# RQR-KGC Paper

Paper and runnable implementation for **Reciprocal Relation Learning with
Relative Quaternion Geometry for Knowledge Graph Completion**.

## Code

The standalone implementation is under `code/`. It includes complete training,
validation, checkpoint selection, and filtered test evaluation. Reproduction
commands for FB15k-237 and WN18RR are documented in `code/README.md`.

## Build

The paper uses the official ICASSP style files included in this repository.
Build it with:

```bash
pdflatex paper.tex
bibtex paper
pdflatex paper.tex
pdflatex paper.tex
```

The resulting manuscript is `paper.pdf`.

## Repository contents

- `paper.tex`: main manuscript.
- `code/`: standalone RQR-KGC implementation and reproduction scripts.
- `rqr_model_figure.tex`: TikZ model diagram included by the manuscript.
- `rqr_motivation.jpg`: motivation figure.
- `references.bib`: bibliography.
- `spconf.sty` and `IEEEbib.bst`: ICASSP formatting files.
- `fb15k237_relation_types_ns256.json`: machine-readable relation-mapping
  evaluation used by the corresponding table.
- `motivation_assets_attribution.json`: attribution metadata for motivation
  figure assets.

## Result protocol

Reported link-prediction metrics use filtered head and tail ranking. Model
checkpoints are selected using validation MRR and evaluated on the test split.
The best FB15k-237 main result uses 256 negatives. The controlled component
ablations use 128 negatives for both the complete-model control and every
ablation variant.
