"""Bounded quaternion-block scales on the unchanged v73 directional geometry."""

import torch
from torch import nn

from model import KGEModel
from models.bidirectional_relative_quaternion import relative_relation_frames
from models.quaternion import hamilton_product

MODEL = 'BidirectionalResidualReciprocalRelativeQuaternionTransERR'


class ScaledV73(KGEModel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.model_name != MODEL or self.entity_dim % 4:
            raise ValueError('Requires v73 with a quaternion-compatible real width')
        self.quaternion_scale_raw = nn.Parameter(
            torch.zeros(self.nrelation, 2, self.entity_dim // 4))

    def endpoint_scales(self, ids, inverse=False):
        scales = torch.exp(.5 * torch.tanh(self.quaternion_scale_raw[ids]))
        if inverse:
            scales = scales.flip(1)
        # Component-major layout: all real components, then all i, j, k.
        return scales.repeat(1, 1, 4)

    def forward(self, sample, mode='single'):
        if mode in ('single', 'head-single', 'tail-single'):
            positive = sample
            head = self.entity_embedding[positive[:, 0]].unsqueeze(1)
            tail = self.entity_embedding[positive[:, 2]].unsqueeze(1)
        elif mode in ('head-batch', 'tail-batch'):
            positive, candidates = sample
            head = (self.entity_embedding[candidates] if mode == 'head-batch'
                    else self.entity_embedding[positive[:, 0]].unsqueeze(1))
            tail = (self.entity_embedding[candidates] if mode == 'tail-batch'
                    else self.entity_embedding[positive[:, 2]].unsqueeze(1))
        else:
            raise ValueError('Unsupported mode: ' + mode)
        ids = positive[:, 1]
        relation = self.relation_embedding[ids].unsqueeze(1)
        inverse = mode in ('head-single', 'head-batch')
        if inverse:
            relation = self._coupled_inverse_relation(relation, ids)
            head, tail = tail, head
        else:
            relation = self._tail_residual_relation(relation, ids)
        wh, translation, _, wt = relative_relation_frames(relation)
        scales = self.endpoint_scales(ids, inverse)
        residual = (scales[:, :1] * hamilton_product(head, wh) + translation
                    - scales[:, 1:] * hamilton_product(tail, wt))
        return self.gamma.item() - residual.norm(p=1, dim=2)


def scaled_optimizer(original_builder, model, learning_rate, multiplier, *rates):
    optimizer = original_builder(model, learning_rate, *rates)
    scale = model.quaternion_scale_raw
    for group in optimizer.param_groups:
        group['params'] = [p for p in group['params'] if p is not scale]
    optimizer.add_param_group(dict(params=[scale], lr=learning_rate * multiplier,
                                   name='quaternion_scale'))
    return optimizer
