#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
REPO_ROOT=$(cd -- "$SCRIPT_DIR/.." && pwd)
cd "$REPO_ROOT"

DATA_PATH=${1:-data/wn18rr}
OUTPUT_PATH=${2:-outputs/wn18rr}
GPU_ID=${3:-0}

CUDA_VISIBLE_DEVICES="$GPU_ID" python -u code/train.py \
  --scale_variant lr2 \
  --data_path "$DATA_PATH" \
  --dataset wn18rr \
  --do_train --do_valid --do_test --cuda \
  --model BidirectionalResidualReciprocalRelativeQuaternionTransERR \
  --triple_relation_embedding \
  --negative_sample_size 128 \
  --batch_size 2048 \
  --hidden_dim 1000 \
  --gamma 12 \
  --negative_adversarial_sampling \
  --adversarial_temperature 0.5 \
  --learning_rate 0.001 \
  --max_steps 100000 \
  --warm_up_ratio 0.2 0.5 0.8 \
  --lr_decay_factor 10 \
  --regularization 0.4 \
  --norm_aware_regularization \
  --cpu_num 8 \
  --test_batch_size 8 \
  --log_steps 100 \
  --valid_steps 2000 \
  --save_checkpoint_steps 2000 \
  --save_best_valid --test_best_valid \
  --seed 20260806 \
  --save_path "$OUTPUT_PATH" \
  --curriculum_hard_negative_min_ratio 0.05 \
  --curriculum_hard_negative_max_ratio 0.15 \
  --curriculum_hard_negative_start_step 4000 \
  --curriculum_hard_negative_ramp_steps 8000 \
  --curriculum_hard_rank_topk 8 \
  --rank_loss_weight 0.025 \
  --rank_loss_margin 0.5 \
  --rank_loss_topk 10 \
  --rank_loss_mode hybrid \
  --rank_loss_cutoffs 1 3 10 \
  --reciprocal_residual_bound 0.1 \
  --reciprocal_residual_regularization 0.0001 \
  --reciprocal_residual_lr_decay_factor 10 \
  --reciprocal_residual_lr_scale 0.5
