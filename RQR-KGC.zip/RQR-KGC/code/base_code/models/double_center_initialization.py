"""Train-only L1 residual initialization after an ordinary TransERR warmup."""

import torch


def fit_two_l1_centers(points, max_iterations=10):
    if points.ndim != 2 or not points.shape[0] or not points.shape[1]:
        raise ValueError('Expected a nonempty [samples, dimensions] residual tensor')
    if max_iterations < 1 or not torch.isfinite(points).all():
        raise ValueError('Clustering requires finite residuals and positive iterations')
    median = points.median(dim=0).values
    farthest = (points - median).abs().sum(dim=1).argmax()
    centers = torch.stack((median, points[farthest]))
    previous = None
    for _ in range(max_iterations):
        assignment = torch.cdist(points, centers, p=1).argmin(dim=1)
        if previous is not None and torch.equal(assignment, previous):
            break
        for cluster in range(2):
            members = points[assignment == cluster]
            if len(members):
                centers[cluster] = members.median(dim=0).values
        previous = assignment
    assignment = torch.cdist(points, centers, p=1).argmin(dim=1)
    return centers, assignment


@torch.no_grad()
def configure_double_center_stage(model, method, checkpoint=None):
    if model.model_name != 'DoubleCenterTransERR':
        return
    if method not in ('random', 'residual_kmedians'):
        raise ValueError('Unknown double-center initialization method: ' + method)
    if method == 'residual_kmedians' and checkpoint is not None:
        if 'double_center_split_complete' not in checkpoint:
            raise ValueError('Residual initialization checkpoint is missing its stage marker')
    complete = bool(checkpoint and checkpoint.get('double_center_split_complete', False))
    model.double_center_split_complete = complete
    model.double_center_warmup_active = method == 'residual_kmedians' and not complete
    if model.double_center_warmup_active and checkpoint is None:
        model.center_offset.zero_()


@torch.no_grad()
def initialize_double_centers_from_train(model, train_triples, optimizer=None,
                                        relation_names=None, batch_size=512,
                                        max_iterations=10):
    if model.model_name != 'DoubleCenterTransERR':
        raise ValueError('Residual initialization requires DoubleCenterTransERR')
    if getattr(model, 'double_center_split_complete', False):
        raise ValueError('Double centers have already been initialized')
    if not getattr(model, 'double_center_warmup_active', False):
        raise ValueError('Residual initialization requires an active warmup stage')
    if batch_size < 1 or max_iterations < 1:
        raise ValueError('Batch size and clustering iterations must be positive')
    triples = torch.as_tensor(train_triples, dtype=torch.long, device='cpu')
    if triples.ndim != 2 or triples.shape[1] != 3 or not len(triples):
        raise ValueError('Expected nonempty training triples')
    if (triples.min() < 0 or triples[:, 1].max() >= model.nrelation
            or triples[:, (0, 2)].max() >= model.nentity):
        raise ValueError('Training triple IDs are out of range')

    names = relation_names or {}
    device = model.entity_embedding.device
    dimension = model.entity_dim
    updates, rows = [], []
    for rid in range(model.nrelation):
        selected = triples[triples[:, 1] == rid]
        row = {'relation_id': rid, 'relation': names.get(rid, str(rid)),
               'train_count': len(selected), 'applied': False}
        rows.append(row)
        if not len(selected):
            row['reason'] = 'no_training_triples'
            continue
        wh, translation, wt = model.relation_embedding[rid].view(1, 1, -1).chunk(3, dim=2)
        wh, wt = model.q_norm(wh), model.q_norm(wt)
        chunks = []
        for start in range(0, len(selected), batch_size):
            batch = selected[start:start + batch_size].to(device)
            head = model.entity_embedding[batch[:, 0]].unsqueeze(1)
            tail = model.entity_embedding[batch[:, 2]].unsqueeze(1)
            residual = model._calc(head, wh) + translation - model._calc(tail, wt)
            chunks.append(residual.squeeze(1).cpu())
        points = torch.cat(chunks, dim=0)
        centers, assignment = fit_two_l1_centers(points, max_iterations)
        counts = torch.bincount(assignment, minlength=2)
        midpoint = centers.mean(dim=0)
        offset = (centers[0] - centers[1]) / 2
        row.update(cluster_counts=counts.tolist(),
                   mean_l1_before=points.abs().sum(dim=1).mean().item(),
                   center_separation_l2=(2 * offset.norm()).item())
        if (counts == 0).any() or not torch.any(offset != 0):
            row['reason'] = 'degenerate_clusters_keep_original_translation'
            continue
        row.update(applied=True, translation_shift_l2=midpoint.norm().item(),
                   mean_l1_nearest_after=torch.cdist(points, centers, p=1).min(dim=1).values.mean().item())
        updates.append((rid, midpoint.to(device), offset.to(device)))

    # z_new +/- delta = z_old - c2/c1, so preserve the original relation frames.
    for rid, midpoint, offset in updates:
        model.relation_embedding[rid, dimension:2 * dimension].sub_(midpoint)
        model.center_offset[rid].copy_(offset)
    if optimizer is not None:
        optimizer.state.pop(model.center_offset, None)
        relation_state = optimizer.state.get(model.relation_embedding, {})
        for key in ('exp_avg', 'exp_avg_sq', 'max_exp_avg_sq', 'momentum_buffer'):
            moment = relation_state.get(key)
            if moment is not None:
                for rid, _, _ in updates:
                    moment[rid, dimension:2 * dimension].zero_()
    model.center_offset.grad = None
    model.double_center_split_complete = True
    model.double_center_warmup_active = False
    return {'split': 'train', 'num_triples': len(triples),
            'method': 'deterministic_l1_kmedians', 'max_iterations': max_iterations,
            'relations_updated': len(updates), 'relations': rows,
            'optimizer_reset': 'center state and changed translation moments only; shared relation Adam step retained'}
