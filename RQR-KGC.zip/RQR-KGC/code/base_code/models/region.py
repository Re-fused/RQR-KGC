"""A bounded, leaky tolerance region in the original TransERR frame."""

import torch


def region_distance(residual, block_width, inner_weight):
    # Quaternions are stored component-major: [all s, all x, all y, all z].
    width = torch.cat([block_width] * 4, dim=-1)
    absolute = residual.abs()
    outside = (absolute - width).clamp_min(0)
    inside = torch.minimum(absolute, width)
    return (outside + inner_weight * inside).sum(dim=-1)


@torch.no_grad()
def region_diagnostics(model, train_triples, relation_names=None, batch_size=512):
    if model.model_name != 'RegionTransERR' or batch_size < 1:
        raise ValueError('Region diagnostics require RegionTransERR and a positive batch size')
    widths = model.effective_region_width().detach()
    counts = torch.zeros(model.nrelation, dtype=torch.long, device=widths.device)
    inside = torch.zeros(model.nrelation, dtype=torch.float64, device=widths.device)
    for start in range(0, len(train_triples), batch_size):
        batch = torch.as_tensor(train_triples[start:start + batch_size],
                                dtype=torch.long, device=widths.device)
        ids = batch[:, 1]
        head = model.entity_embedding[batch[:, 0]].unsqueeze(1)
        tail = model.entity_embedding[batch[:, 2]].unsqueeze(1)
        wh, translation, wt = model.relation_embedding[ids].unsqueeze(1).chunk(3, dim=2)
        residual = model._calc(head, model.q_norm(wh)) + translation - model._calc(tail, model.q_norm(wt))
        width = torch.cat([widths[ids]] * 4, dim=-1)
        fraction = (residual.squeeze(1).abs() < width).double().mean(dim=-1)
        counts.index_add_(0, ids, torch.ones_like(ids))
        inside.index_add_(0, ids, fraction)
    rows = []
    for rid, count in enumerate(counts.cpu().tolist()):
        width = widths[rid]
        rows.append({
            'relation_id': rid, 'relation': (relation_names or {}).get(rid, str(rid)),
            'train_count': count, 'width_min': width.min().item(),
            'width_mean': width.mean().item(), 'width_max': width.max().item(),
            'fraction_widths_near_upper_bound': (
                (width >= 0.99 * model.region_width_bound).float().mean().item()
                if model.region_width_bound else 0.0),
            'train_coordinate_inside_fraction': inside[rid].item() / count if count else None,
        })
    return {'split': 'train', 'num_triples': len(train_triples),
            'width_bound': model.region_width_bound, 'inner_weight': model.region_inner_weight,
            'relations': rows}
