"""Eight-real-coordinate SU(2) actions in the existing right-Hamilton convention."""

import math

import torch

from models.quaternion import normalize_quaternion


SPIN_MODELS = ('SpinThreeHalfTransERR', 'SharedQuaternion8TransERR')


def split_spin_relation(relation, entity_dim):
    """Compact frames: [head d/2, translation d, tail d/2]."""
    if entity_dim < 8 or entity_dim % 8 or relation.size(-1) != 2 * entity_dim:
        raise ValueError('Spin relations require entity width divisible by eight and relation width 2*d')
    return relation.split((entity_dim // 2, entity_dim, entity_dim // 2), dim=-1)


def right_hamilton_matrix(frame):
    """U(q)[s+i*x,y+i*z] equals the complex encoding of quaternion x*q."""
    if frame.ndim != 3 or frame.size(-1) < 4 or frame.size(-1) % 4:
        raise ValueError('Expected [batch, 1, 4*groups] quaternion frames')
    if frame.size(1) != 1 or frame.dtype not in (torch.float32, torch.float64):
        raise ValueError('Frames require singleton candidate axis and float32/float64')
    a, b, c, d = normalize_quaternion(frame).chunk(4, dim=-1)
    alpha, beta = torch.complex(a, b), torch.complex(-c, d)
    return torch.stack((alpha, beta, -beta.conj(), alpha.conj()), -1).reshape(
        *alpha.shape, 2, 2)


def symmetric_cube(matrix):
    """Sym^3(U), in the orthonormal symmetric tensor basis 000,001,011,111."""
    if matrix.shape[-2:] != (2, 2):
        raise ValueError('Symmetric cube requires 2x2 matrices')
    a, b = matrix[..., 0, 0], matrix[..., 0, 1]
    c, d = matrix[..., 1, 0], matrix[..., 1, 1]
    k = math.sqrt(3)
    rows = (
        (a ** 3, k * a.square() * b, k * a * b.square(), b ** 3),
        (k * a.square() * c, a.square() * d + 2 * a * b * c,
         2 * a * b * d + b.square() * c, k * b.square() * d),
        (k * a * c.square(), 2 * a * c * d + b * c.square(),
         a * d.square() + 2 * b * c * d, k * b * d.square()),
        (c ** 3, k * c.square() * d, k * c * d.square(), d ** 3),
    )
    return torch.stack([torch.stack(row, -1) for row in rows], -2)


def spin_operator(frame, model_name):
    unitary = right_hamilton_matrix(frame)
    if model_name == 'SpinThreeHalfTransERR':
        return symmetric_cube(unitary)
    if model_name == 'SharedQuaternion8TransERR':
        zero = torch.zeros_like(unitary)
        return torch.cat((torch.cat((unitary, zero), -1),
                          torch.cat((zero, unitary), -1)), -2)
    raise ValueError('Unknown spin model: %s' % model_name)


def to_complex_groups(value):
    """Pair adjacent original quaternion blocks; preserve component-major storage."""
    if value.ndim != 3 or value.size(-1) < 8 or value.size(-1) % 8:
        raise ValueError('Expected [batch, candidates, d] with d divisible by eight')
    groups = value.size(-1) // 8
    paired = value.reshape(*value.shape[:2], 4, groups, 2).permute(0, 1, 3, 4, 2)
    return torch.view_as_complex(paired.contiguous().view(*value.shape[:2], groups, 4, 2))


def from_complex_groups(value):
    paired = torch.view_as_real(value.resolve_conj()).reshape(*value.shape[:3], 2, 4)
    return paired.permute(0, 1, 4, 2, 3).reshape(*value.shape[:2], -1)


def apply_spin_operator(value, operator):
    groups = to_complex_groups(value)
    if operator.ndim != 5 or operator.shape[1:] != (1, groups.size(2), 4, 4):
        raise ValueError('Operator must have shape [batch, 1, groups, 4, 4]')
    # Contract per relation/group, without expanding matrices over candidates.
    transformed = torch.einsum('bgoi,bngi->bngo', operator.squeeze(1), groups)
    return from_complex_groups(transformed)


@torch.no_grad()
def spin_diagnostics(model):
    if model.model_name not in SPIN_MODELS:
        raise ValueError('Expected a spin model')
    source, _, target = split_spin_relation(model.relation_embedding.unsqueeze(1), model.entity_dim)
    rows = []
    for rid in range(model.nrelation):
        row = {'relation_id': rid}
        for name, frame in (('head', source[rid:rid + 1]), ('tail', target[rid:rid + 1])):
            operator = spin_operator(frame.double(), model.model_name)
            identity = torch.eye(4, dtype=operator.dtype, device=operator.device)
            norms = frame.reshape(1, 1, 4, -1).square().sum(-2).sqrt()
            row[name] = {'raw_norm_min': norms.min().item(),
                         'raw_norm_max': norms.max().item(),
                         'unitarity_max_error': (operator.mH @ operator - identity).abs().max().item()}
        rows.append(row)
    return {'model': model.model_name, 'scope': 'relation_parameters_only_not_metrics',
            'entity_dim': model.entity_dim, 'groups': model.entity_dim // 8,
            'relation_dim': model.relation_dim, 'relations': rows}
