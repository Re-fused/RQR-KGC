"""Blockwise complexified-quaternion operations."""

import torch

from models.quaternion import hamilton_product


def _require_biquaternion_width(value):
    if value.size(-1) % 8 != 0:
        raise ValueError(
            'Biquaternion tensors require the last dimension divisible by 8'
        )


def normalize_biquaternion(value, epsilon=1e-9):
    """Normalize each eight-component biquaternion block."""
    _require_biquaternion_width(value)
    parts = torch.chunk(value, 8, dim=2)
    denominator = torch.sqrt(sum(part.square() for part in parts))
    denominator = denominator.clamp_min(epsilon)
    return torch.cat([part / denominator for part in parts], dim=2)


def biquaternion_product(left, right):
    """Multiply (p + I*q)(a + I*b), where I commutes and I^2 = -1."""
    _require_biquaternion_width(left)
    _require_biquaternion_width(right)
    left_real, left_imag = torch.chunk(left, 2, dim=2)
    right_real, right_imag = torch.chunk(right, 2, dim=2)

    real = (
        hamilton_product(left_real, right_real)
        - hamilton_product(left_imag, right_imag)
    )
    imag = (
        hamilton_product(left_real, right_imag)
        + hamilton_product(left_imag, right_real)
    )
    return torch.cat([real, imag], dim=2)
