"""Relation-specific real orthogonal mixing across quaternion blocks."""

import torch


def spectral_multiplier(phase, block_count):
    """Unit-modulus half spectrum with fixed real DC/Nyquist coefficients."""
    if block_count < 3 or phase.size(-1) != (block_count - 1) // 2:
        raise ValueError('Spectral phase width must equal (quaternion count - 1) // 2')
    if phase.dtype not in (torch.float32, torch.float64):
        raise ValueError('Spectral phases require float32 or float64')
    zero = torch.zeros_like(phase[..., :1])
    angles = torch.cat((zero, phase, zero), -1) if block_count % 2 == 0 else torch.cat((zero, phase), -1)
    return torch.complex(angles.cos(), angles.sin())


def spectral_mix(value, phase):
    """Mix block indices, sharing a circulant operator over s/x/y/z channels.

    Values use component-major storage. ``phase`` broadcasts over the leading
    value dimensions, e.g. [batch, 1, frequencies] for candidate scoring.
    """
    if value.size(-1) % 4 or value.dtype != phase.dtype:
        raise ValueError('Spectral values must have quaternion width and match phase dtype')
    block_count = value.size(-1) // 4
    multiplier = spectral_multiplier(phase, block_count).unsqueeze(-2)
    channels = value.reshape(*value.shape[:-1], 4, block_count)
    spectrum = torch.fft.rfft(channels, dim=-1, norm='ortho')
    mixed = torch.fft.irfft(spectrum * multiplier, n=block_count, dim=-1, norm='ortho')
    return mixed.flatten(start_dim=-2)


@torch.no_grad()
def spectral_diagnostics(model, relation_names=None):
    """Parameter-only diagnostics; no triples, RNG, or model state changes."""
    if model.model_name != 'SpectralTransERR':
        raise ValueError('Spectral diagnostics require SpectralTransERR')
    phase = model.spectral_phase.detach()
    block_count = model.entity_dim // 4
    multiplier = spectral_multiplier(phase, block_count)
    wrapped_phase = torch.atan2(phase.sin(), phase.cos())
    # The backward-normalized IFFT gives the real circulant impulse response.
    kernel = torch.fft.irfft(multiplier, n=block_count, norm='backward')
    energy = kernel.square().sum(-1)
    off_diagonal = kernel[..., 1:].square().sum(-1)
    rows = []
    for rid in range(model.nrelation):
        row = {'relation_id': rid,
               'relation': relation_names[rid] if relation_names is not None else str(rid)}
        for side, label in enumerate(('head', 'tail')):
            row[label] = {
                'mean_absolute_phase_radians': wrapped_phase[rid, side].abs().mean().item(),
                'max_absolute_phase_radians': wrapped_phase[rid, side].abs().max().item(),
                'off_diagonal_kernel_energy': off_diagonal[rid, side].item(),
                'kernel_energy_error': (energy[rid, side] - 1).abs().item(),
            }
        rows.append(row)
    return {'scope': 'relation_parameters_only', 'quaternion_blocks': block_count,
            'learned_frequencies_per_side': phase.size(-1),
            'shared_over_components': True, 'fixed_dc': True,
            'fixed_nyquist': block_count % 2 == 0, 'relations': rows}
