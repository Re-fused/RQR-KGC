"""Geometry used by bidirectional relative-quaternion TransERR."""

import torch

from models.quaternion import (
    hamilton_product,
    normalize_quaternion,
    quaternion_conjugate,
)


def relative_relation_frames(relation):
    """Decode a relation into source frame, translation, and target frame."""
    base, translation, relative = torch.chunk(relation, 3, dim=2)
    source_frame = normalize_quaternion(base)
    relative = normalize_quaternion(relative)
    target_frame = normalize_quaternion(
        hamilton_product(source_frame, relative)
    )
    return source_frame, translation, relative, target_frame


def score_relative_quaternion(head, relation, tail, gamma):
    """Score triples using a source frame and its relative target frame."""
    source_frame, translation, _, target_frame = (
        relative_relation_frames(relation)
    )
    residual = (
        hamilton_product(head, source_frame) + translation
        - hamilton_product(tail, target_frame)
    )
    return gamma - torch.norm(residual, p=1, dim=2)


def analytic_inverse_relative_relation(relation):
    """Construct the exact inverse of a relative-quaternion relation."""
    _, translation, relative, target_frame = relative_relation_frames(
        relation
    )
    return torch.cat([
        target_frame,
        -translation,
        quaternion_conjugate(relative),
    ], dim=2)


def apply_bounded_relation_residual(
        relation, residual_table, relation_id, bound):
    """Apply a relation-specific residual without changing parameter layout."""
    residual = torch.index_select(
        residual_table, dim=0, index=relation_id
    ).unsqueeze(1)
    return relation + bound * torch.tanh(residual)


def _quaternion_frame_alignment_loss(left, right):
    """Compare normalized quaternion blocks without choosing a sign."""
    left_components = torch.stack(torch.chunk(left, 4, dim=2), dim=-1)
    right_components = torch.stack(torch.chunk(right, 4, dim=2), dim=-1)
    alignment = torch.sum(
        left_components * right_components, dim=-1
    ).clamp(min=-1.0, max=1.0)
    return (1.0 - alignment.square()).mean()


def reciprocal_cycle_consistency(
        relation_embedding, tail_residual, inverse_residual, bound,
        translation_weight=1.0):
    """Measure whether the learned reverse relation closes the forward cycle."""
    relation = relation_embedding.unsqueeze(1)
    forward_relation = relation + (
        bound * torch.tanh(tail_residual).unsqueeze(1)
    )
    expected_inverse = analytic_inverse_relative_relation(forward_relation)
    learned_inverse = analytic_inverse_relative_relation(relation) + (
        bound * torch.tanh(inverse_residual).unsqueeze(1)
    )

    expected_source, expected_translation, _, expected_target = (
        relative_relation_frames(expected_inverse)
    )
    learned_source, learned_translation, _, learned_target = (
        relative_relation_frames(learned_inverse)
    )
    frame_loss = 0.5 * (
        _quaternion_frame_alignment_loss(
            expected_source, learned_source
        )
        + _quaternion_frame_alignment_loss(
            expected_target, learned_target
        )
    )
    translation_loss = torch.mean(
        (expected_translation - learned_translation).square()
    )
    cycle_loss = frame_loss + translation_weight * translation_loss
    return cycle_loss, frame_loss, translation_loss
