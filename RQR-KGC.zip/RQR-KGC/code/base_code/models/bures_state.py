"""Packed 2x2 complex positive-definite states and closed-form Bures geometry."""

import torch
import torch.nn.functional as F


def _parts(value):
    if value.size(-1) < 4 or value.size(-1) % 4:
        raise ValueError('Expected component-major width divisible by four')
    if value.dtype not in (torch.float32, torch.float64):
        raise ValueError('Bures operators require float32 or float64')
    return value.chunk(4, dim=-1)


def cholesky_state(raw, scale, diagonal_floor=.1):
    """Pack [[a,c+i*d],[c-i*d,b]]=L L^H with two positive Cholesky diagonals."""
    p, q, u, v = _parts(raw)
    p = scale * (F.softplus(p / scale) + diagonal_floor)
    q = scale * (F.softplus(q / scale) + diagonal_floor)
    return torch.cat((p.square(), q.square() + u.square() + v.square(), p * u, -p * v), -1)


def unitary_congruence(state, frame):
    """Q S Q^H, Q=[[w+i*x,y+i*z],[-y+i*z,w-i*x]], using real arithmetic."""
    a, b, c, d = _parts(state)
    w, x, y, z = _parts(frame)
    first, second = w.square() + x.square(), y.square() + z.square()
    cross = 2 * ((w * y + x * z) * c + (w * z - x * y) * d)
    real = (w * y - x * z) * (b - a) + (
        w.square() - x.square() - y.square() + z.square()) * c - 2 * (w * x + y * z) * d
    imag = (w * z + x * y) * (b - a) + 2 * (w * x - y * z) * c + (
        w.square() - x.square() + y.square() - z.square()) * d
    return torch.cat((first * a + second * b + cross,
                      second * a + first * b - cross, real, imag), -1)


def affine_state(raw_entity, frame, log_stretch, raw_offset, scale,
                 diagonal_floor=.1, jitter=1e-4):
    """A=Q*diag(exp(log_stretch)); return A*C(entity)*A^H+C(offset)+jitter*I."""
    a, b, c, d = _parts(cholesky_state(raw_entity, scale, diagonal_floor))
    l0, l1 = log_stretch.unbind(-2)
    stretched = torch.cat((a * (2 * l0).exp(), b * (2 * l1).exp(),
                           c * (l0 + l1).exp(), d * (l0 + l1).exp()), -1)
    result = unitary_congruence(stretched, frame) + cholesky_state(raw_offset, scale, diagonal_floor)
    a, b, c, d = _parts(result)
    return torch.cat((a + jitter * scale ** 2, b + jitter * scale ** 2, c, d), -1)


def bures_squared(left, right):
    """Per-block Bures squared distance. Float64 avoids trace subtraction loss."""
    a, b, c, d = _parts(left.double())
    e, f, g, h = _parts(right.double())
    determinant_left = (a * b - c.square() - d.square()).clamp_min(0)
    determinant_right = (e * f - g.square() - h.square()).clamp_min(0)
    trace_product = a * e + b * f + 2 * (c * g + d * h)
    tiny = torch.finfo(torch.float64).tiny
    root_product = (determinant_left * determinant_right).clamp_min(tiny).sqrt()
    fidelity_root = (trace_product + 2 * root_product).clamp_min(tiny).sqrt()
    return (a + b + e + f - 2 * fidelity_root).clamp_min(0)


def bures_distance(left, right, smoothing):
    """Sum smooth Bures lengths, not squared lengths; delta is in distance units."""
    squared = bures_squared(left, right)
    # Rational form is equivalent to sqrt(d^2+delta^2)-delta near d=0.
    value = squared / ((squared + smoothing ** 2).sqrt() + smoothing)
    return value.sum(-1).to(left.dtype)


@torch.no_grad()
def bures_diagnostics(model, sample_size=32):
    if model.model_name != 'BuresTransERR' or sample_size < 1:
        raise ValueError('Expected BuresTransERR and a positive sample size')
    count = min(model.nentity, sample_size)
    ids = torch.arange(count, device=model.entity_embedding.device) * model.nentity // count
    head = model.entity_embedding[ids].unsqueeze(0)
    tail = model.entity_embedding[ids.roll(1)].unsqueeze(0)
    rows = []
    for rid in range(model.nrelation):
        relation_id = torch.tensor([rid], device=ids.device)
        relation = model.relation_embedding[rid].view(1, 1, -1)
        source, target = model.bures_endpoint_states(head, relation, tail, relation_id)
        row = {'relation_id': rid}
        for name, state in (('source', source), ('target', target)):
            a, b, c, d = _parts(state.double())
            trace = a + b
            gap = ((a - b).square() + 4 * (c.square() + d.square())).sqrt()
            minimum = (trace - gap) / 2
            row[name] = {'min_eigenvalue': minimum.min().item(),
                         'mean_trace': trace.mean().item(),
                         'max_condition_number': ((trace + gap) / 2 / minimum).max().item()}
        row['mean_distance'] = bures_distance(source, target, model.bures_smoothing * model.bures_scale).mean().item()
        rows.append(row)
    return {'model': model.model_name, 'scope': 'deterministic_embedding_sample_not_metrics',
            'state_scale': model.bures_scale, 'distance_scale': model.bures_distance_scale.item(),
            'stretch_bound': model.bures_stretch_bound, 'diagonal_floor': model.bures_diagonal_floor,
            'smoothing': model.bures_smoothing, 'jitter': model.bures_jitter, 'relations': rows}
