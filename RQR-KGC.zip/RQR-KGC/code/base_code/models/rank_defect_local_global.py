"""Rank-defect local-to-global operators for relative-quaternion TransERR.

The operator keeps Hamilton multiplication as the local action, reshapes its
output into a matrix, removes a relation-specific tensor-product subspace, and
then applies low-rank Cayley rotations on both matrix axes.  At zero progress
the operation is exactly the identity, which lets the enclosing model recover
the v73 score without a learned gate.
"""

import math
from collections import defaultdict

import torch


def balanced_matrix_shape(width, requested_rows=0):
    """Return a deterministic factorization ``rows * columns == width``."""
    width = int(width)
    requested_rows = int(requested_rows)
    if width <= 0:
        raise ValueError('width must be positive')
    if requested_rows:
        if requested_rows <= 0 or width % requested_rows != 0:
            raise ValueError('requested_rows must be a positive divisor of width')
        return requested_rows, width // requested_rows

    rows = math.isqrt(width)
    while width % rows != 0:
        rows -= 1
    return rows, width // rows


def _degree_to_rank(degree, max_rank, scale):
    if degree <= 1.0 + 1e-12 or max_rank == 0 or scale == 0.0:
        return 0
    rank = int(math.ceil(scale * math.log(degree, 2.0) - 1e-12))
    return min(max(rank, 1), max_rank)


def relation_cardinality_defect_ranks(
        triples, nrelation, max_rank=4, scale=1.0):
    """Infer directional rank defects from training triples only.

    Head rank follows the average number of heads per tail (many-to-one
    collapse).  Tail rank follows the average number of tails per head
    (one-to-many ambiguity).  The logarithmic map avoids assigning the maximum
    rank to every non-bijective relation.
    """
    nrelation = int(nrelation)
    max_rank = int(max_rank)
    scale = float(scale)
    if nrelation <= 0:
        raise ValueError('nrelation must be positive')
    if max_rank < 0:
        raise ValueError('max_rank must be non-negative')
    if scale < 0.0:
        raise ValueError('scale must be non-negative')

    heads = defaultdict(set)
    tails = defaultdict(set)
    counts = [0] * nrelation
    for head, relation, tail in triples:
        relation = int(relation)
        if not 0 <= relation < nrelation:
            raise ValueError('relation id is outside [0, nrelation)')
        counts[relation] += 1
        heads[relation].add(int(head))
        tails[relation].add(int(tail))

    head_ranks = []
    tail_ranks = []
    diagnostics = []
    for relation in range(nrelation):
        count = counts[relation]
        if count == 0:
            heads_per_tail = 1.0
            tails_per_head = 1.0
        else:
            heads_per_tail = count / max(len(tails[relation]), 1)
            tails_per_head = count / max(len(heads[relation]), 1)
        head_rank = _degree_to_rank(heads_per_tail, max_rank, scale)
        tail_rank = _degree_to_rank(tails_per_head, max_rank, scale)
        head_ranks.append(head_rank)
        tail_ranks.append(tail_rank)
        diagnostics.append({
            'relation': relation,
            'triples': count,
            'heads_per_tail': heads_per_tail,
            'tails_per_head': tails_per_head,
            'head_defect_rank': head_rank,
            'tail_defect_rank': tail_rank,
        })
    return head_ranks, tail_ranks, diagnostics


def orthonormal_columns(raw):
    """Map full-column-rank factors to an orthonormal basis."""
    if raw.size(-2) < raw.size(-1):
        raise ValueError('basis rows must be at least its rank')
    return torch.linalg.qr(raw, mode='reduced').Q


def cayley_matrix(raw_generator, bound=0.25, progress=1.0):
    """Construct an orthogonal matrix from a bounded skew generator."""
    if raw_generator.size(-1) != raw_generator.size(-2):
        raise ValueError('Cayley generator must be square')
    bound = float(bound)
    if bound <= 0.0:
        raise ValueError('bound must be positive')
    progress = torch.as_tensor(
        progress, dtype=raw_generator.dtype, device=raw_generator.device
    ).clamp(min=0.0, max=1.0)
    skew_raw = raw_generator - raw_generator.transpose(-1, -2)
    scale = bound * progress / math.sqrt(float(raw_generator.size(-1)))
    skew = scale * torch.tanh(skew_raw)
    identity = torch.eye(
        raw_generator.size(-1),
        dtype=raw_generator.dtype,
        device=raw_generator.device,
    ).expand(raw_generator.shape)
    return torch.linalg.solve(
        identity - 0.5 * skew,
        identity + 0.5 * skew,
    )


def rank_defect_projection(matrix, left_basis, right_basis, ranks,
                           progress=1.0):
    """Remove a rank-controlled tensor-product subspace from a matrix."""
    if matrix.dim() != 4:
        raise ValueError('matrix must have shape [batch, candidates, rows, cols]')
    rank = left_basis.size(-1)
    if right_basis.size(-1) != rank:
        raise ValueError('left and right defect bases must have equal rank')
    if ranks.dim() != 1 or ranks.size(0) != matrix.size(0):
        raise ValueError('ranks must have shape [batch]')

    left = orthonormal_columns(left_basis)
    right = orthonormal_columns(right_basis)
    column = torch.arange(rank, device=matrix.device).unsqueeze(0)
    mask = (column < ranks.unsqueeze(1)).to(matrix.dtype)
    left = left * mask.unsqueeze(1)
    right = right * mask.unsqueeze(1)

    coordinates = torch.matmul(
        left.transpose(-1, -2).unsqueeze(1), matrix
    )
    coordinates = torch.matmul(coordinates, right.unsqueeze(1))
    projection = torch.matmul(left.unsqueeze(1), coordinates)
    projection = torch.matmul(
        projection, right.transpose(-1, -2).unsqueeze(1)
    )
    progress = torch.as_tensor(
        progress, dtype=matrix.dtype, device=matrix.device
    ).clamp(min=0.0, max=1.0)
    return matrix - progress * projection


def low_rank_two_sided_cayley(
        matrix, left_basis, left_generator,
        right_basis, right_generator, bound=0.25, progress=1.0):
    """Apply ``Q_left matrix Q_right^T`` without forming large Q matrices."""
    left = orthonormal_columns(left_basis)
    right = orthonormal_columns(right_basis)
    left_small = cayley_matrix(left_generator, bound, progress)
    right_small = cayley_matrix(right_generator, bound, progress)

    left_coordinates = torch.matmul(
        left.transpose(-1, -2).unsqueeze(1), matrix
    )
    left_delta = left_small - torch.eye(
        left_small.size(-1),
        dtype=left_small.dtype,
        device=left_small.device,
    )
    matrix = matrix + torch.matmul(
        left.unsqueeze(1),
        torch.matmul(left_delta.unsqueeze(1), left_coordinates),
    )

    right_coordinates = torch.matmul(matrix, right.unsqueeze(1))
    right_delta = right_small.transpose(-1, -2) - torch.eye(
        right_small.size(-1),
        dtype=right_small.dtype,
        device=right_small.device,
    )
    matrix = matrix + torch.matmul(
        torch.matmul(right_coordinates, right_delta.unsqueeze(1)),
        right.transpose(-1, -2).unsqueeze(1),
    )
    return matrix


def local_global_rank_defect_transform(
        value, rows, defect_left_basis, defect_right_basis, defect_ranks,
        rotation_left_basis, rotation_left_generator,
        rotation_right_basis, rotation_right_generator,
        cayley_bound=0.25, progress=1.0):
    """Apply rank defect followed by a global low-rank orthogonal action."""
    rows = int(rows)
    if value.size(-1) % rows != 0:
        raise ValueError('rows must divide the value width')
    columns = value.size(-1) // rows
    matrix = value.reshape(value.shape[:-1] + (rows, columns))
    matrix = rank_defect_projection(
        matrix,
        defect_left_basis,
        defect_right_basis,
        defect_ranks,
        progress,
    )
    matrix = low_rank_two_sided_cayley(
        matrix,
        rotation_left_basis,
        rotation_left_generator,
        rotation_right_basis,
        rotation_right_generator,
        cayley_bound,
        progress,
    )
    return matrix.reshape(value.shape)
