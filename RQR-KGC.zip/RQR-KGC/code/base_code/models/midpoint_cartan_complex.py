"""Stable midpoint frames from a Cartan-style complex factorization."""

import math

import torch

from models.matrix_algebra import complex_matrix2_product


def _parts(value):
    if value.size(-1) % 8 != 0:
        raise ValueError(
            'MidpointCartanComplexTransERR requires the last dimension '
            'to be divisible by 8'
        )
    return torch.chunk(value, 8, dim=-1)


def _su2_from_euler(raw_alpha, raw_beta, raw_gamma, parameter_scale):
    scale = torch.as_tensor(
        parameter_scale, dtype=raw_alpha.dtype, device=raw_alpha.device
    )
    alpha = math.pi * torch.tanh(raw_alpha / scale)
    beta = math.pi * torch.tanh(raw_beta / scale)
    gamma = math.pi * torch.tanh(raw_gamma / scale)

    half_sum = 0.5 * (alpha + gamma)
    half_difference = 0.5 * (alpha - gamma)
    cosine = torch.cos(0.5 * beta)
    sine = torch.sin(0.5 * beta)

    real00 = cosine * torch.cos(half_sum)
    imag00 = cosine * torch.sin(half_sum)
    real01 = sine * torch.cos(half_difference)
    imag01 = sine * torch.sin(half_difference)
    real10 = -sine * torch.cos(half_difference)
    imag10 = sine * torch.sin(half_difference)
    real11 = real00
    imag11 = -imag00
    return torch.cat([
        real00, real01, real10, real11,
        imag00, imag01, imag10, imag11,
    ], dim=-1)


def complex_matrix2_conjugate_transpose(value):
    """Return the conjugate transpose of component-major 2x2 blocks."""
    real00, real01, real10, real11, imag00, imag01, imag10, imag11 = (
        _parts(value)
    )
    return torch.cat([
        real00, real10, real01, real11,
        -imag00, -imag10, -imag01, -imag11,
    ], dim=-1)


def _multiply_by_complex_phase(value, phase):
    cosine = torch.cos(phase)
    sine = torch.sin(phase)
    parts = _parts(value)
    real_parts = parts[:4]
    imag_parts = parts[4:]
    real = [r * cosine - i * sine for r, i in zip(
        real_parts, imag_parts
    )]
    imag = [r * sine + i * cosine for r, i in zip(
        real_parts, imag_parts
    )]
    return torch.cat(real + imag, dim=-1)


def _real_diagonal_matrix2(stretch):
    zeros = torch.zeros_like(stretch)
    return torch.cat([
        torch.exp(stretch), zeros, zeros, torch.exp(-stretch),
        zeros, zeros, zeros, zeros,
    ], dim=-1)


def midpoint_cartan_frames(
        raw_frame, parameter_scale, stretch_bound=0.5):
    """Build F and its analytic inverse from each 8-real parameter block."""
    if stretch_bound < 0.0:
        raise ValueError('stretch_bound must be non-negative')
    parameters = _parts(raw_frame)
    left_unitary = _su2_from_euler(
        parameters[0], parameters[1], parameters[2], parameter_scale
    )
    right_unitary = _su2_from_euler(
        parameters[3], parameters[4], parameters[5], parameter_scale
    )

    scale = torch.as_tensor(
        parameter_scale,
        dtype=raw_frame.dtype,
        device=raw_frame.device,
    )
    stretch = stretch_bound * torch.tanh(parameters[6] / scale)
    phase = math.pi * torch.tanh(parameters[7] / scale)
    left_unitary = _multiply_by_complex_phase(left_unitary, phase)

    diagonal = _real_diagonal_matrix2(stretch)
    inverse_diagonal = _real_diagonal_matrix2(-stretch)
    frame = complex_matrix2_product(
        complex_matrix2_product(left_unitary, diagonal),
        right_unitary,
    )
    inverse_frame = complex_matrix2_product(
        complex_matrix2_product(
            complex_matrix2_conjugate_transpose(right_unitary),
            inverse_diagonal,
        ),
        complex_matrix2_conjugate_transpose(left_unitary),
    )
    return frame, inverse_frame
