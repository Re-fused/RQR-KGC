"""Reusable geometric operations for TransERR model variants."""

