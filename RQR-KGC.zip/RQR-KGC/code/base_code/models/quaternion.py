"""Quaternion tensor operations shared by TransERR model variants."""

import torch


def hamilton_product(left, right):
    """Multiply blockwise quaternions stored along the final dimension."""
    s_a, x_a, y_a, z_a = torch.chunk(left, 4, dim=2)
    s_b, x_b, y_b, z_b = torch.chunk(right, 4, dim=2)

    scalar = s_a * s_b - x_a * x_b - y_a * y_b - z_a * z_b
    x = s_a * x_b + s_b * x_a + y_a * z_b - y_b * z_a
    y = s_a * y_b + s_b * y_a + z_a * x_b - z_b * x_a
    z = s_a * z_b + s_b * z_a + x_a * y_b - x_b * y_a

    return torch.cat([scalar, x, y, z], dim=2)


def normalize_quaternion(value):
    """Normalize each quaternion block independently."""
    scalar, x, y, z = torch.chunk(value, 4, dim=2)
    denominator = torch.sqrt(
        scalar ** 2 + x ** 2 + y ** 2 + z ** 2
    ).clamp_min(1e-9)
    scalar = scalar / denominator
    x = x / denominator
    y = y / denominator
    z = z / denominator
    return torch.cat([scalar, x, y, z], dim=2)


def quaternion_conjugate(value):
    """Return the conjugate of each quaternion block."""
    scalar, x, y, z = torch.chunk(value, 4, dim=2)
    return torch.cat([scalar, -x, -y, -z], dim=2)

