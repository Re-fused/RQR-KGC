"""Invertible blockwise Householder-Shear relation transforms."""

import torch.nn.functional as F


def _group(value, group_dim, operation_name):
    if group_dim < 2:
        raise ValueError('%s requires group_dim >= 2' % operation_name)
    if value.size(-1) % group_dim != 0:
        raise ValueError(
            '%s requires the last dimension to be divisible by group_dim'
            % operation_name
        )
    return value.reshape(*value.shape[:-1], -1, group_dim)


def _normalized_axes(first_axis, second_axis, group_dim, epsilon):
    first = F.normalize(
        _group(first_axis, group_dim, 'HouseholderShear'),
        p=2, dim=-1, eps=epsilon
    )
    second = F.normalize(
        _group(second_axis, group_dim, 'HouseholderShear'),
        p=2, dim=-1, eps=epsilon
    )
    orthogonal = second - (
        first * second
    ).sum(dim=-1, keepdim=True) * first
    orthogonal = F.normalize(
        orthogonal, p=2, dim=-1, eps=epsilon
    )
    return first, second, orthogonal


def _reflection(value, axis):
    return value - 2.0 * (
        value * axis
    ).sum(dim=-1, keepdim=True) * axis


def apply_householder_shear(
        value, first_axis, second_axis, shear, group_dim,
        epsilon=1e-9):
    """Apply a volume-preserving shear followed by two reflections."""
    grouped = _group(value, group_dim, 'HouseholderShear')
    first, second, shear_axis = _normalized_axes(
        first_axis, second_axis, group_dim, epsilon
    )
    shear = shear.unsqueeze(1).unsqueeze(-1)

    grouped = grouped + shear * (
        grouped * first
    ).sum(dim=-1, keepdim=True) * shear_axis
    grouped = _reflection(grouped, first)
    grouped = _reflection(grouped, second)
    return grouped.reshape_as(value)
