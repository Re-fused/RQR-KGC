"""Closed-form endpoint maps in TransERR's component-major coordinates."""

import math

import torch


def _components(value):
    if value.ndim < 1 or value.size(-1) < 4 or value.size(-1) % 4:
        raise ValueError('Expected a positive width divisible by four')
    if value.dtype not in (torch.float32, torch.float64):
        raise ValueError('Endpoint operators require float32 or float64')
    return value.chunk(4, dim=-1)


def kerr_phases(value, coefficients, intensity_scale):
    """Coefficients have [..., self/cross, block] axes and are already bounded."""
    q0, q1, q2, q3 = _components(value)
    if (coefficients.ndim < 2 or coefficients.shape[-2:] != (2, q0.size(-1))
            or coefficients.dtype != value.dtype or coefficients.device != value.device):
        raise ValueError('Kerr coefficients must match block width, dtype and device')
    scale_squared = float(intensity_scale) * float(intensity_scale)
    if (not math.isfinite(intensity_scale) or intensity_scale <= 0
            or not math.isfinite(scale_squared)
            or scale_squared < torch.finfo(value.dtype).tiny):
        raise ValueError('Kerr intensity scale must be finite, positive and representable')
    e1 = q0.square() + q1.square()
    e2 = q2.square() + q3.square()
    e1 = e1 / (e1 + scale_squared)
    e2 = e2 / (e2 + scale_squared)
    self_phase, cross_phase = coefficients.unbind(dim=-2)
    return (self_phase * e1 + cross_phase * e2,
            self_phase * e2 + cross_phase * e1)


def kerr_transform(value, coefficients, intensity_scale, inverse=False):
    """Rotate two complex channels by their own and each other's intensities."""
    q0, q1, q2, q3 = _components(value)
    phase1, phase2 = kerr_phases(value, coefficients, intensity_scale)
    if inverse:
        phase1, phase2 = -phase1, -phase2
    c1, s1 = phase1.cos(), phase1.sin()
    c2, s2 = phase2.cos(), phase2.sin()
    return torch.cat((q0 * c1 - q1 * s1, q0 * s1 + q1 * c1,
                      q2 * c2 - q3 * s2, q2 * s2 + q3 * c2), dim=-1)


def fold_transform(value):
    """Fold one coordinate per quaternion, retaining the other three."""
    q0, q1, q2, q3 = _components(value)
    return torch.cat((q0, q1, q2, q3.abs()), dim=-1)


@torch.no_grad()
def nonlinear_endpoint_diagnostics(model, relation_names=None, sample_size=128):
    """No triples, random draws, mode changes, or training-state mutations."""
    if model.model_name not in ('KerrTransERR', 'FoldTransERR'):
        raise ValueError('Diagnostics require KerrTransERR or FoldTransERR')
    if sample_size < 1:
        raise ValueError('sample_size must be positive')
    names = relation_names or {}
    count = min(sample_size, model.nentity)
    indices = torch.arange(count, device=model.entity_embedding.device)
    indices = indices * model.nentity // count
    entities = model.entity_embedding.index_select(0, indices).unsqueeze(0)
    report = {'model': model.model_name, 'scope': 'deterministic_entity_sample',
              'entity_ids': indices.cpu().tolist(), 'quaternion_blocks': model.entity_dim // 4,
              'relations': []}
    if model.model_name == 'KerrTransERR':
        coefficients = model.effective_kerr_coefficients()
        report.update(intensity_scale=model.kerr_intensity_scale,
                      phase_bound=model.kerr_phase_bound)
    for rid in range(model.nrelation):
        wh, _, wt = model.relation_embedding[rid:rid + 1].unsqueeze(1).chunk(3, dim=-1)
        row = {'relation_id': rid, 'relation': names.get(rid, str(rid))}
        for side, frame in enumerate((wh, wt)):
            value = model._calc(entities, model.q_norm(frame))
            if model.model_name == 'KerrTransERR':
                params = coefficients[rid].select(0, side).unsqueeze(0).unsqueeze(0)
                phases = torch.stack(kerr_phases(value, params, model.kerr_intensity_scale), dim=-2)
                changed = kerr_transform(value, params, model.kerr_intensity_scale)
                restored = kerr_transform(changed, params, model.kerr_intensity_scale, inverse=True)
                stats = {
                    'mean_absolute_phase_radians': phases.abs().mean().item(),
                    'max_absolute_phase_radians': phases.abs().max().item(),
                    # Measure variation across entities, not across learned blocks.
                    'mean_entity_phase_std_radians': phases.std(dim=1, unbiased=False).mean().item(),
                    'inverse_max_absolute_error': (restored - value).abs().max().item(),
                }
            else:
                changed = fold_transform(value)
                stats = {'negative_fold_coordinate_fraction':
                         (value.chunk(4, dim=-1)[3] < 0).float().mean().item()}
            stats['max_squared_norm_error'] = (
                changed.square().sum(-1) - value.square().sum(-1)).abs().max().item()
            row[('head', 'tail')[side]] = stats
        report['relations'].append(row)
    return report
