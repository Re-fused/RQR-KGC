"""Low-rank two-sided quaternion operators."""

import torch

from models.quaternion import hamilton_product, normalize_quaternion


def rank_quaternion_transform(
        value, base_operator, left_operators, right_operators,
        coefficient_logits, coefficient_bound):
    """Apply a Hamilton action plus bounded two-sided residual actions.

    Operator tensors carry an explicit rank axis immediately before the
    quaternion-component axis. Coefficients contain one value per quaternion
    coordinate block and are shared across that block's four components.
    """
    if value.size(-1) % 4 != 0:
        raise ValueError('quaternion width must be divisible by 4')
    if coefficient_bound <= 0.0:
        raise ValueError('coefficient_bound must be positive')
    if left_operators.shape != right_operators.shape:
        raise ValueError('left and right operator shapes must match')
    if left_operators.size(-1) != value.size(-1):
        raise ValueError('operator and entity widths must match')
    if coefficient_logits.size(-2) != left_operators.size(-2):
        raise ValueError('coefficient and operator ranks must match')
    if coefficient_logits.size(-1) * 4 != value.size(-1):
        raise ValueError(
            'coefficients must provide one value per quaternion block'
        )

    direct = hamilton_product(value, base_operator)
    coefficients = coefficient_bound * torch.tanh(coefficient_logits)
    residual = torch.zeros_like(direct)
    for term in range(left_operators.size(-2)):
        left = normalize_quaternion(left_operators[:, :, term, :])
        right = normalize_quaternion(right_operators[:, :, term, :])
        two_sided = hamilton_product(
            hamilton_product(left, value), right
        )
        coefficient = torch.cat([
            coefficients[:, :, term, :]
        ] * 4, dim=-1)
        residual = residual + coefficient * two_sided
    return direct + residual


def geodesic_rank_quaternion_transform(
        value, base_operator, left_operators, right_operators,
        angle_logits, angle_bound, epsilon=1e-9):
    """Deflect a Hamilton action along norm-preserving S3 geodesics."""
    if value.size(-1) % 4 != 0:
        raise ValueError('quaternion width must be divisible by 4')
    if angle_bound <= 0.0:
        raise ValueError('angle_bound must be positive')
    if epsilon <= 0.0:
        raise ValueError('epsilon must be positive')
    if left_operators.shape != right_operators.shape:
        raise ValueError('left and right operator shapes must match')
    if left_operators.size(-1) != value.size(-1):
        raise ValueError('operator and entity widths must match')
    if angle_logits.size(-2) != left_operators.size(-2):
        raise ValueError('angle and operator ranks must match')
    if angle_logits.size(-1) * 4 != value.size(-1):
        raise ValueError('angles must provide one value per quaternion block')

    transformed = hamilton_product(value, base_operator)
    for term in range(left_operators.size(-2)):
        left = normalize_quaternion(left_operators[:, :, term, :])
        right = normalize_quaternion(right_operators[:, :, term, :])
        direction = hamilton_product(
            hamilton_product(left, value), right
        )

        transformed_parts = torch.chunk(transformed, 4, dim=2)
        direction_parts = torch.chunk(direction, 4, dim=2)
        raw_norm_squared = sum(
            part.square() for part in transformed_parts
        )
        norm_squared = raw_norm_squared.clamp_min(epsilon)
        projection_scale = sum(
            base * candidate
            for base, candidate in zip(
                transformed_parts, direction_parts
            )
        ) / norm_squared
        tangent_parts = [
            candidate - projection_scale * base
            for base, candidate in zip(
                transformed_parts, direction_parts
            )
        ]
        tangent_norm_squared = sum(
            part.square() for part in tangent_parts
        )
        tangent_norm = torch.sqrt(
            tangent_norm_squared.clamp_min(epsilon)
        )
        transformed_norm = torch.sqrt(norm_squared)
        tangent_parts = [
            transformed_norm * part / tangent_norm
            for part in tangent_parts
        ]

        angle = angle_bound * torch.tanh(
            angle_logits[:, :, term, :]
        )
        valid_tangent = (
            (raw_norm_squared > epsilon)
            & (tangent_norm_squared > epsilon)
        )
        angle = angle * valid_tangent.to(angle.dtype)
        cosine = torch.cos(angle)
        sine = torch.sin(angle)
        transformed = torch.cat([
            cosine * base + sine * tangent
            for base, tangent in zip(
                transformed_parts, tangent_parts
            )
        ], dim=2)
    return transformed
