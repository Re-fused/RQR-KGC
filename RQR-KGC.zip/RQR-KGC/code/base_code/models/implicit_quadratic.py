"""Low-rank, jointly conditioned quadratic constraints in TransERR coordinates."""

import torch
import torch.nn.functional as F


def quadratic_features(source, target, source_projection, target_projection,
                       self_coefficients, scale, cross_weight=1., self_weight=1.):
    """Projection rows have unit norm; features are dimensionless polynomials."""
    source_projection = F.normalize(source_projection, p=2, dim=-1, eps=1e-12)
    target_projection = F.normalize(target_projection, p=2, dim=-1, eps=1e-12)
    a = torch.einsum('bnd,bkd->bnk', source, source_projection) / scale
    b = torch.einsum('bnd,bkd->bnk', target, target_projection) / scale
    alpha, beta = self_coefficients.unbind(dim=1)
    return cross_weight * a * b + self_weight * (
        alpha.unsqueeze(1) * a.square() + beta.unsqueeze(1) * b.square())


def quadratic_correction(source, target, source_projection, target_projection,
                         output_map, self_coefficients, scale,
                         cross_weight=1., self_weight=1.):
    features = quadratic_features(source, target, source_projection, target_projection,
                                  self_coefficients, scale, cross_weight, self_weight)
    return scale * torch.einsum('bnk,bdk->bnd', features, output_map)


@torch.no_grad()
def quadratic_diagnostics(model, sample_size=32):
    if model.model_name != 'ImplicitQuadraticTransERR' or sample_size < 1:
        raise ValueError('Expected an implicit quadratic model and a positive sample size')
    count = min(model.nentity, sample_size)
    ids = torch.arange(count, device=model.entity_embedding.device) * model.nentity // count
    head = model.entity_embedding[ids].unsqueeze(0)
    tail = model.entity_embedding[ids.roll(1)].unsqueeze(0)
    rows = []
    for rid in range(model.nrelation):
        wh, translation, wt = model.relation_embedding[rid].view(1, 1, -1).chunk(3, -1)
        x, y = model._calc(head, model.q_norm(wh)), model._calc(tail, model.q_norm(wt))
        correction = model.quadratic_endpoint_correction(x, y, torch.tensor([rid], device=ids.device))
        residual = x + translation - y
        rows.append({'relation_id': rid, 'mean_absolute_correction': correction.abs().mean().item(),
                     'correction_to_residual_l1_ratio': (correction.abs().sum() /
                         residual.abs().sum().clamp_min(1e-12)).item(),
                     'source_projection_norm_min': model.quadratic_source_projection[rid].norm(dim=-1).min().item(),
                     'target_projection_norm_min': model.quadratic_target_projection[rid].norm(dim=-1).min().item()})
    return {'model': model.model_name, 'scope': 'deterministic_embedding_sample_not_metrics',
            'rank': model.quadratic_rank, 'bound': model.quadratic_bound,
            'scale': model.quadratic_scale, 'cross_weight': model.quadratic_cross_weight,
            'self_weight': model.quadratic_self_weight, 'relations': rows}
