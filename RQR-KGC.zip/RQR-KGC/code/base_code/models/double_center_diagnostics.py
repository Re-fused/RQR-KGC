"""Read-only center diagnostics using training positives only."""

import torch

from .double_center import quaternion_group_l1


@torch.no_grad()
def double_center_diagnostics(model, train_triples, relation_names=None,
                              batch_size=512, regularization=0.4,
                              center_regularization=0.0001):
    if model.model_name != 'DoubleCenterTransERR':
        raise ValueError('Center diagnostics require DoubleCenterTransERR')
    if batch_size <= 0:
        raise ValueError('batch_size must be positive')
    device = model.entity_embedding.device
    offsets = model.center_offset.detach()
    nrelation = offsets.size(0)
    groups = getattr(model, 'double_center_groups', 1)
    local_temperature = model.double_center_temperature / groups
    # Direct tensor batches avoid consuming the training DataLoader RNG.
    counts = torch.zeros(nrelation, device=device, dtype=torch.long)
    sums = torch.zeros(nrelation, groups, 5, device=device, dtype=torch.float64)
    for begin in range(0, len(train_triples), batch_size):
        triples = torch.as_tensor(train_triples[begin:begin + batch_size],
                                  device=device, dtype=torch.long)
        ids = triples[:, 1]
        head = model.entity_embedding[triples[:, 0]].unsqueeze(1)
        tail = model.entity_embedding[triples[:, 2]].unsqueeze(1)
        wh, translation, wt = model.relation_embedding[ids].unsqueeze(1).chunk(3, dim=2)
        residual = (model._calc(head, model.q_norm(wh)) + translation
                    - model._calc(tail, model.q_norm(wt)))
        offset = offsets[ids].unsqueeze(1)
        if groups == 1:
            minus = (residual - offset).abs().sum(-1)
            plus = (residual + offset).abs().sum(-1)
        else:
            minus = quaternion_group_l1(residual - offset, groups).squeeze(1)
            plus = quaternion_group_l1(residual + offset, groups).squeeze(1)
        probability = torch.sigmoid((plus - minus) / local_temperature)
        clipped = probability.clamp(1e-7, 1.0 - 1e-7)
        entropy = -(clipped * clipped.log() + (1.0 - clipped) * (1.0 - clipped).log())
        values = torch.stack((probability, (minus < plus).to(probability.dtype),
                              ((probability < 0.05) | (probability > 0.95)).to(probability.dtype),
                              entropy, (plus - minus).abs()), dim=-1)
        counts.index_add_(0, ids, torch.ones_like(ids))
        sums.index_add_(0, ids, values.to(sums.dtype))

    translation = model.relation_embedding.detach().chunk(3, dim=1)[1]
    offset_squared = offsets.square().sum(-1)
    translation_squared = translation.square().sum(-1)
    entity_squared = model.entity_embedding.detach().square().sum(-1)
    base_raw = torch.cat((entity_squared, translation_squared)).mean().item()
    center_raw = offset_squared.mean().item()
    counts = counts.cpu().tolist()
    group_sums = sums.cpu().tolist()
    sums = sums.mean(dim=1).cpu().tolist()
    group_offset_norms = quaternion_group_l1(offsets.square(), groups).sqrt().cpu().tolist()
    group_translation_norms = quaternion_group_l1(translation.square(), groups).sqrt().cpu().tolist()
    offset_norms = offset_squared.sqrt().cpu().tolist()
    translation_norms = translation_squared.sqrt().cpu().tolist()
    rows = []
    for rid, count in enumerate(counts):
        means = [value / count if count else None for value in sums[rid]]
        rows.append({
            'relation_id': rid,
            'relation': relation_names[rid] if relation_names is not None else str(rid),
            'train_count': count,
            'offset_l2_norm': offset_norms[rid],
            'center_separation_l2': 2.0 * offset_norms[rid],
            'translation_l2_norm': translation_norms[rid],
            'mean_minus_posterior': means[0],
            'minus_winner_fraction': means[1],
            'confident_fraction': means[2],
            'mean_posterior_entropy_nats': means[3],
            'mean_absolute_distance_gap': means[4],
        })
        if groups > 1:
            rows[-1]['groups'] = [{
                'group_id': gid,
                'center_separation_l2': 2.0 * group_offset_norms[rid][gid],
                'translation_l2_norm': group_translation_norms[rid][gid],
                'mean_minus_posterior': totals[0] / count if count else None,
                'minus_winner_fraction': totals[1] / count if count else None,
                'confident_fraction': totals[2] / count if count else None,
                'mean_posterior_entropy_nats': totals[3] / count if count else None,
                'mean_absolute_distance_gap': totals[4] / count if count else None,
            } for gid, totals in enumerate(group_sums[rid])]
    return {
        'split': 'train',
        'num_triples': sum(counts),
        'temperature': model.double_center_temperature,
        'center_groups': groups,
        'local_temperature': local_temperature,
        'base_regularization_raw': base_raw,
        'base_regularization_weighted': regularization * base_raw,
        'center_regularization_raw': center_raw,
        'center_regularization_weighted': center_regularization * center_raw,
        'center_rms_l2_norm': center_raw ** 0.5,
        'relations': rows,
    }
