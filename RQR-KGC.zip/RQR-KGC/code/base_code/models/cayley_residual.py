"""Stable full- and rank-two generators for residual Cayley rotations."""

import torch


def full_plane_coefficients(raw_generator, parameter_scale):
    """Decode six bounded plane coefficients per four-dimensional block."""
    if raw_generator.size(-1) % 6 != 0:
        raise ValueError(
            'Full Cayley residual generators require six channels per block'
        )
    scale = torch.as_tensor(
        parameter_scale,
        dtype=raw_generator.dtype,
        device=raw_generator.device,
    ).clamp_min(1e-9)
    return tuple(
        torch.tanh(part / scale)
        for part in torch.chunk(raw_generator, 6, dim=-1)
    )


def rank2_plane_coefficients(raw_generator, epsilon=1e-9):
    """Decode one oriented two-plane per four-dimensional block."""
    if raw_generator.size(-1) % 8 != 0:
        raise ValueError(
            'Rank-two Cayley residual generators require eight channels '
            'per block'
        )
    parts = torch.chunk(raw_generator, 8, dim=-1)
    raw_u = parts[:4]
    raw_v = parts[4:]

    u_norm = torch.sqrt(sum(part.square() for part in raw_u)).clamp_min(
        epsilon
    )
    u = tuple(part / u_norm for part in raw_u)
    projection = sum(u_part * v_part for u_part, v_part in zip(u, raw_v))
    orthogonal_v = tuple(
        v_part - projection * u_part
        for u_part, v_part in zip(u, raw_v)
    )
    v_norm = torch.sqrt(
        sum(part.square() for part in orthogonal_v)
    )

    # Parallel raw vectors are rare, but a deterministic orthogonal fallback
    # keeps the parameterization finite for checkpoints and unit tests.
    stacked_u = torch.stack(u, dim=-1)
    fallback_index = torch.argmin(torch.abs(stacked_u), dim=-1)
    basis = torch.nn.functional.one_hot(
        fallback_index, num_classes=4
    ).to(stacked_u.dtype)
    fallback = basis - torch.sum(
        basis * stacked_u, dim=-1, keepdim=True
    ) * stacked_u
    fallback = fallback / torch.linalg.vector_norm(
        fallback, dim=-1, keepdim=True
    ).clamp_min(epsilon)

    normalized_v = torch.stack(orthogonal_v, dim=-1) / v_norm.clamp_min(
        epsilon
    ).unsqueeze(-1)
    use_raw_v = (v_norm > epsilon).unsqueeze(-1)
    v = torch.where(use_raw_v, normalized_v, fallback).unbind(dim=-1)

    coefficients = []
    for first, second in ((0, 1), (0, 2), (0, 3),
                          (1, 2), (1, 3), (2, 3)):
        coefficients.append(
            u[first] * v[second] - v[first] * u[second]
        )
    return tuple(coefficients)


def pack_cayley_generator(coefficients, parameter_scale, gate):
    """Pack dimensionless plane coefficients for the legacy Cayley helper."""
    if len(coefficients) != 6:
        raise ValueError('Cayley residuals require exactly six planes')
    scale = torch.as_tensor(
        parameter_scale,
        dtype=coefficients[0].dtype,
        device=coefficients[0].device,
    )
    scaled = [scale * gate * coefficient for coefficient in coefficients]
    return torch.cat(scaled[:4], dim=-1), torch.cat(scaled[4:], dim=-1)
