"""Blockwise port-Hamiltonian relation dynamics.

The operation in this module is deliberately stateless.  ``KGEModel`` owns
the relation parameters so historical checkpoint naming remains stable.
"""

import torch


def skew_symmetric_matrix(coefficients, block_dim):
    """Pack upper-triangular coefficients into skew-symmetric matrices."""
    expected_width = block_dim * (block_dim - 1) // 2
    if coefficients.size(-1) != expected_width:
        raise ValueError(
            'expected %d skew coefficients for block_dim=%d, got %d'
            % (expected_width, block_dim, coefficients.size(-1))
        )

    row, column = torch.triu_indices(
        block_dim,
        block_dim,
        offset=1,
        device=coefficients.device,
    )
    matrix = coefficients.new_zeros(
        coefficients.shape[:-1] + (block_dim, block_dim)
    )
    matrix[..., row, column] = coefficients
    matrix[..., column, row] = -coefficients
    return matrix


def port_hamiltonian_flow(
        value, skew_coefficients, damping, nonlinear, block_dim, steps):
    """Integrate a bounded blockwise port-Hamiltonian vector field.

    For each block, the Hamiltonian and its gradient are

        H(x) = 0.5 * ||x||^2 + sum(beta * log(cosh(x)))
        grad H(x) = x + beta * tanh(x)

    The vector field is ``dx/dt = (J - R) grad H(x)``, where ``J`` is
    skew-symmetric and ``R`` is diagonal and non-negative.  A fixed-step
    explicit integrator keeps the operation inexpensive for large negative
    batches; parameter bounds control its stability.
    """
    if value.size(-1) % block_dim != 0:
        raise ValueError('value width must be divisible by block_dim')
    if steps <= 0:
        raise ValueError('steps must be positive')

    block_count = value.size(-1) // block_dim
    expected_shape = (value.size(0), block_count, block_dim)
    if damping.shape != expected_shape:
        raise ValueError(
            'damping shape must be %s, got %s'
            % (expected_shape, tuple(damping.shape))
        )
    if nonlinear.shape != expected_shape:
        raise ValueError(
            'nonlinear shape must be %s, got %s'
            % (expected_shape, tuple(nonlinear.shape))
        )

    generator = skew_symmetric_matrix(skew_coefficients, block_dim)
    state = value.reshape(
        value.size(0), value.size(1), block_count, block_dim
    )
    damping = damping.unsqueeze(1)
    nonlinear = nonlinear.unsqueeze(1)
    time_step = 1.0 / float(steps)

    for _ in range(steps):
        energy_gradient = state + nonlinear * torch.tanh(state)
        conservative = torch.einsum(
            'bkij,bnkj->bnki', generator, energy_gradient
        )
        state = state + time_step * (
            conservative - damping * energy_gradient
        )

    return state.reshape_as(value)


def cayley_split_port_hamiltonian_flow(
        value, skew_coefficients, damping, nonlinear, block_dim, steps,
        relation_index=None):
    """Integrate port-Hamiltonian dynamics with a stable split step.

    The linear conservative field uses a Cayley transform, the linear
    dissipative field uses its exact diagonal exponential, and the bounded
    nonlinear field is applied in two symmetric half steps.  Parameters may
    be supplied once per unique relation; ``relation_index`` then expands the
    resulting operators to the batch without repeating matrix solves.
    """
    if value.size(-1) % block_dim != 0:
        raise ValueError('value width must be divisible by block_dim')
    if steps <= 0:
        raise ValueError('steps must be positive')

    block_count = value.size(-1) // block_dim
    parameter_batch = skew_coefficients.size(0)
    expected_shape = (parameter_batch, block_count, block_dim)
    if damping.shape != expected_shape:
        raise ValueError(
            'damping shape must be %s, got %s'
            % (expected_shape, tuple(damping.shape))
        )
    if nonlinear.shape != expected_shape:
        raise ValueError(
            'nonlinear shape must be %s, got %s'
            % (expected_shape, tuple(nonlinear.shape))
        )
    if relation_index is None:
        if parameter_batch != value.size(0):
            raise ValueError('parameter and value batch sizes must match')
        relation_index = torch.arange(
            value.size(0), device=value.device, dtype=torch.long
        )
    elif relation_index.shape != (value.size(0),):
        raise ValueError('relation_index must have shape [batch]')

    generator_table = skew_symmetric_matrix(
        skew_coefficients, block_dim
    )
    state = value.reshape(
        value.size(0), value.size(1), block_count, block_dim
    )
    time_step = 1.0 / float(steps)
    identity = torch.eye(
        block_dim, device=value.device, dtype=value.dtype
    ).view(1, 1, block_dim, block_dim)
    cayley_table = torch.linalg.solve(
        identity - 0.5 * time_step * generator_table,
        identity + 0.5 * time_step * generator_table,
    )
    generator = generator_table.index_select(0, relation_index)
    cayley = cayley_table.index_select(0, relation_index)
    damping = damping.index_select(0, relation_index).unsqueeze(1)
    nonlinear = nonlinear.index_select(0, relation_index).unsqueeze(1)
    damping_half_step = torch.exp(-0.5 * time_step * damping)

    def nonlinear_half_step(current):
        nonlinear_gradient = nonlinear * torch.tanh(current)
        conservative = torch.einsum(
            'bkij,bnkj->bnki', generator, nonlinear_gradient
        )
        return current + 0.5 * time_step * (
            conservative - damping * nonlinear_gradient
        )

    for _ in range(steps):
        state = nonlinear_half_step(state)
        state = damping_half_step * state
        state = torch.einsum('bkij,bnkj->bnki', cayley, state)
        state = damping_half_step * state
        state = nonlinear_half_step(state)

    return state.reshape_as(value)


def laplace_endpoint_distance(residual, log_scale):
    """Return diagonal Laplace negative log-likelihood without constants."""
    if log_scale.dim() != 3:
        raise ValueError('log_scale must have shape [batch, blocks, width]')
    flat_log_scale = log_scale.reshape(log_scale.size(0), 1, -1)
    if flat_log_scale.size(-1) != residual.size(-1):
        raise ValueError('log_scale and residual widths must match')
    weighted_l1 = torch.norm(
        residual * torch.exp(-flat_log_scale), p=1, dim=-1
    )
    return weighted_l1 + flat_log_scale.sum(dim=-1)
