"""Two translation centers in one shared TransERR relation frame."""

import math

import torch


def quaternion_group_l1(value, groups):
    """Sum intact quaternions in component-major [s, x, y, z] storage."""
    width = value.size(-1)
    if not isinstance(groups, int) or isinstance(groups, bool) or groups < 1:
        raise ValueError('Center groups must be a positive integer')
    if width % (4 * groups):
        raise ValueError('Entity width must be divisible by 4 * center groups')
    grouped = value.reshape(*value.shape[:-1], 4, groups, width // (4 * groups))
    return grouped.abs().sum(dim=-1).sum(dim=-2)


def grouped_double_center_distance(residual, offset, temperature, groups=1):
    """Independent two-center choices with a fixed total smoothing budget."""
    if groups == 1:
        return double_center_distance(residual, offset, temperature)
    near = quaternion_group_l1(residual - offset, groups)
    far = quaternion_group_l1(residual + offset, groups)
    local_temperature = temperature / groups
    # This is the same normalized softmin, without large distance/temperature
    # logits: min + T * (log(2) - log(1 + exp(-abs(gap) / T))).
    correction = -local_temperature * torch.log1p(
        0.5 * torch.expm1(-(near - far).abs() / local_temperature))
    return (torch.minimum(near, far) + correction).sum(dim=-1)


def double_center_distance(residual, offset, temperature):
    """Normalized soft minimum of the two full-vector L1 distances.

    The center is selected for the whole embedding, not independently for
    each coordinate. The log(2) correction recovers TransERR at zero offset.
    """
    near = (residual - offset).abs().sum(dim=-1)
    far = (residual + offset).abs().sum(dim=-1)
    logits = torch.stack((-near / temperature, -far / temperature), dim=-1)
    return -temperature * (torch.logsumexp(logits, dim=-1) - math.log(2.0))
