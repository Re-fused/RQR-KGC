"""Relation-adaptive four-component Clifford products."""

import torch

from models.quaternion import hamilton_product


def adaptive_metric_clifford_product(left, right, signature):
    """Multiply blocks in Cl(diag(-1, signature)).

    Components use the basis ``(1, e1, e2, e12)`` with
    ``e1^2 = -1``, ``e2^2 = signature`` and ``e1*e2 = -e2*e1``.
    A signature of -1 is exactly the Hamilton product, zero is a
    degenerate Clifford product, and a positive signature is split type.
    """
    if left.size(-1) % 4 != 0 or right.size(-1) % 4 != 0:
        raise ValueError(
            'adaptive metric Clifford operands must be divisible by 4'
        )

    if not torch.is_tensor(signature):
        signature = left.new_tensor(signature)
    else:
        signature = signature.to(device=left.device, dtype=left.dtype)

    scalar_a, x_a, y_a, z_a = torch.chunk(left, 4, dim=-1)
    _, _, y_b, z_b = torch.chunk(right, 4, dim=-1)
    while signature.dim() < scalar_a.dim():
        signature = signature.unsqueeze(-1)

    # Express the generalized product as an exact residual around the
    # Hamilton product. At signature == -1 the correction is exactly zero,
    # while its derivative with respect to the signature remains nonzero.
    zero = torch.zeros_like(scalar_a)
    correction = torch.cat([
        y_a * y_b + z_a * z_b,
        -y_a * z_b + z_a * y_b,
        zero,
        zero,
    ], dim=-1)
    return hamilton_product(left, right) + (signature + 1.0) * correction
