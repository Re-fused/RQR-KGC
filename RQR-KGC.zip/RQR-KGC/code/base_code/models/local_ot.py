"""Candidate-conditioned, mass-preserving local transport for TransERR."""

from functools import lru_cache
import math
import os
from pathlib import Path
import sys

import torch
from torch.autograd.function import once_differentiable


@lru_cache(maxsize=1)
def _pot_solver():
    # Keep this optional dependency out of every other model's import path.
    local = Path(__file__).resolve().parents[2] / '.local_deps/pot-0.9.7.post1'
    if local.is_dir():
        sys.path.insert(0, str(local))
    for backend in ('JAX', 'TENSORFLOW', 'CUPY'):
        os.environ.setdefault('POT_BACKEND_DISABLE_' + backend, '1')
    try:
        from ot.batch import solve_batch
    except ImportError as error:
        raise ImportError('LocalOTTransERR requires POT==0.9.7.post1; see LOCAL_OT_TRANSERR.md') from error
    return solve_batch


def validate_local_ot(width, window, temperature, prior_mix, chunk_size, max_iter, tolerance):
    if not isinstance(window, int) or window < 2 or width < 4 or width % (4 * window):
        raise ValueError('Local OT width must be divisible by four times window size (>=2)')
    if not math.isfinite(temperature) or temperature <= 0:
        raise ValueError('Local OT temperature must be finite and positive')
    if not math.isfinite(prior_mix) or not 0 < prior_mix <= 1:
        raise ValueError('Local OT prior mix must be in (0, 1]')
    if not isinstance(chunk_size, int) or chunk_size < 1:
        raise ValueError('Local OT chunk size must be a positive integer')
    if not isinstance(max_iter, int) or max_iter < 1:
        raise ValueError('Local OT max iterations must be a positive integer')
    if not math.isfinite(tolerance) or not 0 < tolerance < .01:
        raise ValueError('Local OT marginal tolerance must be in (0, .01)')


def local_windows(value, window):
    """[B,N,4*G*K] component-major -> [B*N*G,K,4], not consecutive scalars."""
    batch, candidates, width = value.shape
    groups = width // (4 * window)
    return value.reshape(batch, candidates, 4, groups, window).permute(
        0, 1, 3, 4, 2).contiguous().reshape(-1, window, 4)


def pair_cost(left, right):
    cost = (left[:, :, None, 0] - right[:, None, :, 0]).abs()
    for component in range(1, 4):
        cost = cost + (left[:, :, None, component] - right[:, None, :, component]).abs()
    return cost


def transport_plan(cost, temperature=.1, prior_mix=.2, max_iter=128, tolerance=1e-5):
    """Return P (row/column sums 1) and the full cost + tau*KL(P||Q)."""
    size = cost.size(-1)
    if cost.ndim != 3 or cost.size(-2) != size or size < 2:
        raise ValueError('Expected a batch of square local cost matrices')
    if cost.dtype not in (torch.float32, torch.float64):
        raise ValueError('Local OT requires float32 or float64')
    if not torch.isfinite(cost).all():
        raise RuntimeError('Local OT failed: nonfinite cost')
    validate_local_ot(4 * size, size, temperature, prior_mix, 1, max_iter, tolerance)
    prior = (1 - prior_mix) * torch.eye(size, dtype=cost.dtype, device=cost.device)
    prior = prior + prior_mix / size
    # POT uses mass-one T=P/K. Encoding Q/K in M retains the entire KL term.
    shifted = cost - temperature * (prior / size).log()
    with torch.no_grad():
        result = _pot_solver()(shifted, reg=temperature, method='log_sinkhorn',
                               reg_type='entropy', grad='envelope', max_iter=max_iter,
                               tol=tolerance / (2 * size))
        plan = result.plan * size
        error = torch.maximum((plan.sum(-1) - 1).abs().amax(-1),
                              (plan.sum(-2) - 1).abs().amax(-1))
        bad = (~torch.isfinite(plan).all(dim=-1).all(dim=-1)) | (error > tolerance)
        if bad.any():
            refined = _pot_solver()(shifted[bad], reg=temperature, method='log_sinkhorn',
                                    reg_type='entropy', grad='envelope',
                                    max_iter=max(2048, max_iter * 4),
                                    tol=tolerance / (2 * size))
            plan[bad] = refined.plan * size
            error = torch.maximum((plan.sum(-1) - 1).abs().amax(-1),
                                  (plan.sum(-2) - 1).abs().amax(-1))
        bad = (~torch.isfinite(plan).all(dim=-1).all(dim=-1)) | (error > tolerance)
        if bad.any():
            # Rare sharp kernels need both more iterations and higher precision.
            high_cost, high_prior = cost[bad].double(), prior.double()
            refined = _pot_solver()(high_cost - temperature * (high_prior / size).log(),
                                    reg=temperature, method='log_sinkhorn', reg_type='entropy',
                                    grad='envelope', max_iter=max(16384, max_iter * 8),
                                    tol=tolerance / (4 * size))
            plan[bad] = (refined.plan * size).to(cost.dtype)
            error = torch.maximum((plan.sum(-1) - 1).abs().amax(-1),
                                  (plan.sum(-2) - 1).abs().amax(-1))
        if not torch.isfinite(plan).all() or error.max() > tolerance:
            raise RuntimeError('Local OT failed its marginal/finite check (max error=%g); no invalid score returned'
                               % error.max().item())
    # Envelope derivative dD/dC=P; do not differentiate the iterative solver.
    kl = (plan * (plan.clamp_min(torch.finfo(plan.dtype).tiny).log() - prior.log())).sum((-1, -2))
    value = (plan * cost).sum((-1, -2)) + temperature * kl
    return plan, value


def _indices(start, end, candidates, groups, left_count, right_count, device):
    index = torch.arange(start, end, device=device)
    group = index % groups
    pair = index // groups
    batch, candidate = pair // candidates, pair % candidates
    left = (batch * left_count + (candidate if left_count > 1 else 0)) * groups + group
    right = (batch * right_count + (candidate if right_count > 1 else 0)) * groups + group
    return left, right, pair


class _LocalDistance(torch.autograd.Function):
    """Chunk both passes; retain plans, not Sinkhorn graphs or K*K*4 differences."""

    @staticmethod
    def forward(ctx, left, right, window, temperature, prior_mix, chunk_size, max_iter, tolerance):
        batch, left_count, width = left.shape
        right_count = right.size(1)
        candidates, groups = max(left_count, right_count), width // (4 * window)
        x, y = local_windows(left, window), local_windows(right, window)
        total = batch * candidates * groups
        values = left.new_empty(total)
        needs_backward = ctx.needs_input_grad[0] or ctx.needs_input_grad[1]
        plans = left.new_empty((total, window, window)) if needs_backward else None
        for start in range(0, total, chunk_size):
            end = min(start + chunk_size, total)
            ix, iy, _ = _indices(start, end, candidates, groups, left_count, right_count, left.device)
            plan, value = transport_plan(pair_cost(x[ix], y[iy]), temperature, prior_mix, max_iter, tolerance)
            values[start:end] = value
            if plans is not None:
                plans[start:end] = plan
        if needs_backward:
            ctx.save_for_backward(x, y, plans)
            ctx.layout = batch, candidates, groups, window, left_count, right_count, chunk_size
        return values.reshape(batch, candidates, groups).sum(-1)

    @staticmethod
    @once_differentiable
    def backward(ctx, grad_output):
        x, y, plans = ctx.saved_tensors
        batch, candidates, groups, window, left_count, right_count, chunk_size = ctx.layout
        dx, dy = torch.zeros_like(x), torch.zeros_like(y)
        total = plans.size(0)
        for start in range(0, total, chunk_size):
            end = min(start + chunk_size, total)
            ix, iy, pair = _indices(start, end, candidates, groups, left_count, right_count, x.device)
            left, right = x[ix], y[iy]
            weight = plans[start:end] * grad_output.reshape(-1)[pair, None, None]
            gx, gy = torch.empty_like(left), torch.empty_like(right)
            for component in range(4):
                signed = (left[:, :, None, component] - right[:, None, :, component]).sign()
                signed = signed * weight
                gx[:, :, component] = signed.sum(-1)
                gy[:, :, component] = -signed.sum(-2)
            dx.index_add_(0, ix, gx)
            dy.index_add_(0, iy, gy)
        def unpack(value, count):
            return value.reshape(batch, count, groups, window, 4).permute(
                0, 1, 4, 2, 3).reshape(batch, count, 4 * groups * window)
        return unpack(dx, left_count), unpack(dy, right_count), None, None, None, None, None, None


def local_ot_distance(left, right, window=5, temperature=.1, prior_mix=.2,
                      chunk_size=1048576, max_iter=128, tolerance=1e-5, identity=False):
    if (left.ndim != 3 or right.ndim != 3 or left.shape[0] != right.shape[0]
            or left.shape[-1] != right.shape[-1] or min(left.shape[:2] + right.shape[:2]) < 1
            or (left.size(1) != right.size(1) and min(left.size(1), right.size(1)) != 1)
            or left.device != right.device or left.dtype != right.dtype):
        raise ValueError('Local OT expects matching [B,1 or N,D] endpoints')
    if left.dtype not in (torch.float32, torch.float64):
        raise ValueError('Local OT requires float32 or float64')
    validate_local_ot(left.size(-1), window, temperature, prior_mix, chunk_size, max_iter, tolerance)
    if identity:
        return (left - right).norm(p=1, dim=-1)
    return _LocalDistance.apply(left, right, window, temperature, prior_mix, chunk_size, max_iter, tolerance)


@torch.no_grad()
def local_ot_diagnostics(model, sample_size=16):
    """Deterministic embedding sample; no validation/test triples or RNG draws."""
    if model.model_name != 'LocalOTTransERR' or sample_size < 1:
        raise ValueError('Expected LocalOTTransERR and a positive sample size')
    count = min(model.nentity, sample_size)
    ids = torch.arange(count, device=model.entity_embedding.device) * model.nentity // count
    head = model.entity_embedding[ids].unsqueeze(1)
    tail = model.entity_embedding[ids.roll(1)].unsqueeze(1)
    rows = []
    for rid in range(model.nrelation):
        wh, translation, wt = model.relation_embedding[rid].view(1, 1, -1).chunk(3, -1)
        left = model._calc(head, model.q_norm(wh)) + translation
        right = model._calc(tail, model.q_norm(wt))
        cost = pair_cost(local_windows(left, model.local_ot_window), local_windows(right, model.local_ot_window))
        if model.local_ot_identity:
            plan = torch.eye(model.local_ot_window, dtype=cost.dtype, device=cost.device).expand_as(cost)
            value = (plan * cost).sum((-1, -2))
        else:
            plan, value = transport_plan(cost, model.local_ot_temperature, model.local_ot_prior_mix,
                                         model.local_ot_max_iter, model.local_ot_tolerance)
        rows.append({'relation_id': rid, 'diagonal_mass_fraction': plan.diagonal(dim1=-2, dim2=-1).sum(-1).mean().item() / model.local_ot_window,
                     'max_row_error': (plan.sum(-1) - 1).abs().max().item(),
                     'max_column_error': (plan.sum(-2) - 1).abs().max().item(),
                     'mean_window_distance': value.mean().item()})
    return {'model': model.model_name, 'scope': 'deterministic_embedding_sample_not_metrics',
            'identity': model.local_ot_identity, 'window': model.local_ot_window,
            'temperature': model.local_ot_temperature, 'prior_mix': model.local_ot_prior_mix,
            'relations': rows}
