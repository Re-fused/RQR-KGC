"""Blockwise 2x2 matrix operations for matrix-algebra TransERR models."""

import math

import torch


def _matrix_parts(value, part_count, model_name):
    if value.size(-1) % part_count != 0:
        raise ValueError(
            '%s requires the last dimension to be divisible by %d'
            % (model_name, part_count)
        )
    return torch.chunk(value, part_count, dim=-1)


def normalize_real_matrix2(value, epsilon=1e-9):
    """Normalize each 2x2 real matrix to Frobenius norm sqrt(2)."""
    parts = _matrix_parts(value, 4, 'RealMatrix2TransERR')
    denominator = torch.sqrt(sum(part.square() for part in parts))
    scale = math.sqrt(2.0) / denominator.clamp_min(epsilon)
    return torch.cat([part * scale for part in parts], dim=-1)


def real_matrix2_product(left, right):
    """Multiply component-major 2x2 real matrix blocks as left @ right."""
    a00, a01, a10, a11 = _matrix_parts(
        left, 4, 'RealMatrix2TransERR'
    )
    b00, b01, b10, b11 = _matrix_parts(
        right, 4, 'RealMatrix2TransERR'
    )
    return torch.cat([
        a00 * b00 + a01 * b10,
        a00 * b01 + a01 * b11,
        a10 * b00 + a11 * b10,
        a10 * b01 + a11 * b11,
    ], dim=-1)


def normalize_complex_matrix2(value, epsilon=1e-9):
    """Normalize each 2x2 complex matrix to Frobenius norm sqrt(2)."""
    parts = _matrix_parts(value, 8, 'ComplexMatrix2TransERR')
    denominator = torch.sqrt(sum(part.square() for part in parts))
    scale = math.sqrt(2.0) / denominator.clamp_min(epsilon)
    return torch.cat([part * scale for part in parts], dim=-1)


def complex_matrix2_product(left, right):
    """Multiply component-major 2x2 complex matrix blocks as left @ right."""
    left_parts = _matrix_parts(left, 8, 'ComplexMatrix2TransERR')
    right_parts = _matrix_parts(right, 8, 'ComplexMatrix2TransERR')
    left_real = left_parts[:4]
    left_imag = left_parts[4:]
    right_real = right_parts[:4]
    right_imag = right_parts[4:]

    real_real = _real_matrix2_product_parts(left_real, right_real)
    imag_imag = _real_matrix2_product_parts(left_imag, right_imag)
    real_imag = _real_matrix2_product_parts(left_real, right_imag)
    imag_real = _real_matrix2_product_parts(left_imag, right_real)
    real = [rr - ii for rr, ii in zip(real_real, imag_imag)]
    imag = [ri + ir for ri, ir in zip(real_imag, imag_real)]
    return torch.cat(real + imag, dim=-1)


def residual_kronecker_branch_weights(logits, identity_floor=0.03):
    """Return convex branch weights with a non-vanishing identity path."""
    if logits.size(-1) != 3:
        raise ValueError('Residual Kronecker branch logits require width 3')
    if not 0.0 <= identity_floor < 1.0:
        raise ValueError('identity_floor must be in [0, 1)')

    weights = torch.softmax(logits, dim=-1)
    if identity_floor == 0.0:
        return weights
    identity = identity_floor + (1.0 - identity_floor) * weights[..., :1]
    matrix_branches = (1.0 - identity_floor) * weights[..., 1:]
    return torch.cat([identity, matrix_branches], dim=-1)


def residual_kronecker_complex_matrix2(
        value, right, left, branch_logits, identity_floor=0.03):
    """Mix X, X @ R, and L @ X @ R for each complex matrix block."""
    group_count = value.size(-1) // 8
    if value.size(-1) % 8 != 0:
        raise ValueError(
            'ResidualKroneckerComplexMatrix2TransERR requires the last '
            'dimension to be divisible by 8'
        )
    if branch_logits.size(-2) != group_count:
        raise ValueError(
            'Residual Kronecker branch logits do not match matrix blocks'
        )

    normalized_right = normalize_complex_matrix2(right)
    normalized_left = normalize_complex_matrix2(left)
    right_transformed = complex_matrix2_product(value, normalized_right)
    two_sided = complex_matrix2_product(
        normalized_left, right_transformed
    )

    weights = residual_kronecker_branch_weights(
        branch_logits, identity_floor
    )
    component_weights = torch.cat([weights] * 8, dim=-2).unsqueeze(-3)
    branches = torch.stack(
        [value, right_transformed, two_sided], dim=-1
    )
    return torch.sum(branches * component_weights, dim=-1)


def _real_matrix2_product_parts(left, right):
    a00, a01, a10, a11 = left
    b00, b01, b10, b11 = right
    return (
        a00 * b00 + a01 * b10,
        a00 * b01 + a01 * b11,
        a10 * b00 + a11 * b10,
        a10 * b01 + a11 * b11,
    )
