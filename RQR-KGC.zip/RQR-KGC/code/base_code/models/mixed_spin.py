"""Direct sum of independent Hamilton blocks and spin-3/2 blocks."""

import torch

from models.higher_spin import apply_spin_operator, right_hamilton_matrix, spin_operator
from models.quaternion import hamilton_product, normalize_quaternion


MIXED_SPIN_MODEL = 'MixedSpinTransERR'


def mixed_spin_dimensions(entity_dim):
    if entity_dim < 16 or entity_dim % 8:
        raise ValueError('Mixed spin requires entity width >= 16 and divisible by eight')
    high_dim = 8 * (entity_dim // 16)
    return entity_dim - high_dim, high_dim


def split_mixed_entity(value):
    """Partition quaternion indices, not contiguous scalar coordinates."""
    low_dim, high_dim = mixed_spin_dimensions(value.size(-1))
    components = value.reshape(*value.shape[:-1], 4, -1)
    low, high = components.split((low_dim // 4, high_dim // 4), dim=-1)
    return low.flatten(-2), high.flatten(-2)


def join_mixed_entity(low, high):
    components = [part.reshape(*part.shape[:-1], 4, -1) for part in (low, high)]
    return torch.cat(components, dim=-1).flatten(-2)


def compact_mixed_frame(full_frame):
    low, high = split_mixed_entity(full_frame)
    high = high.reshape(*high.shape[:-1], 4, -1, 2)[..., 0].flatten(-2)
    return torch.cat((low, high), dim=-1)


def split_mixed_frame(frame, entity_dim):
    low_dim, high_dim = mixed_spin_dimensions(entity_dim)
    if frame.size(-1) != low_dim + high_dim // 2:
        raise ValueError('Invalid compact mixed frame width')
    return frame.split((low_dim, high_dim // 2), dim=-1)


def split_mixed_relation(relation, entity_dim):
    low_dim, high_dim = mixed_spin_dimensions(entity_dim)
    frame_dim = low_dim + high_dim // 2
    if relation.size(-1) != 2 * frame_dim + entity_dim:
        raise ValueError('Invalid compact mixed relation width')
    return relation.split((frame_dim, entity_dim, frame_dim), dim=-1)


def apply_mixed_spin(value, frame):
    low, high = split_mixed_entity(value)
    low_frame, high_frame = split_mixed_frame(frame, value.size(-1))
    low_result = hamilton_product(low, normalize_quaternion(low_frame))
    high_result = apply_spin_operator(high, spin_operator(high_frame, 'SpinThreeHalfTransERR'))
    return join_mixed_entity(low_result, high_result)


@torch.no_grad()
def mixed_spin_diagnostics(model):
    if model.model_name != MIXED_SPIN_MODEL:
        raise ValueError('Expected a mixed spin model')
    low_dim, high_dim = mixed_spin_dimensions(model.entity_dim)
    source, _, target = split_mixed_relation(model.relation_embedding.unsqueeze(1), model.entity_dim)
    rows = []
    for rid in range(model.nrelation):
        row = {'relation_id': rid}
        for name, frame in (('head', source[rid:rid + 1]), ('tail', target[rid:rid + 1])):
            low, high = split_mixed_frame(frame.double(), model.entity_dim)
            for branch, raw, operator in (
                    ('low', low, right_hamilton_matrix(low)),
                    ('high', high, spin_operator(high, 'SpinThreeHalfTransERR'))):
                identity = torch.eye(operator.size(-1), dtype=operator.dtype, device=operator.device)
                norms = raw.reshape(1, 1, 4, -1).square().sum(-2).sqrt()
                row[name + '_' + branch] = {
                    'raw_norm_min': norms.min().item(), 'raw_norm_max': norms.max().item(),
                    'unitarity_max_error': (operator.mH @ operator - identity).abs().max().item(),
                }
        rows.append(row)
    return {'model': model.model_name, 'scope': 'relation_parameters_only_not_metrics',
            'entity_dim': model.entity_dim, 'low_dim': low_dim, 'high_dim': high_dim,
            'low_groups': low_dim // 4, 'high_groups': high_dim // 8,
            'relation_dim': model.relation_dim, 'relations': rows}
