#!/usr/bin/env python3
"""Evaluate a TransERR WN18RR checkpoint overall and by relation type."""

import argparse
import collections
import inspect
import json
import logging
import re
import sys
from pathlib import Path

import torch
from torch.utils.data import DataLoader

from dataloader import TestDataset
from model import KGEModel


METRICS = ("MRR", "MR", "HITS@1", "HITS@3", "HITS@10")
RELATION_TYPES = ("1-1", "1-N", "N-1", "N-N")
TYPE_NAMES = dict(enumerate(RELATION_TYPES))


def parse_args():
    parser = argparse.ArgumentParser(
        description="Standalone filtered WN18RR evaluation by relation mapping type."
    )
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--data-path", type=Path)
    parser.add_argument("--split", choices=("valid", "test"), default="test")
    parser.add_argument("--batch-size", type=int)
    parser.add_argument("--cpu-num", type=int, default=8)
    parser.add_argument("--type-threshold", type=float, default=1.5)
    parser.add_argument(
        "--openke-test-types",
        type=Path,
        help="Optional OpenKE test2id_all.txt; its first column is the official type ID.",
    )
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--expected-log", type=Path)
    parser.add_argument("--tolerance", type=float, default=5e-7)
    parser.add_argument("--output", type=Path)
    return parser.parse_args()


def read_dict(path):
    result = {}
    with path.open() as fin:
        for line in fin:
            idx, value = line.rstrip("\n").split("\t")
            result[value] = int(idx)
    return result


def read_triples(path, entity2id, relation2id):
    triples = []
    with path.open() as fin:
        for line in fin:
            head, relation, tail = line.rstrip("\n").split("\t")
            triples.append((entity2id[head], relation2id[relation], entity2id[tail]))
    return triples


def resolve_data_path(cli_path, config, checkpoint_dir):
    if cli_path is not None:
        return cli_path.resolve()
    configured = Path(config["data_path"])
    candidates = [configured, Path.cwd() / configured, checkpoint_dir / configured]
    for candidate in candidates:
        if (candidate / "entities.dict").is_file():
            return candidate.resolve()
    raise FileNotFoundError(
        "Cannot resolve data_path from config; pass --data-path explicitly"
    )


def classify_relations(train_triples, nrelation, threshold):
    heads = [collections.defaultdict(set) for _ in range(nrelation)]
    tails = [collections.defaultdict(set) for _ in range(nrelation)]
    for head, relation, tail in train_triples:
        heads[relation][tail].add(head)
        tails[relation][head].add(tail)

    relation_types = {}
    cardinalities = {}
    for relation in range(nrelation):
        heads_per_tail = sum(map(len, heads[relation].values())) / max(len(heads[relation]), 1)
        tails_per_head = sum(map(len, tails[relation].values())) / max(len(tails[relation]), 1)
        if tails_per_head < threshold and heads_per_tail < threshold:
            relation_type = "1-1"
        elif tails_per_head >= threshold and heads_per_tail < threshold:
            relation_type = "1-N"
        elif tails_per_head < threshold and heads_per_tail >= threshold:
            relation_type = "N-1"
        else:
            relation_type = "N-N"
        relation_types[relation] = relation_type
        cardinalities[relation] = {
            "tails_per_head": tails_per_head,
            "heads_per_tail": heads_per_tail,
            "type": relation_type,
        }
    return relation_types, cardinalities


def read_openke_type_labels(path, expected_count):
    with path.open() as fin:
        declared = int(fin.readline())
        labels = [TYPE_NAMES[int(line.split()[0])] for line in fin if line.strip()]
    if declared != expected_count or len(labels) != expected_count:
        raise ValueError(
            f"OpenKE type count mismatch: declared={declared}, "
            f"read={len(labels)}, expected={expected_count}"
        )
    return labels


def metric_row(rank):
    return {
        "MRR": 1.0 / rank,
        "MR": float(rank),
        "HITS@1": float(rank <= 1),
        "HITS@3": float(rank <= 3),
        "HITS@10": float(rank <= 10),
    }


def summarize(rows):
    if not rows:
        return {"count": 0, **{metric: None for metric in METRICS}}
    return {
        "count": len(rows),
        **{
            metric: sum(row[metric] for row in rows) / len(rows)
            for metric in METRICS
        },
    }


def evaluate(model, triples, all_true_triples, relation_types, nentity, nrelation,
             batch_size, cpu_num, device, triple_type_labels=None):
    grouped = collections.defaultdict(list)
    loaders = [
        DataLoader(
            TestDataset(triples, all_true_triples, nentity, nrelation, mode),
            batch_size=batch_size,
            num_workers=max(1, cpu_num // 2),
            collate_fn=TestDataset.collate_fn,
        )
        for mode in ("head-batch", "tail-batch")
    ]

    model.eval()
    with torch.no_grad():
        for loader in loaders:
            row_offset = 0
            for positive, negative, filter_bias, mode in loader:
                positive = positive.to(device)
                negative = negative.to(device)
                filter_bias = filter_bias.to(device)
                score = model((positive, negative), mode) + filter_bias
                order = torch.argsort(score, dim=1, descending=True)
                target = positive[:, 0] if mode == "head-batch" else positive[:, 2]
                ranks = (order == target.unsqueeze(1)).nonzero(as_tuple=False)[:, 1] + 1

                batch_types = (
                    triple_type_labels[row_offset:row_offset + len(ranks)]
                    if triple_type_labels is not None else None
                )
                for index, (relation, rank) in enumerate(
                        zip(positive[:, 1].tolist(), ranks.tolist())):
                    relation_type = (
                        batch_types[index] if batch_types is not None
                        else relation_types[relation]
                    )
                    row = metric_row(rank)
                    grouped["overall"].append(row)
                    grouped[relation_type].append(row)
                    grouped[mode].append(row)
                    grouped[f"{relation_type}/{mode}"].append(row)
                row_offset += len(ranks)

    result = {"overall": summarize(grouped["overall"])}
    result["by_relation_type"] = {
        name: summarize(grouped[name]) for name in RELATION_TYPES
    }
    result["by_direction"] = {
        mode: summarize(grouped[mode]) for mode in ("head-batch", "tail-batch")
    }
    result["by_type_and_direction"] = {
        name: {
            mode: summarize(grouped[f"{name}/{mode}"])
            for mode in ("head-batch", "tail-batch")
        }
        for name in RELATION_TYPES
    }
    return result


def read_last_logged_metrics(path, split):
    pattern = re.compile(
        rf"\b{split.capitalize()} ({'|'.join(map(re.escape, METRICS))}) "
        rf"at step \d+: ([0-9.eE+-]+)"
    )
    metrics = {}
    with path.open() as fin:
        for line in fin:
            match = pattern.search(line)
            if match:
                metrics[match.group(1)] = float(match.group(2))
    if set(metrics) != set(METRICS):
        raise ValueError(f"No complete {split} metrics found in {path}")
    return metrics


def verify_metrics(actual, expected, tolerance):
    differences = {metric: actual[metric] - expected[metric] for metric in METRICS}
    failed = {
        metric: difference
        for metric, difference in differences.items()
        if abs(difference) > tolerance
    }
    if failed:
        raise RuntimeError(f"Aggregate metrics do not match the log: {failed}")
    return differences


def main():
    args = parse_args()
    checkpoint_dir = args.checkpoint.resolve()
    with (checkpoint_dir / "config.json").open() as fin:
        config = json.load(fin)
    data_path = resolve_data_path(args.data_path, config, checkpoint_dir)

    entity2id = read_dict(data_path / "entities.dict")
    relation2id = read_dict(data_path / "relations.dict")
    train = read_triples(data_path / "train.txt", entity2id, relation2id)
    valid = read_triples(data_path / "valid.txt", entity2id, relation2id)
    test = read_triples(data_path / "test.txt", entity2id, relation2id)
    triples = valid if args.split == "valid" else test
    all_true = train + valid + test

    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable; use --device cpu")
    checkpoint = torch.load(
        checkpoint_dir / "checkpoint", map_location=device, weights_only=False
    )
    model_class = KGEModel
    if "quaternion_scale_raw" in checkpoint["model_state_dict"]:
        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
        from scale_model import ScaledV73
        model_class = ScaledV73

    constructor_keys = set(inspect.signature(KGEModel.__init__).parameters) - {"self"}
    model_kwargs = {key: config[key] for key in constructor_keys if key in config}
    model_kwargs.update(
        model_name=config["model"],
        nentity=len(entity2id),
        nrelation=len(relation2id),
        hidden_dim=config["hidden_dim"],
        gamma=config["gamma"],
    )
    model = model_class(**model_kwargs).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])

    relation_types, cardinalities = classify_relations(
        train, len(relation2id), args.type_threshold
    )
    triple_type_labels = (
        read_openke_type_labels(args.openke_test_types, len(triples))
        if args.openke_test_types else None
    )
    result = evaluate(
        model=model,
        triples=triples,
        all_true_triples=all_true,
        relation_types=relation_types,
        nentity=len(entity2id),
        nrelation=len(relation2id),
        batch_size=args.batch_size or config.get("test_batch_size", 8),
        cpu_num=args.cpu_num,
        device=device,
        triple_type_labels=triple_type_labels,
    )
    result["metadata"] = {
        "checkpoint": str(checkpoint_dir),
        "checkpoint_step": checkpoint.get("step"),
        "data_path": str(data_path),
        "split": args.split,
        "type_threshold": args.type_threshold,
        "type_source": (
            str(args.openke_test_types.resolve())
            if args.openke_test_types else "computed from training triples"
        ),
        "triple_count": len(triples),
        "rank_count": result["overall"]["count"],
    }
    result["relation_cardinalities"] = {
        relation: cardinalities[index]
        for relation, index in sorted(relation2id.items(), key=lambda item: item[1])
    }

    if args.expected_log:
        expected = read_last_logged_metrics(args.expected_log, args.split)
        result["log_verification"] = {
            "expected": expected,
            "difference": verify_metrics(
                result["overall"], expected, args.tolerance
            ),
            "tolerance": args.tolerance,
            "matched": True,
        }

    rendered = json.dumps(result, indent=2, sort_keys=True)
    print(rendered)
    output = args.output or checkpoint_dir / f"{args.split}_metrics_by_type.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(rendered + "\n")
    logging.info("Saved results to %s", output)


if __name__ == "__main__":
    main()
