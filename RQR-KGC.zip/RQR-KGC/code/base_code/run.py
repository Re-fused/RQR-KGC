#!/usr/bin/python3

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import json
import logging
import math
import os
import random

import numpy as np
import torch
import time

from torch.utils.data import DataLoader

from model import KGEModel, RANK_DEFECT_LOCAL_GLOBAL_MODEL
from models.double_center_diagnostics import double_center_diagnostics
from models.double_center_initialization import (
    configure_double_center_stage, initialize_double_centers_from_train,
)
from models.region import region_diagnostics
from models.spectral import spectral_diagnostics
from models.nonlinear_phase import nonlinear_endpoint_diagnostics
from models.local_ot import local_ot_diagnostics
from models.implicit_quadratic import quadratic_diagnostics
from models.bures_state import bures_diagnostics
from models.higher_spin import SPIN_MODELS, spin_diagnostics
from models.mixed_spin import MIXED_SPIN_MODEL, mixed_spin_diagnostics
from training.negative_cache import PersistentNegativeCache
from models.rank_defect_local_global import (
    relation_cardinality_defect_ranks,
)
try:
    from tensorboardX import SummaryWriter
except ImportError:
    class SummaryWriter(object):
        """No-op fallback when optional TensorBoard logging is unavailable."""

        def __init__(self, *args, **kwargs):
            pass

        def add_scalar(self, *args, **kwargs):
            pass

        def close(self):
            pass

from dataloader import TrainDataset
from dataloader import BidirectionalOneShotIterator

PAIR_GEOMETRY_DEFAULTS = {
    'quadratic_rank': 4, 'quadratic_bound': 1., 'quadratic_self_init': .5,
    'quadratic_cross_weight': 1., 'quadratic_self_weight': 1.,
    'quadratic_regularization': 1e-4,
    'bures_stretch_bound': .5, 'bures_diagonal_floor': .1,
    'bures_jitter': 1e-4, 'bures_smoothing': 1e-4,
    'bures_distance_scale': 0., 'bures_pair_chunk': 16384,
    'bures_regularization': 1e-4,
}

def save_region_diagnostics(model, train_triples, relation2id, args, step):
    if model.model_name != 'RegionTransERR':
        return
    report = region_diagnostics(model, train_triples, {rid: name for name, rid in relation2id.items()})
    report['step'] = step
    directory = os.path.join(args.save_path, 'region_diagnostics')
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, 'step_%06d.json' % step)
    with open(path + '.tmp', 'w') as handle:
        json.dump(report, handle, indent=2)
        handle.write('\n')
    os.replace(path + '.tmp', path)
    logging.info('Saved train-only region diagnostics at step %d: %s', step, path)


def save_spectral_diagnostics(model, relation2id, args, step):
    if model.model_name != 'SpectralTransERR':
        return
    report = spectral_diagnostics(model, {rid: name for name, rid in relation2id.items()})
    report['step'] = step
    directory = os.path.join(args.save_path, 'spectral_diagnostics')
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, 'step_%06d.json' % step)
    with open(path + '.tmp', 'w') as handle:
        json.dump(report, handle, indent=2)
        handle.write('\n')
    os.replace(path + '.tmp', path)
    logging.info('Saved spectral operator diagnostics at step %d: %s', step, path)


def save_nonlinear_endpoint_diagnostics(model, relation2id, args, step):
    if model.model_name not in ('KerrTransERR', 'FoldTransERR'):
        return
    report = nonlinear_endpoint_diagnostics(model, {rid: name for name, rid in relation2id.items()})
    report['step'] = step
    directory = os.path.join(args.save_path, 'nonlinear_endpoint_diagnostics')
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, 'step_%06d.json' % step)
    with open(path + '.tmp', 'w') as handle:
        json.dump(report, handle, indent=2)
        handle.write('\n')
    os.replace(path + '.tmp', path)
    logging.info('Saved nonlinear endpoint diagnostics at step %d: %s', step, path)


def save_local_ot_diagnostics(model, args, step):
    if model.model_name != 'LocalOTTransERR':
        return
    report = local_ot_diagnostics(model)
    report['step'] = step
    directory = os.path.join(args.save_path, 'local_ot_diagnostics')
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, 'step_%06d.json' % step)
    with open(path + '.tmp', 'w') as handle:
        json.dump(report, handle, indent=2, allow_nan=False)
        handle.write('\n')
    os.replace(path + '.tmp', path)
    logging.info('Saved local OT diagnostics at step %d: %s', step, path)


def save_pair_geometry_diagnostics(model, args, step):
    if model.model_name == 'ImplicitQuadraticTransERR':
        report = quadratic_diagnostics(model)
    elif model.model_name == 'BuresTransERR':
        report = bures_diagnostics(model)
    else:
        return
    report['step'] = step
    directory = os.path.join(args.save_path, 'pair_geometry_diagnostics')
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, 'step_%06d.json' % step)
    with open(path + '.tmp', 'w') as handle:
        json.dump(report, handle, indent=2, allow_nan=False)
        handle.write('\n')
    os.replace(path + '.tmp', path)
    logging.info('Saved pair geometry diagnostics at step %d: %s', step, path)


def save_spin_diagnostics(model, args, step):
    if model.model_name == MIXED_SPIN_MODEL:
        report = mixed_spin_diagnostics(model)
    elif model.model_name in SPIN_MODELS:
        report = spin_diagnostics(model)
    else:
        return
    report['step'] = step
    directory = os.path.join(args.save_path, 'spin_diagnostics')
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, 'step_%06d.json' % step)
    with open(path + '.tmp', 'w') as handle:
        json.dump(report, handle, indent=2, allow_nan=False)
        handle.write('\n')
    os.replace(path + '.tmp', path)
    logging.info('Saved spin diagnostics at step %d: %s', step, path)


def configure_negative_cache(model, args, train_triples, checkpoint=None):
    if not args.do_train or not args.persistent_negative_cache:
        return
    cache = PersistentNegativeCache(
        train_triples, model.nentity, capacity=args.negative_cache_size,
        draw_size=args.negative_cache_sample_size,
        score_batch_size=args.negative_cache_score_batch_size,
        seed=(args.seed or 0) + 0x4E5343,
    )
    if checkpoint is not None:
        if 'negative_cache_state' not in checkpoint:
            raise ValueError('Cannot resume cache training without saved negative_cache_state')
        cache.load_state_dict(checkpoint['negative_cache_state'])
    model.negative_cache = cache
    logging.info('Persistent negative cache: capacity=%d, draws=%d/%d, restored queries=%d',
                 cache.capacity, cache.draw_size, args.negative_sample_size, len(cache.entries))


def validate_region_cache_args(args):
    for model, key in (('ImplicitQuadraticTransERR', 'quadratic_regularization'),
                       ('BuresTransERR', 'bures_regularization')):
        if args.model == model and (not math.isfinite(getattr(args, key)) or getattr(args, key) < 0):
            raise ValueError('%s must be finite and nonnegative' % key)
    if (args.model == 'BuresTransERR' and args.do_train and args.regularization
            and not args.norm_aware_regularization):
        raise ValueError('BuresTransERR requires --norm_aware_regularization for its normalized frames')
    if args.model == 'RegionTransERR' and (
            not math.isfinite(args.region_regularization) or args.region_regularization < 0):
        raise ValueError('region_regularization must be finite and nonnegative')
    if args.persistent_negative_cache:
        if args.model not in ('TransERR', 'RegionTransERR'):
            raise ValueError('Persistent cache currently requires TransERR or RegionTransERR')
        if min(args.negative_cache_size, args.negative_cache_sample_size,
               args.negative_cache_score_batch_size) < 1:
            raise ValueError('Negative cache sizes must be positive')
        if args.negative_cache_sample_size >= args.negative_sample_size:
            raise ValueError('Cache must leave at least one uniform negative per query')
        if args.relation_pool_negative_ratio or args.curriculum_hard_negative_max_ratio:
            raise ValueError('Persistent cache cannot be combined with relation-pool sampling')


def save_center_diagnostics(model, train_triples, relation2id, args, step):
    if model.model_name != 'DoubleCenterTransERR':
        return
    report = double_center_diagnostics(
        model, train_triples, {rid: name for name, rid in relation2id.items()},
        regularization=args.regularization,
        center_regularization=args.double_center_regularization,
    )
    report['step'] = step
    report['warmup_active'] = getattr(model, 'double_center_warmup_active', False)
    directory = os.path.join(args.save_path, 'center_diagnostics')
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, 'step_%06d.json' % step)
    with open(path + '.tmp', 'w') as handle:
        json.dump(report, handle, indent=2)
        handle.write('\n')
    os.replace(path + '.tmp', path)
    logging.info('Center diagnostics at step %d: RMS offset %.6f, weighted penalty %.8g; %s',
                 step, report['center_rms_l2_norm'],
                 report['center_regularization_weighted'], path)

def parse_args(args=None):
    parser = argparse.ArgumentParser(
        description='Training and Testing Knowledge Graph Embedding Models',
        usage='train.py [<args>] [-h | --help]'
    )

    parser.add_argument('--cuda', action='store_true', help='use GPU')
    
    parser.add_argument('--do_train', action='store_true')
    parser.add_argument('--do_valid', action='store_true')
    parser.add_argument('--do_test', action='store_true')
    parser.add_argument('--evaluate_train', action='store_true', help='Evaluate on training data')
    
    parser.add_argument('--countries', action='store_true', help='Use Countries S1/S2/S3 datasets')
    parser.add_argument('--regions', type=int, nargs='+', default=None, 
                        help='Region Id for Countries S1/S2/S3 datasets, DO NOT MANUALLY SET')
    
    parser.add_argument('--dataset', type=str, default='wn18rr', help='dataset name, default to biokg')
    parser.add_argument('--data_path', type=str, default=None)
    parser.add_argument('--model', default='TransE', type=str)
    parser.add_argument('--double_center_temperature', default=0.5, type=float)
    parser.add_argument('--double_center_groups', default=1, type=int,
                        help='Independent center choices over intact quaternion groups; local temperature = total/groups')
    parser.add_argument('--double_center_init_scale', default=0.1, type=float)
    parser.add_argument('--double_center_regularization', default=1e-4, type=float)
    parser.add_argument('--double_center_init_method', default='random',
                        choices=('random', 'residual_kmedians'))
    parser.add_argument('--double_center_split_step', default=2000, type=int)
    parser.add_argument('--double_center_cluster_iterations', default=10, type=int)
    parser.add_argument('--region_width_bound', default=0.02, type=float)
    parser.add_argument('--region_width_init_fraction', default=0.01, type=float)
    parser.add_argument('--region_inner_weight', default=0.1, type=float)
    parser.add_argument('--region_regularization', default=1e-4, type=float)
    parser.add_argument('--kerr_phase_bound', default=math.pi / 2, type=float,
                        help='Absolute phase cap; each self/cross coefficient is bounded by half this value')
    parser.add_argument('--kerr_intensity_scale', default=0.0, type=float,
                        help='Fixed positive intensity scale; zero uses (gamma + 2) / hidden_dim')
    parser.add_argument('--local_ot_window', default=5, type=int)
    parser.add_argument('--local_ot_temperature', default=0.1, type=float)
    parser.add_argument('--local_ot_prior_mix', default=0.2, type=float)
    parser.add_argument('--local_ot_chunk_size', default=1048576, type=int,
                        help='Internal OT problems per chunk; does not change training batch or negatives')
    parser.add_argument('--local_ot_max_iter', default=128, type=int)
    parser.add_argument('--local_ot_tolerance', default=1e-5, type=float)
    parser.add_argument('--local_ot_identity', action='store_true',
                        help='Fixed one-to-one matching without KL; original TransERR control')
    for name, default in PAIR_GEOMETRY_DEFAULTS.items():
        parser.add_argument('--' + name, default=default, type=type(default))
    parser.add_argument('--persistent_negative_cache', action='store_true')
    parser.add_argument('--negative_cache_size', default=64, type=int)
    parser.add_argument('--negative_cache_sample_size', default=64, type=int)
    parser.add_argument('--negative_cache_score_batch_size', default=64, type=int)
    parser.add_argument('-de', '--double_entity_embedding', action='store_true')
    parser.add_argument('-dr', '--double_relation_embedding', action='store_true')
    parser.add_argument('-tr', '--triple_relation_embedding', action='store_true')
    parser.add_argument('--context_rank', default=16, type=int)
    parser.add_argument('--context_gate_init', default=-2.0, type=float)
    parser.add_argument('--context_delta_bound', default=0.05, type=float)
    parser.add_argument('--context_regularization', default=1e-4, type=float)
    parser.add_argument('--scale_bound', default=0.1, type=float)
    parser.add_argument('--scale_regularization', default=1e-4, type=float)
    parser.add_argument('--relation_bias_bound', default=1.0, type=float)
    parser.add_argument('--relation_bias_regularization', default=1e-4,
                        type=float)
    parser.add_argument('--role_delta_bound', default=0.01, type=float)
    parser.add_argument('--role_delta_regularization', default=1e-4,
                        type=float)
    parser.add_argument('--reciprocal_residual_bound', default=0.01,
                        type=float)
    parser.add_argument('--reciprocal_residual_regularization',
                        default=1e-4, type=float)
    parser.add_argument('--reciprocal_cycle_regularization',
                        default=0.0, type=float)
    parser.add_argument('--reciprocal_cycle_translation_weight',
                        default=1.0, type=float)
    parser.add_argument('--soft_extremal_group_size', default=8, type=int)
    parser.add_argument('--soft_extremal_temperature', default=0.35,
                        type=float)
    parser.add_argument('--soft_extremal_gate_init', default=-2.2,
                        type=float)
    parser.add_argument('--max_mean_group_size', default=8, type=int)
    parser.add_argument('--max_mean_gate_init', default=-5.0, type=float)
    parser.add_argument('--mean_variance_group_size', default=8, type=int)
    parser.add_argument('--mean_variance_temperature', default=0.1,
                        type=float)
    parser.add_argument('--mean_variance_gate_init', default=-2.2,
                        type=float)
    parser.add_argument('--pmean_group_size', default=8, type=int)
    parser.add_argument('--pmean_exponent_bound', default=1.0, type=float)
    parser.add_argument('--pmean_exponent_init', default=-4.0, type=float)
    parser.add_argument('--complex_dim', default=500, type=int)
    parser.add_argument('--hyperbolic_dim', default=250, type=int)
    parser.add_argument('--router_temperature', default=1.0, type=float)
    parser.add_argument('--moe_regularization', default=1e-4, type=float)
    parser.add_argument('--router_balance_regularization', default=1e-3, type=float)
    parser.add_argument('--dual_gate_init', default=-4.0, type=float)
    parser.add_argument('--dual_weight_bound', default=0.1, type=float)
    parser.add_argument('--dual_init_scale', default=0.1, type=float)
    parser.add_argument('--dual_regularization', default=1e-4, type=float)
    parser.add_argument('--biquaternion_fusion_bound', default=0.25,
                        type=float)
    parser.add_argument('--biquaternion_fusion_gate_init', default=-4.0,
                        type=float)
    parser.add_argument('--subspace_groups', default=10, type=int)
    parser.add_argument('--subspace_regularization', default=1e-4, type=float)
    parser.add_argument('--lie_angle_bound', default=3.141592653589793,
                        type=float)
    parser.add_argument('--screw_distance_bound', default=0.1, type=float)
    parser.add_argument('--mobius_c_bound', default=0.1, type=float)
    parser.add_argument('--mobius_denominator_epsilon', default=1e-6,
                        type=float)
    parser.add_argument('--frame_temperature', default=1.0, type=float)
    parser.add_argument('--frame_relative_prior', default=2.0, type=float)
    parser.add_argument('--frame_min_weight', default=0.0, type=float)
    parser.add_argument('--block_frame_temperature', default=0.05, type=float)
    parser.add_argument('--block_frame_relative_prior', default=2.0,
                        type=float)
    parser.add_argument('--block_frame_min_weight', default=0.02, type=float)
    parser.add_argument('--orthogonal_temperature', default=1.0, type=float)
    parser.add_argument('--orthogonal_cayley_prior', default=1.0, type=float)
    parser.add_argument('--residual_so4_bound', default=0.0, type=float)
    parser.add_argument('--cayley_residual_start_step', default=20000,
                        type=int)
    parser.add_argument('--geometry_regularization', default=1e-4,
                        type=float)
    parser.add_argument('--householder_group_dim', default=8, type=int)
    parser.add_argument('--householder_shear_bound', default=0.5,
                        type=float)
    parser.add_argument('--kronecker_identity_floor', default=0.03,
                        type=float)
    parser.add_argument('--cartan_stretch_bound', default=0.5, type=float)
    parser.add_argument('--port_block_dim', default=4, type=int)
    parser.add_argument('--port_steps', default=1, type=int)
    parser.add_argument('--port_rotation_bound', default=0.25, type=float)
    parser.add_argument('--port_damping_bound', default=0.1, type=float)
    parser.add_argument('--port_damping_init', default=0.001, type=float)
    parser.add_argument('--port_nonlinear_bound', default=0.25, type=float)
    parser.add_argument('--port_log_scale_bound', default=0.5, type=float)
    parser.add_argument('--port_regularization', default=1e-4, type=float)
    parser.add_argument('--quaternion_operator_bound', default=0.1,
                        type=float)
    parser.add_argument('--polar_rank', default=4, type=int)
    parser.add_argument('--polar_bound', default=0.5, type=float)
    parser.add_argument('--flow_rank', default=16, type=int)
    parser.add_argument('--flow_scale_bound', default=0.25, type=float)
    parser.add_argument('--flow_shift_bound', default=0.1, type=float)
    parser.add_argument('--rank_defect_rows', default=0, type=int)
    parser.add_argument('--local_global_rank', default=4, type=int)
    parser.add_argument('--rank_defect_max_rank', default=4, type=int)
    parser.add_argument('--rank_defect_degree_scale', default=1.0, type=float)
    parser.add_argument('--rank_defect_cayley_bound', default=0.25, type=float)
    parser.add_argument('--rank_defect_start_step', default=0, type=int)
    parser.add_argument('--rank_defect_ramp_steps', default=4000, type=int)
    parser.add_argument('--norm_aware_regularization', action='store_true')
    
    parser.add_argument('-n', '--negative_sample_size', default=128, type=int)
    parser.add_argument(
        '--relation_pool_negative_ratio', default=0.0, type=float,
        help='fraction of negatives sampled from the relation domain/range'
    )
    parser.add_argument(
        '--curriculum_hard_negative_min_ratio', default=0.0, type=float
    )
    parser.add_argument(
        '--curriculum_hard_negative_max_ratio', default=0.0, type=float
    )
    parser.add_argument(
        '--curriculum_hard_negative_start_step', default=20000, type=int
    )
    parser.add_argument(
        '--curriculum_hard_negative_ramp_steps', default=10000, type=int
    )
    parser.add_argument(
        '--curriculum_hard_rank_topk', default=8, type=int
    )
    parser.add_argument('-d', '--hidden_dim', default=500, type=int)
    parser.add_argument('-g', '--gamma', default=12.0, type=float)
    parser.add_argument('-adv', '--negative_adversarial_sampling', action='store_true')
    parser.add_argument('-a', '--adversarial_temperature', default=1.0, type=float)
    parser.add_argument('--rank_loss_weight', default=0.0, type=float)
    parser.add_argument('--rank_loss_margin', default=0.0, type=float)
    parser.add_argument('--rank_loss_topk', default=10, type=int)
    parser.add_argument(
        '--rank_loss_mode', default='pairwise',
        choices=('pairwise', 'cutoff', 'hybrid')
    )
    parser.add_argument(
        '--rank_loss_cutoffs', default=(1, 3, 10), type=int, nargs='+'
    )
    parser.add_argument('-b', '--batch_size', default=1024, type=int)
    parser.add_argument('-r', '--regularization', default=0.0, type=float)
    parser.add_argument(
        '--translation_regularization', default=0.0, type=float,
        help='Additional L2 regularization for the relation translation.'
    )
    parser.add_argument('--test_batch_size', default=4, type=int, help='valid/test batch size')
    parser.add_argument('--uni_weight', action='store_true', 
                        help='Otherwise use subsampling weighting like in word2vec')
    
    parser.add_argument('-lr', '--learning_rate', default=0.0001, type=float)
    parser.add_argument('-cpu', '--cpu_num', default=10, type=int)
    parser.add_argument('-init', '--init_checkpoint', default=None, type=str)
    parser.add_argument(
        '--override_init_learning_rate', action='store_true',
        help='Restore checkpoint state but use learning rates from this run.'
    )
    parser.add_argument('-save', '--save_path', default=None, type=str)
    parser.add_argument('--max_steps', default=100000, type=int)
    parser.add_argument('--warm_up_steps', default=None, type=int)
    parser.add_argument('-wur', '--warm_up_ratio', default=[0.2, 0.5, 0.8], type=float, nargs='+')
    parser.add_argument('--lr_decay_factor', default=10.0, type=float)
    parser.add_argument('--geometry_lr_decay_factor', default=None, type=float)
    parser.add_argument('--geometry_lr_scale', default=1.0, type=float)
    parser.add_argument('--relation_lr_decay_factor', default=None, type=float)
    parser.add_argument(
        '--reciprocal_residual_lr_decay_factor', default=None, type=float
    )
    parser.add_argument(
        '--reciprocal_residual_lr_scale', default=1.0, type=float
    )
    parser.add_argument(
        '--inverse_residual_lr_scale', default=None, type=float
    )
    parser.add_argument(
        '--tail_residual_lr_scale', default=None, type=float
    )
    
    
    parser.add_argument('--save_checkpoint_steps', default=2000, type=int)
    parser.add_argument('--valid_steps', default=2000, type=int)
    parser.add_argument('--log_steps', default=100, type=int, help='train log every xx steps')
    parser.add_argument('--test_log_steps', default=1000, type=int, help='valid/test log every xx steps')
    
    parser.add_argument('--nentity', type=int, default=0, help='DO NOT MANUALLY SET')
    parser.add_argument('--nrelation', type=int, default=0, help='DO NOT MANUALLY SET')
    parser.add_argument('--eval_type', default="random", type=str)
    parser.add_argument('--seed', default=None, type=int)
    parser.add_argument('--save_best_valid', action='store_true')
    parser.add_argument('--test_best_valid', action='store_true')
    
    
    return parser.parse_args(args)

def override_config(args):
    '''
    Override model and data configuration
    '''
    
    with open(os.path.join(args.init_checkpoint, 'config.json'), 'r') as fjson:
        argparse_dict = json.load(fjson)
    
    args.countries = argparse_dict['countries']
    if args.data_path is None:
        args.data_path = argparse_dict['data_path']
    args.model = argparse_dict['model']
    args.double_entity_embedding = argparse_dict['double_entity_embedding']
    args.double_relation_embedding = argparse_dict['double_relation_embedding']
    args.triple_relation_embedding = argparse_dict.get(
        'triple_relation_embedding', False
    )
    args.hidden_dim = argparse_dict['hidden_dim']
    # Legacy checkpoints always use one global center choice, even if a
    # different group count was supplied on the evaluation command line.
    args.double_center_groups = argparse_dict.get('double_center_groups', 1)
    args.kerr_phase_bound = argparse_dict.get('kerr_phase_bound', math.pi / 2)
    args.kerr_intensity_scale = argparse_dict.get('kerr_intensity_scale', 0.0)
    for key, default in (('local_ot_window', 5), ('local_ot_temperature', 0.1),
                         ('local_ot_prior_mix', 0.2), ('local_ot_chunk_size', 1048576),
                         ('local_ot_max_iter', 128), ('local_ot_tolerance', 1e-5),
                         ('local_ot_identity', False)):
        setattr(args, key, argparse_dict.get(key, default))
    for key, default in PAIR_GEOMETRY_DEFAULTS.items():
        setattr(args, key, argparse_dict.get(key, default))
    if args.model in ('KerrTransERR', 'FoldTransERR', 'LocalOTTransERR',
                      'ImplicitQuadraticTransERR', 'BuresTransERR', *SPIN_MODELS, MIXED_SPIN_MODEL):
        # Kerr's automatic intensity scale is derived before tensor restoration.
        args.gamma = argparse_dict['gamma']
    for key in ('double_center_temperature', 'double_center_init_scale',
                'double_center_regularization', 'double_center_init_method',
                'double_center_split_step', 'double_center_cluster_iterations',
                'region_width_bound', 'region_width_init_fraction', 'region_inner_weight',
                'region_regularization', 'persistent_negative_cache', 'negative_cache_size',
                'negative_cache_sample_size', 'negative_cache_score_batch_size'):
        setattr(args, key, argparse_dict.get(key, getattr(args, key)))
    args.test_batch_size = argparse_dict['test_batch_size']
    args.context_rank = argparse_dict.get('context_rank', args.context_rank)
    args.context_gate_init = argparse_dict.get(
        'context_gate_init', args.context_gate_init
    )
    args.context_delta_bound = argparse_dict.get(
        'context_delta_bound', args.context_delta_bound
    )
    args.scale_bound = argparse_dict.get('scale_bound', args.scale_bound)
    args.complex_dim = argparse_dict.get('complex_dim', args.complex_dim)
    args.hyperbolic_dim = argparse_dict.get(
        'hyperbolic_dim', args.hyperbolic_dim
    )
    args.router_temperature = argparse_dict.get(
        'router_temperature', args.router_temperature
    )
    args.dual_gate_init = argparse_dict.get(
        'dual_gate_init', args.dual_gate_init
    )
    args.dual_weight_bound = argparse_dict.get(
        'dual_weight_bound', args.dual_weight_bound
    )
    args.dual_init_scale = argparse_dict.get(
        'dual_init_scale', args.dual_init_scale
    )
    args.biquaternion_fusion_bound = argparse_dict.get(
        'biquaternion_fusion_bound', args.biquaternion_fusion_bound
    )
    args.biquaternion_fusion_gate_init = argparse_dict.get(
        'biquaternion_fusion_gate_init',
        args.biquaternion_fusion_gate_init
    )
    args.subspace_groups = argparse_dict.get(
        'subspace_groups', args.subspace_groups
    )
    args.lie_angle_bound = argparse_dict.get(
        'lie_angle_bound', args.lie_angle_bound
    )
    args.screw_distance_bound = argparse_dict.get(
        'screw_distance_bound', args.screw_distance_bound
    )
    args.mobius_c_bound = argparse_dict.get(
        'mobius_c_bound', args.mobius_c_bound
    )
    args.mobius_denominator_epsilon = argparse_dict.get(
        'mobius_denominator_epsilon',
        args.mobius_denominator_epsilon
    )
    args.frame_temperature = argparse_dict.get(
        'frame_temperature', args.frame_temperature
    )
    args.frame_relative_prior = argparse_dict.get(
        'frame_relative_prior', args.frame_relative_prior
    )
    args.frame_min_weight = argparse_dict.get(
        'frame_min_weight', args.frame_min_weight
    )
    args.block_frame_temperature = argparse_dict.get(
        'block_frame_temperature', args.block_frame_temperature
    )
    args.block_frame_relative_prior = argparse_dict.get(
        'block_frame_relative_prior', args.block_frame_relative_prior
    )
    args.block_frame_min_weight = argparse_dict.get(
        'block_frame_min_weight', args.block_frame_min_weight
    )
    args.orthogonal_temperature = argparse_dict.get(
        'orthogonal_temperature', args.orthogonal_temperature
    )
    args.orthogonal_cayley_prior = argparse_dict.get(
        'orthogonal_cayley_prior', args.orthogonal_cayley_prior
    )
    args.residual_so4_bound = argparse_dict.get(
        'residual_so4_bound', args.residual_so4_bound
    )
    args.cayley_residual_start_step = argparse_dict.get(
        'cayley_residual_start_step', args.cayley_residual_start_step
    )
    args.geometry_regularization = argparse_dict.get(
        'geometry_regularization', args.geometry_regularization
    )
    args.translation_regularization = argparse_dict.get(
        'translation_regularization', args.translation_regularization
    )
    args.polar_rank = argparse_dict.get('polar_rank', args.polar_rank)
    args.polar_bound = argparse_dict.get('polar_bound', args.polar_bound)
    args.flow_rank = argparse_dict.get('flow_rank', args.flow_rank)
    args.flow_scale_bound = argparse_dict.get(
        'flow_scale_bound', args.flow_scale_bound
    )
    args.flow_shift_bound = argparse_dict.get(
        'flow_shift_bound', args.flow_shift_bound
    )
    args.rank_defect_rows = argparse_dict.get(
        'rank_defect_rows', args.rank_defect_rows
    )
    args.local_global_rank = argparse_dict.get(
        'local_global_rank', args.local_global_rank
    )
    args.rank_defect_max_rank = argparse_dict.get(
        'rank_defect_max_rank', args.rank_defect_max_rank
    )
    args.rank_defect_degree_scale = argparse_dict.get(
        'rank_defect_degree_scale', args.rank_defect_degree_scale
    )
    args.rank_defect_cayley_bound = argparse_dict.get(
        'rank_defect_cayley_bound', args.rank_defect_cayley_bound
    )
    args.rank_defect_start_step = argparse_dict.get(
        'rank_defect_start_step', args.rank_defect_start_step
    )
    args.rank_defect_ramp_steps = argparse_dict.get(
        'rank_defect_ramp_steps', args.rank_defect_ramp_steps
    )
    args.householder_group_dim = argparse_dict.get(
        'householder_group_dim', args.householder_group_dim
    )
    args.householder_shear_bound = argparse_dict.get(
        'householder_shear_bound', args.householder_shear_bound
    )
    args.kronecker_identity_floor = argparse_dict.get(
        'kronecker_identity_floor', args.kronecker_identity_floor
    )
    args.cartan_stretch_bound = argparse_dict.get(
        'cartan_stretch_bound', args.cartan_stretch_bound
    )
    args.port_block_dim = argparse_dict.get(
        'port_block_dim', args.port_block_dim
    )
    args.port_steps = argparse_dict.get('port_steps', args.port_steps)
    args.port_rotation_bound = argparse_dict.get(
        'port_rotation_bound', args.port_rotation_bound
    )
    args.port_damping_bound = argparse_dict.get(
        'port_damping_bound', args.port_damping_bound
    )
    args.port_damping_init = argparse_dict.get(
        'port_damping_init', args.port_damping_init
    )
    args.port_nonlinear_bound = argparse_dict.get(
        'port_nonlinear_bound', args.port_nonlinear_bound
    )
    args.port_log_scale_bound = argparse_dict.get(
        'port_log_scale_bound', args.port_log_scale_bound
    )
    args.port_regularization = argparse_dict.get(
        'port_regularization', args.port_regularization
    )
    args.quaternion_operator_bound = argparse_dict.get(
        'quaternion_operator_bound', args.quaternion_operator_bound
    )
    args.geometry_lr_decay_factor = argparse_dict.get(
        'geometry_lr_decay_factor', args.geometry_lr_decay_factor
    )
    args.geometry_lr_scale = argparse_dict.get(
        'geometry_lr_scale', args.geometry_lr_scale
    )
    args.relation_lr_decay_factor = argparse_dict.get(
        'relation_lr_decay_factor', args.relation_lr_decay_factor
    )
    args.reciprocal_residual_lr_decay_factor = argparse_dict.get(
        'reciprocal_residual_lr_decay_factor',
        args.reciprocal_residual_lr_decay_factor
    )
    args.reciprocal_residual_lr_scale = argparse_dict.get(
        'reciprocal_residual_lr_scale',
        args.reciprocal_residual_lr_scale
    )
    args.inverse_residual_lr_scale = argparse_dict.get(
        'inverse_residual_lr_scale', args.inverse_residual_lr_scale
    )
    args.tail_residual_lr_scale = argparse_dict.get(
        'tail_residual_lr_scale', args.tail_residual_lr_scale
    )
    args.relation_bias_bound = argparse_dict.get(
        'relation_bias_bound', args.relation_bias_bound
    )
    args.relation_bias_regularization = argparse_dict.get(
        'relation_bias_regularization', args.relation_bias_regularization
    )
    args.role_delta_bound = argparse_dict.get(
        'role_delta_bound', args.role_delta_bound
    )
    args.role_delta_regularization = argparse_dict.get(
        'role_delta_regularization', args.role_delta_regularization
    )
    args.reciprocal_residual_bound = argparse_dict.get(
        'reciprocal_residual_bound', args.reciprocal_residual_bound
    )
    args.reciprocal_residual_regularization = argparse_dict.get(
        'reciprocal_residual_regularization',
        args.reciprocal_residual_regularization
    )
    args.reciprocal_cycle_regularization = argparse_dict.get(
        'reciprocal_cycle_regularization',
        args.reciprocal_cycle_regularization
    )
    args.reciprocal_cycle_translation_weight = argparse_dict.get(
        'reciprocal_cycle_translation_weight',
        args.reciprocal_cycle_translation_weight
    )


_GEOMETRY_LR_PARAMETER_NAMES = frozenset({
    'clifford_signature_delta',
    'residual_so4_embedding',
    'residual_so4_gate_logits',
    'coupled_residual_so4_embedding',
    'relative_residual_so4_embedding',
    'cayley_residual_embedding',
    'cayley_residual_gate',
    'port_skew_embedding',
    'port_damping_embedding',
    'port_nonlinear_embedding',
    'port_log_scale_embedding',
    'polar_direction',
    'polar_coefficient',
    'flow_down',
    'flow_scale_up',
    'flow_shift_up',
    'rank_defect_left_basis',
    'rank_defect_right_basis',
    'local_global_left_basis',
    'local_global_right_basis',
    'local_global_left_generator',
    'local_global_right_generator',
})

_RELATION_LR_PARAMETER_NAMES = frozenset({
    'relation_embedding',
    'center_offset',
    'region_width_logits',
    'spectral_phase',
    'kerr_coefficients_raw',
    'inverse_relation_embedding',
    'inverse_relation_residual',
    'tail_relation_residual',
    'forward_translation_residual_gate',
    'inverse_translation_residual_gate',
})

_RECIPROCAL_RESIDUAL_LR_PARAMETER_NAMES = frozenset({
    'inverse_relation_residual',
    'tail_relation_residual',
    'forward_translation_residual_gate',
    'inverse_translation_residual_gate',
})

_INVERSE_RESIDUAL_LR_PARAMETER_NAMES = frozenset({
    'inverse_relation_residual',
    'inverse_translation_residual_gate',
})

_TAIL_RESIDUAL_LR_PARAMETER_NAMES = frozenset({
    'tail_relation_residual',
    'forward_translation_residual_gate',
})


def build_optimizer(model, learning_rate, geometry_learning_rate=None,
                    relation_learning_rate=None,
                    reciprocal_residual_learning_rate=None,
                    inverse_residual_learning_rate=None,
                    tail_residual_learning_rate=None):
    """Build Adam with optional specialized learning-rate groups."""
    split_residual_lr = (
        inverse_residual_learning_rate is not None
        or tail_residual_learning_rate is not None
    )
    if split_residual_lr and reciprocal_residual_learning_rate is not None:
        raise ValueError(
            'combined and split reciprocal residual LR groups are exclusive'
        )
    if split_residual_lr and (
            inverse_residual_learning_rate is None
            or tail_residual_learning_rate is None):
        raise ValueError(
            'inverse and tail residual learning rates must be set together'
        )
    trainable = [
        (name, parameter)
        for name, parameter in model.named_parameters()
        if parameter.requires_grad
    ]
    if (geometry_learning_rate is None
            and relation_learning_rate is None
            and reciprocal_residual_learning_rate is None
            and not split_residual_lr):
        return torch.optim.Adam(
            [parameter for _, parameter in trainable], lr=learning_rate
        )

    geometry_parameters = [
        parameter for name, parameter in trainable
        if name in _GEOMETRY_LR_PARAMETER_NAMES
    ]
    if geometry_learning_rate is not None and not geometry_parameters:
        raise ValueError(
            '--geometry_lr_decay_factor requires a residual SO(4) model, '
            'port-Hamiltonian model, or another model with dedicated '
            'geometry parameters'
        )

    relation_parameters = [
        parameter for name, parameter in trainable
        if name in _RELATION_LR_PARAMETER_NAMES
        and not (
            (reciprocal_residual_learning_rate is not None
             or split_residual_lr)
            and name in _RECIPROCAL_RESIDUAL_LR_PARAMETER_NAMES
        )
    ]
    if relation_learning_rate is not None and not relation_parameters:
        raise ValueError(
            '--relation_lr_decay_factor requires relation parameters'
        )

    reciprocal_residual_parameters = [
        parameter for name, parameter in trainable
        if name in _RECIPROCAL_RESIDUAL_LR_PARAMETER_NAMES
    ]
    if (reciprocal_residual_learning_rate is not None
            and not reciprocal_residual_parameters):
        raise ValueError(
            '--reciprocal_residual_lr_decay_factor requires reciprocal '
            'residual parameters'
        )
    inverse_residual_parameters = [
        parameter for name, parameter in trainable
        if name in _INVERSE_RESIDUAL_LR_PARAMETER_NAMES
    ]
    tail_residual_parameters = [
        parameter for name, parameter in trainable
        if name in _TAIL_RESIDUAL_LR_PARAMETER_NAMES
    ]
    if split_residual_lr and not inverse_residual_parameters:
        raise ValueError('model has no inverse residual parameters')
    if split_residual_lr and not tail_residual_parameters:
        raise ValueError('model has no tail residual parameters')

    geometry_ids = {
        id(parameter) for parameter in geometry_parameters
    } if geometry_learning_rate is not None else set()
    relation_ids = {
        id(parameter) for parameter in relation_parameters
    } if relation_learning_rate is not None else set()
    reciprocal_residual_ids = {
        id(parameter) for parameter in reciprocal_residual_parameters
    } if reciprocal_residual_learning_rate is not None else set()
    inverse_residual_ids = {
        id(parameter) for parameter in inverse_residual_parameters
    } if split_residual_lr else set()
    tail_residual_ids = {
        id(parameter) for parameter in tail_residual_parameters
    } if split_residual_lr else set()
    specialized_residual_ids = (
        reciprocal_residual_ids
        | inverse_residual_ids
        | tail_residual_ids
    )
    overlap = (
        geometry_ids & relation_ids
        | geometry_ids & specialized_residual_ids
        | relation_ids & specialized_residual_ids
        | inverse_residual_ids & tail_residual_ids
    )
    if overlap:
        raise ValueError('geometry and relation LR groups overlap')
    base_parameters = [
        parameter for _, parameter in trainable
        if id(parameter) not in (
            geometry_ids | relation_ids | specialized_residual_ids
        )
    ]
    parameter_groups = [
        {'params': base_parameters, 'lr': learning_rate}
    ]
    if geometry_learning_rate is not None:
        parameter_groups.append({
            'params': geometry_parameters,
            'lr': geometry_learning_rate,
        })
    if relation_learning_rate is not None:
        parameter_groups.append({
            'params': relation_parameters,
            'lr': relation_learning_rate,
        })
    if reciprocal_residual_learning_rate is not None:
        parameter_groups.append({
            'params': reciprocal_residual_parameters,
            'lr': reciprocal_residual_learning_rate,
        })
    if split_residual_lr:
        parameter_groups.extend([
            {
                'params': inverse_residual_parameters,
                'lr': inverse_residual_learning_rate,
            },
            {
                'params': tail_residual_parameters,
                'lr': tail_residual_learning_rate,
            },
        ])
    return torch.optim.Adam(parameter_groups)


def residual_learning_rates(args, learning_rate):
    """Return combined or direction-specific residual learning rates."""
    if args.inverse_residual_lr_scale is not None:
        return (
            None,
            learning_rate * args.inverse_residual_lr_scale,
            learning_rate * args.tail_residual_lr_scale,
        )
    combined = (
        learning_rate * args.reciprocal_residual_lr_scale
        if args.reciprocal_residual_lr_decay_factor is not None else None
    )
    return combined, None, None
    
def save_model(model, optimizer, save_variable_list, args, output_path=None):
    '''
    Save the parameters of the model and the optimizer,
    as well as some other variables such as step and learning_rate
    '''
    
    output_path = output_path or args.save_path
    os.makedirs(output_path, exist_ok=True)
    argparse_dict = vars(args)
    with open(os.path.join(output_path, 'config.json'), 'w') as fjson:
        json.dump(argparse_dict, fjson)

    torch.save({
        **save_variable_list,
        **({'double_center_split_complete': getattr(model, 'double_center_split_complete', False)}
           if model.model_name == 'DoubleCenterTransERR' else {}),
        **({'negative_cache_state': model.negative_cache.state_dict()}
           if getattr(model, 'negative_cache', None) is not None else {}),
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict()},
        os.path.join(output_path, 'checkpoint')
    )
    
    entity_embedding = model.entity_embedding.detach().cpu().numpy()
    np.save(
        os.path.join(output_path, 'entity_embedding'), 
        entity_embedding
    )
    
    relation_embedding = model.relation_embedding.detach().cpu().numpy()
    np.save(
        os.path.join(output_path, 'relation_embedding'), 
        relation_embedding
    )

    if hasattr(model, 'clifford_signature_delta'):
        signature = model.effective_clifford_signature().detach().cpu().numpy()
        np.save(os.path.join(output_path, 'clifford_signature'), signature)

    if hasattr(model, 'center_offset'):
        np.save(os.path.join(output_path, 'center_offset'),
                model.center_offset.detach().cpu().numpy())

    if model.model_name == 'RegionTransERR':
        np.save(os.path.join(output_path, 'region_width'),
                model.effective_region_width().detach().cpu().numpy())

    if model.model_name == 'SpectralTransERR':
        np.save(os.path.join(output_path, 'spectral_phase'),
                model.spectral_phase.detach().cpu().numpy())

    if model.model_name == 'KerrTransERR':
        np.save(os.path.join(output_path, 'kerr_coefficients'),
                model.effective_kerr_coefficients().detach().cpu().numpy())

def read_triple(file_path, entity2id, relation2id):
    '''
    Read triples and map them into ids.
    '''
    triples = []
    with open(file_path) as fin:
        for line in fin:
            h, r, t = line.strip().split('\t')
            triples.append((entity2id[h], relation2id[r], entity2id[t]))
    return triples

def set_logger(args):
    '''
    Write logs to checkpoint and console
    '''

    if args.do_train:
        log_file = os.path.join(args.save_path or args.init_checkpoint, 'train.log')
    else:
        log_file = os.path.join(args.save_path or args.init_checkpoint, 'test.log')

    logging.basicConfig(
        format='%(asctime)s %(levelname)-8s %(message)s',
        level=logging.INFO,
        datefmt='%Y-%m-%d %H:%M:%S',
        filename=log_file,
        filemode='a' if args.init_checkpoint else 'w'
    )
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s %(levelname)-8s %(message)s')
    console.setFormatter(formatter)
    logging.getLogger('').addHandler(console)

def log_metrics(mode, step, metrics, writer):
    '''
    Print the evaluation logs
    '''
    for metric in metrics:
        logging.info('%s %s at step %d: %f' % (mode, metric, step, metrics[metric]))
        writer.add_scalar("_".join([mode, metric]), metrics[metric], step)
        
        
def main(args):
    args.save_path = 'log/%s/%s/%s-%s/%s'%(args.model, args.dataset, args.hidden_dim, args.gamma, time.time()) if args.save_path is None else args.save_path

    if args.seed is not None:
        random.seed(args.seed)
        np.random.seed(args.seed)
        torch.manual_seed(args.seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(args.seed)


    if (not args.do_train) and (not args.do_valid) and (not args.do_test):
        raise ValueError('one of train/val/test mode must be choosed.')
    
    if args.init_checkpoint:
        override_config(args)
    elif args.data_path is None:
        raise ValueError('one of init_checkpoint/data_path must be choosed.')

    validate_region_cache_args(args)

    if args.do_train and args.save_path is None:
        raise ValueError('Where do you want to save your trained model?')
    if args.test_best_valid and not args.do_valid:
        raise ValueError('--test_best_valid requires --do_valid')
    if args.lr_decay_factor <= 1.0:
        raise ValueError('--lr_decay_factor must be greater than 1')
    if (args.geometry_lr_decay_factor is not None
            and args.geometry_lr_decay_factor <= 1.0):
        raise ValueError(
            '--geometry_lr_decay_factor must be greater than 1'
        )
    if args.geometry_lr_scale <= 0.0:
        raise ValueError('--geometry_lr_scale must be positive')
    if args.port_regularization < 0.0:
        raise ValueError('--port_regularization must be non-negative')
    if args.translation_regularization < 0.0:
        raise ValueError(
            '--translation_regularization must be non-negative'
        )
    if (args.translation_regularization != 0.0
            and args.model != (
                'BidirectionalResidualReciprocalRelativeQuaternionTransERR'
            )):
        raise ValueError(
            '--translation_regularization currently requires the '
            'v73 BidirectionalResidual model'
        )
    if args.cayley_residual_start_step < 0:
        raise ValueError(
            '--cayley_residual_start_step must be non-negative'
        )
    if args.rank_defect_rows < 0:
        raise ValueError('--rank_defect_rows must be non-negative')
    if args.local_global_rank <= 0:
        raise ValueError('--local_global_rank must be positive')
    if args.rank_defect_max_rank <= 0:
        raise ValueError('--rank_defect_max_rank must be positive')
    if args.rank_defect_degree_scale < 0.0:
        raise ValueError('--rank_defect_degree_scale must be non-negative')
    if args.rank_defect_cayley_bound <= 0.0:
        raise ValueError('--rank_defect_cayley_bound must be positive')
    if args.rank_defect_start_step < 0:
        raise ValueError('--rank_defect_start_step must be non-negative')
    if args.rank_defect_ramp_steps <= 0:
        raise ValueError('--rank_defect_ramp_steps must be positive')
    if (args.relation_lr_decay_factor is not None
            and args.relation_lr_decay_factor <= 1.0):
        raise ValueError(
            '--relation_lr_decay_factor must be greater than 1'
        )
    if (args.reciprocal_residual_lr_decay_factor is not None
            and args.reciprocal_residual_lr_decay_factor <= 1.0):
        raise ValueError(
            '--reciprocal_residual_lr_decay_factor must be greater than 1'
        )
    if args.reciprocal_residual_lr_scale <= 0.0:
        raise ValueError(
            '--reciprocal_residual_lr_scale must be positive'
        )
    split_residual_lr = (
        args.inverse_residual_lr_scale is not None
        or args.tail_residual_lr_scale is not None
    )
    if split_residual_lr:
        if (args.inverse_residual_lr_scale is None
                or args.tail_residual_lr_scale is None):
            raise ValueError(
                '--inverse_residual_lr_scale and '
                '--tail_residual_lr_scale must be set together'
            )
        if (args.inverse_residual_lr_scale <= 0.0
                or args.tail_residual_lr_scale <= 0.0):
            raise ValueError('split residual LR scales must be positive')
        if args.reciprocal_residual_lr_decay_factor is None:
            raise ValueError(
                'split residual LR scales require '
                '--reciprocal_residual_lr_decay_factor'
            )
        if args.model != (
                'BidirectionalResidualReciprocalRelativeQuaternionTransERR'):
            raise ValueError(
                'split residual LR scales currently require the v73 '
                'BidirectionalResidual model'
            )
    if args.reciprocal_cycle_regularization < 0.0:
        raise ValueError(
            '--reciprocal_cycle_regularization must be non-negative'
        )
    if args.reciprocal_cycle_translation_weight < 0.0:
        raise ValueError(
            '--reciprocal_cycle_translation_weight must be non-negative'
        )
    if (args.reciprocal_cycle_regularization != 0.0
            and args.model != (
                'BidirectionalResidualReciprocalRelativeQuaternionTransERR'
            )):
        raise ValueError(
            '--reciprocal_cycle_regularization currently requires the '
            'v73 BidirectionalResidual model'
        )
    if not (0.0 <= args.curriculum_hard_negative_min_ratio
            <= args.curriculum_hard_negative_max_ratio <= 1.0):
        raise ValueError(
            'curriculum hard-negative ratios must satisfy '
            '0 <= min <= max <= 1'
        )
    if (args.relation_pool_negative_ratio > 0.0
            and args.curriculum_hard_negative_max_ratio > 0.0):
        raise ValueError(
            'static and curriculum relation-pool sampling are exclusive'
        )
    if args.curriculum_hard_negative_start_step < 0:
        raise ValueError(
            '--curriculum_hard_negative_start_step must be non-negative'
        )
    if args.curriculum_hard_negative_ramp_steps <= 0:
        raise ValueError(
            '--curriculum_hard_negative_ramp_steps must be positive'
        )
    if args.curriculum_hard_rank_topk <= 0:
        raise ValueError('--curriculum_hard_rank_topk must be positive')
    
    if args.save_path and not os.path.exists(args.save_path):
        os.makedirs(args.save_path)
    
    writer = SummaryWriter(args.save_path)
    
    # Write logs to checkpoint and console
    set_logger(args)


    
    with open(os.path.join(args.data_path, 'entities.dict')) as fin:
        entity2id = dict()
        for line in fin:
            eid, entity = line.strip().split('\t')
            entity2id[entity] = int(eid)

    with open(os.path.join(args.data_path, 'relations.dict')) as fin:
        relation2id = dict()
        for line in fin:
            rid, relation = line.strip().split('\t')
            relation2id[relation] = int(rid)
    
    # Read regions for Countries S* datasets
    if args.countries:
        regions = list()
        with open(os.path.join(args.data_path, 'regions.list')) as fin:
            for line in fin:
                region = line.strip()
                regions.append(entity2id[region])
        args.regions = regions

    nentity = len(entity2id)
    nrelation = len(relation2id)
    
    args.nentity = nentity
    args.nrelation = nrelation
    
    logging.info('Model: %s' % args.model)
    logging.info('Data Path: %s' % args.data_path)
    logging.info('#entity: %d' % nentity)
    logging.info('#relation: %d' % nrelation)

    
    train_triples = read_triple(os.path.join(args.data_path, 'train.txt'), entity2id, relation2id)
    logging.info('#train: %d' % len(train_triples))
    valid_triples = read_triple(os.path.join(args.data_path, 'valid.txt'), entity2id, relation2id)
    logging.info('#valid: %d' % len(valid_triples))
    test_triples = read_triple(os.path.join(args.data_path, 'test.txt'), entity2id, relation2id)
    logging.info('#test: %d' % len(test_triples))
    
    #All true triples
    all_true_triples = train_triples + valid_triples + test_triples

    relation_head_defect_ranks = None
    relation_tail_defect_ranks = None
    if args.model == RANK_DEFECT_LOCAL_GLOBAL_MODEL:
        (relation_head_defect_ranks,
         relation_tail_defect_ranks,
         defect_diagnostics) = relation_cardinality_defect_ranks(
            train_triples,
            nrelation,
            max_rank=args.rank_defect_max_rank,
            scale=args.rank_defect_degree_scale,
        )
        diagnostics_path = os.path.join(
            args.save_path, 'rank_defect_cardinality.json'
        )
        with open(diagnostics_path, 'w') as fout:
            json.dump(defect_diagnostics, fout, indent=2)
        logging.info(
            'Rank-defect head ranks: %s', relation_head_defect_ranks
        )
        logging.info(
            'Rank-defect tail ranks: %s', relation_tail_defect_ranks
        )
    
    if args.double_center_groups != 1 and args.model != 'DoubleCenterTransERR':
        raise ValueError('Grouped centers require DoubleCenterTransERR')
    if args.double_center_groups != 1 and args.double_center_init_method != 'random':
        raise ValueError('Grouped centers currently require random initialization')
    if args.model == 'DoubleCenterTransERR' and (
            not math.isfinite(args.double_center_regularization)
            or args.double_center_regularization < 0):
        raise ValueError('double_center_regularization must be finite and nonnegative')
    if args.double_center_init_method == 'residual_kmedians':
        if args.model != 'DoubleCenterTransERR':
            raise ValueError('Residual initialization requires DoubleCenterTransERR')
        if args.double_center_split_step < 1 or args.double_center_cluster_iterations < 1:
            raise ValueError('Double-center split step and clustering iterations must be positive')
        if args.do_train and args.double_center_split_step >= args.max_steps:
            raise ValueError('Double-center split must occur before max_steps')

    kge_model = KGEModel(
        model_name=args.model,
        nentity=nentity,
        nrelation=nrelation,
        hidden_dim=args.hidden_dim,
        gamma=args.gamma,
        double_center_temperature=args.double_center_temperature,
        double_center_init_scale=args.double_center_init_scale,
        double_center_groups=args.double_center_groups,
        region_width_bound=args.region_width_bound,
        region_width_init_fraction=args.region_width_init_fraction,
        region_inner_weight=args.region_inner_weight,
        kerr_phase_bound=args.kerr_phase_bound,
        kerr_intensity_scale=args.kerr_intensity_scale,
        local_ot_window=args.local_ot_window,
        local_ot_temperature=args.local_ot_temperature,
        local_ot_prior_mix=args.local_ot_prior_mix,
        local_ot_chunk_size=args.local_ot_chunk_size,
        local_ot_max_iter=args.local_ot_max_iter,
        local_ot_tolerance=args.local_ot_tolerance,
        local_ot_identity=args.local_ot_identity,
        quadratic_rank=args.quadratic_rank,
        quadratic_bound=args.quadratic_bound,
        quadratic_self_init=args.quadratic_self_init,
        quadratic_cross_weight=args.quadratic_cross_weight,
        quadratic_self_weight=args.quadratic_self_weight,
        bures_stretch_bound=args.bures_stretch_bound,
        bures_diagonal_floor=args.bures_diagonal_floor,
        bures_jitter=args.bures_jitter,
        bures_smoothing=args.bures_smoothing,
        bures_distance_scale=args.bures_distance_scale,
        bures_pair_chunk=args.bures_pair_chunk,
        double_entity_embedding=args.double_entity_embedding,
        double_relation_embedding=args.double_relation_embedding,
        triple_relation_embedding=args.triple_relation_embedding,
        context_rank=args.context_rank,
        context_gate_init=args.context_gate_init,
        context_delta_bound=args.context_delta_bound,
        scale_bound=args.scale_bound,
        complex_dim=args.complex_dim,
        hyperbolic_dim=args.hyperbolic_dim,
        router_temperature=args.router_temperature,
        dual_gate_init=args.dual_gate_init,
        dual_weight_bound=args.dual_weight_bound,
        dual_init_scale=args.dual_init_scale,
        biquaternion_fusion_bound=args.biquaternion_fusion_bound,
        biquaternion_fusion_gate_init=(
            args.biquaternion_fusion_gate_init
        ),
        subspace_groups=args.subspace_groups,
        lie_angle_bound=args.lie_angle_bound,
        screw_distance_bound=args.screw_distance_bound,
        mobius_c_bound=args.mobius_c_bound,
        mobius_denominator_epsilon=args.mobius_denominator_epsilon,
        frame_temperature=args.frame_temperature,
        frame_relative_prior=args.frame_relative_prior,
        frame_min_weight=args.frame_min_weight,
        block_frame_temperature=args.block_frame_temperature,
        block_frame_relative_prior=args.block_frame_relative_prior,
        block_frame_min_weight=args.block_frame_min_weight,
        orthogonal_temperature=args.orthogonal_temperature,
        orthogonal_cayley_prior=args.orthogonal_cayley_prior,
        residual_so4_bound=args.residual_so4_bound,
        relation_bias_bound=args.relation_bias_bound,
        role_delta_bound=args.role_delta_bound,
        reciprocal_residual_bound=args.reciprocal_residual_bound,
        soft_extremal_group_size=args.soft_extremal_group_size,
        soft_extremal_temperature=args.soft_extremal_temperature,
        soft_extremal_gate_init=args.soft_extremal_gate_init,
        max_mean_group_size=args.max_mean_group_size,
        max_mean_gate_init=args.max_mean_gate_init,
        mean_variance_group_size=args.mean_variance_group_size,
        mean_variance_temperature=args.mean_variance_temperature,
        mean_variance_gate_init=args.mean_variance_gate_init,
        pmean_group_size=args.pmean_group_size,
        pmean_exponent_bound=args.pmean_exponent_bound,
        pmean_exponent_init=args.pmean_exponent_init,
        householder_group_dim=args.householder_group_dim,
        householder_shear_bound=args.householder_shear_bound,
        kronecker_identity_floor=args.kronecker_identity_floor,
        cartan_stretch_bound=args.cartan_stretch_bound,
        port_block_dim=args.port_block_dim,
        port_steps=args.port_steps,
        port_rotation_bound=args.port_rotation_bound,
        port_damping_bound=args.port_damping_bound,
        port_damping_init=args.port_damping_init,
        port_nonlinear_bound=args.port_nonlinear_bound,
        port_log_scale_bound=args.port_log_scale_bound,
        quaternion_operator_bound=args.quaternion_operator_bound,
        polar_rank=args.polar_rank,
        polar_bound=args.polar_bound,
        flow_rank=args.flow_rank,
        flow_scale_bound=args.flow_scale_bound,
        flow_shift_bound=args.flow_shift_bound,
        cayley_residual_start_step=args.cayley_residual_start_step,
        rank_defect_rows=args.rank_defect_rows,
        local_global_rank=args.local_global_rank,
        rank_defect_max_rank=args.rank_defect_max_rank,
        rank_defect_cayley_bound=args.rank_defect_cayley_bound,
        rank_defect_start_step=args.rank_defect_start_step,
        rank_defect_ramp_steps=args.rank_defect_ramp_steps,
        relation_head_defect_ranks=relation_head_defect_ranks,
        relation_tail_defect_ranks=relation_tail_defect_ranks,
        
    )
    
    logging.info('Model Parameter Configuration:')
    for name, param in kge_model.named_parameters():
        logging.info('Parameter %s: %s, require_grad = %s' % (name, str(param.size()), str(param.requires_grad)))

    if args.cuda:
        kge_model = kge_model.cuda()
    
    if args.do_train:
        # Set training dataloader iterator
        train_dataloader_head = DataLoader(
            TrainDataset(
                train_triples, nentity, nrelation,
                args.negative_sample_size, 'head-batch',
                relation_pool_negative_ratio=(
                    args.relation_pool_negative_ratio
                ),
                curriculum_hard_negative_min_ratio=(
                    args.curriculum_hard_negative_min_ratio
                ),
                curriculum_hard_negative_max_ratio=(
                    args.curriculum_hard_negative_max_ratio
                ),
            ),
            batch_size=args.batch_size,
            shuffle=True, 
            num_workers=max(1, args.cpu_num//2),
            collate_fn=TrainDataset.collate_fn
        )
        
        train_dataloader_tail = DataLoader(
            TrainDataset(
                train_triples, nentity, nrelation,
                args.negative_sample_size, 'tail-batch',
                relation_pool_negative_ratio=(
                    args.relation_pool_negative_ratio
                ),
                curriculum_hard_negative_min_ratio=(
                    args.curriculum_hard_negative_min_ratio
                ),
                curriculum_hard_negative_max_ratio=(
                    args.curriculum_hard_negative_max_ratio
                ),
            ),
            batch_size=args.batch_size,
            shuffle=True, 
            num_workers=max(1, args.cpu_num//2),
            collate_fn=TrainDataset.collate_fn
        )
        
        train_iterator = BidirectionalOneShotIterator(train_dataloader_head, train_dataloader_tail)
        
        # Set training configuration
        current_learning_rate = args.learning_rate
        current_geometry_learning_rate = (
            args.learning_rate * args.geometry_lr_scale
            if args.geometry_lr_decay_factor is not None else None
        )
        current_relation_learning_rate = (
            args.learning_rate
            if args.relation_lr_decay_factor is not None else None
        )
        (current_reciprocal_residual_learning_rate,
         current_inverse_residual_learning_rate,
         current_tail_residual_learning_rate) = residual_learning_rates(
            args, args.learning_rate
        )
        optimizer = build_optimizer(
            kge_model,
            current_learning_rate,
            current_geometry_learning_rate,
            current_relation_learning_rate,
            current_reciprocal_residual_learning_rate,
            current_inverse_residual_learning_rate,
            current_tail_residual_learning_rate,
        )
        if args.warm_up_steps:
            warm_up_steps = args.warm_up_steps
        else:
            warm_up_steps = args.max_steps // 2

    if args.init_checkpoint:
        # Restore model from checkpoint directory
        logging.info('Loading checkpoint %s...' % args.init_checkpoint)
        checkpoint = torch.load(os.path.join(args.init_checkpoint, 'checkpoint'))
        init_step = checkpoint['step']
        restored_best_valid_mrr = checkpoint.get('best_valid_mrr')
        kge_model.load_state_dict(checkpoint['model_state_dict'])
        if args.do_train:
            current_learning_rate = checkpoint['current_learning_rate']
            current_geometry_learning_rate = checkpoint.get(
                'current_geometry_learning_rate',
                (current_learning_rate * args.geometry_lr_scale
                 if args.geometry_lr_decay_factor is not None else None),
            )
            current_relation_learning_rate = checkpoint.get(
                'current_relation_learning_rate',
                (current_learning_rate
                 if args.relation_lr_decay_factor is not None else None),
            )
            current_reciprocal_residual_learning_rate = checkpoint.get(
                'current_reciprocal_residual_learning_rate',
                residual_learning_rates(args, current_learning_rate)[0],
            )
            current_inverse_residual_learning_rate = checkpoint.get(
                'current_inverse_residual_learning_rate',
                residual_learning_rates(args, current_learning_rate)[1],
            )
            current_tail_residual_learning_rate = checkpoint.get(
                'current_tail_residual_learning_rate',
                residual_learning_rates(args, current_learning_rate)[2],
            )
            warm_up_steps = checkpoint['warm_up_steps']
            optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
            if args.override_init_learning_rate:
                current_learning_rate = args.learning_rate
                current_geometry_learning_rate = (
                    args.learning_rate * args.geometry_lr_scale
                    if args.geometry_lr_decay_factor is not None else None
                )
                current_relation_learning_rate = (
                    args.learning_rate
                    if args.relation_lr_decay_factor is not None else None
                )
                (current_reciprocal_residual_learning_rate,
                 current_inverse_residual_learning_rate,
                 current_tail_residual_learning_rate) = (
                    residual_learning_rates(args, args.learning_rate)
                )
                reset_learning_rates = [current_learning_rate]
                if current_geometry_learning_rate is not None:
                    reset_learning_rates.append(current_geometry_learning_rate)
                if current_relation_learning_rate is not None:
                    reset_learning_rates.append(current_relation_learning_rate)
                if current_reciprocal_residual_learning_rate is not None:
                    reset_learning_rates.append(
                        current_reciprocal_residual_learning_rate
                    )
                if current_inverse_residual_learning_rate is not None:
                    reset_learning_rates.append(
                        current_inverse_residual_learning_rate
                    )
                if current_tail_residual_learning_rate is not None:
                    reset_learning_rates.append(
                        current_tail_residual_learning_rate
                    )
                for group, learning_rate in zip(
                        optimizer.param_groups, reset_learning_rates):
                    group['lr'] = learning_rate
    else:
        logging.info('Ramdomly Initializing %s Model...' % args.model)
        init_step = 0
        restored_best_valid_mrr = None

    configure_double_center_stage(
        kge_model, args.double_center_init_method,
        checkpoint if args.init_checkpoint else None,
    )
    configure_negative_cache(kge_model, args, train_triples,
                             checkpoint if args.init_checkpoint else None)
    if getattr(kge_model, 'double_center_warmup_active', False):
        logging.info('Ordinary TransERR warmup until %d completed updates; then train-only residual initialization',
                     args.double_center_split_step)

    step = init_step
    
    logging.info('Start Training...')
    logging.info('init_step = %d' % init_step)
    logging.info('batch_size = %d' % args.batch_size)
    logging.info('negative_adversarial_sampling = %d' % args.negative_adversarial_sampling)
    logging.info(
        'relation_pool_negative_ratio = %f',
        args.relation_pool_negative_ratio
    )
    logging.info(
        'curriculum_hard_negative_ratio = [%f, %f]',
        args.curriculum_hard_negative_min_ratio,
        args.curriculum_hard_negative_max_ratio
    )
    logging.info(
        'curriculum_hard_negative_schedule = start %d, ramp %d',
        args.curriculum_hard_negative_start_step,
        args.curriculum_hard_negative_ramp_steps
    )
    logging.info('hidden_dim = %d' % args.hidden_dim)
    logging.info('gamma = %f' % args.gamma)
    logging.info('negative_adversarial_sampling = %s' % str(args.negative_adversarial_sampling))
    if args.negative_adversarial_sampling:
        logging.info('adversarial_temperature = %f' % args.adversarial_temperature)
    
    # Set valid dataloader as it would be evaluated during training
    
    if args.do_train:
        logging.info('learning_rate = %.8g' % current_learning_rate)
        if current_geometry_learning_rate is not None:
            logging.info(
                'geometry_learning_rate = %.8g',
                current_geometry_learning_rate,
            )
        if current_relation_learning_rate is not None:
            logging.info(
                'relation_learning_rate = %.8g',
                current_relation_learning_rate,
            )
        if current_reciprocal_residual_learning_rate is not None:
            logging.info(
                'reciprocal_residual_learning_rate = %.8g',
                current_reciprocal_residual_learning_rate,
            )
        if current_inverse_residual_learning_rate is not None:
            logging.info(
                'inverse_residual_learning_rate = %.8g',
                current_inverse_residual_learning_rate,
            )
        if current_tail_residual_learning_rate is not None:
            logging.info(
                'tail_residual_learning_rate = %.8g',
                current_tail_residual_learning_rate,
            )

        training_logs = []
        decay_steps = {
            int(round(args.max_steps * ratio))
            for ratio in args.warm_up_ratio
            if 0.0 < ratio < 1.0
        }
        best_valid_mrr = (
            restored_best_valid_mrr
            if restored_best_valid_mrr is not None else float('-inf')
        )
        best_valid_path = os.path.join(args.save_path, 'best_valid')
        
        #Training Loop
        for step in range(init_step, args.max_steps):
            if (getattr(kge_model, 'double_center_warmup_active', False)
                    and step >= args.double_center_split_step):
                logging.info('Initializing double centers from training residuals before update %d', step)
                report = initialize_double_centers_from_train(
                    kge_model, train_triples, optimizer,
                    {rid: name for name, rid in relation2id.items()},
                    max_iterations=args.double_center_cluster_iterations,
                )
                report['completed_updates'] = step
                report_path = os.path.join(args.save_path, 'center_initialization.json')
                with open(report_path + '.tmp', 'w') as handle:
                    json.dump(report, handle, indent=2)
                    handle.write('\n')
                os.replace(report_path + '.tmp', report_path)
                logging.info('Double-center initialization complete: %d relations updated; %s',
                             report['relations_updated'], report_path)

            log = kge_model.train_step(
                kge_model, optimizer, train_iterator, args, step=step
            )
            
            training_logs.append(log)
            
            if step in decay_steps:
                current_learning_rate /= args.lr_decay_factor
                logging.info('Change learning_rate to %f at step %d' % (current_learning_rate, step))
                if current_geometry_learning_rate is not None:
                    current_geometry_learning_rate /= (
                        args.geometry_lr_decay_factor
                    )
                    logging.info(
                        'Change geometry_learning_rate to %f at step %d',
                        current_geometry_learning_rate,
                        step,
                    )
                if current_relation_learning_rate is not None:
                    current_relation_learning_rate /= (
                        args.relation_lr_decay_factor
                    )
                    logging.info(
                        'Change relation_learning_rate to %f at step %d',
                        current_relation_learning_rate,
                        step,
                    )
                if current_reciprocal_residual_learning_rate is not None:
                    current_reciprocal_residual_learning_rate /= (
                        args.reciprocal_residual_lr_decay_factor
                    )
                    logging.info(
                        'Change reciprocal_residual_learning_rate to %f '
                        'at step %d',
                        current_reciprocal_residual_learning_rate,
                        step,
                    )
                if current_inverse_residual_learning_rate is not None:
                    current_inverse_residual_learning_rate /= (
                        args.reciprocal_residual_lr_decay_factor
                    )
                    logging.info(
                        'Change inverse_residual_learning_rate to %f '
                        'at step %d',
                        current_inverse_residual_learning_rate,
                        step,
                    )
                if current_tail_residual_learning_rate is not None:
                    current_tail_residual_learning_rate /= (
                        args.reciprocal_residual_lr_decay_factor
                    )
                    logging.info(
                        'Change tail_residual_learning_rate to %f '
                        'at step %d',
                        current_tail_residual_learning_rate,
                        step,
                    )
                optimizer = build_optimizer(
                    kge_model,
                    current_learning_rate,
                    current_geometry_learning_rate,
                    current_relation_learning_rate,
                    current_reciprocal_residual_learning_rate,
                    current_inverse_residual_learning_rate,
                    current_tail_residual_learning_rate,
                )
            
            if step % args.save_checkpoint_steps == 0:
                save_variable_list = {
                    'step': step, 
                    'current_learning_rate': current_learning_rate,
                    'current_geometry_learning_rate':
                        current_geometry_learning_rate,
                    'current_relation_learning_rate':
                        current_relation_learning_rate,
                    'current_reciprocal_residual_learning_rate':
                        current_reciprocal_residual_learning_rate,
                    'current_inverse_residual_learning_rate':
                        current_inverse_residual_learning_rate,
                    'current_tail_residual_learning_rate':
                        current_tail_residual_learning_rate,
                    'warm_up_steps': warm_up_steps,
                    'best_valid_mrr': best_valid_mrr
                }
                save_model(kge_model, optimizer, save_variable_list, args)
                
            if step % args.log_steps == 0:
                metrics = {}
                for metric in training_logs[0].keys():
                    metrics[metric] = sum([log[metric] for log in training_logs])/len(training_logs)
                log_metrics('Training average', step, metrics, writer)
                training_logs = []
                
            if args.do_valid and step % args.valid_steps == 0:
                logging.info('Evaluating on Valid Dataset...')
                metrics = kge_model.test_step(kge_model, valid_triples, all_true_triples, args)
                log_metrics('Valid', step, metrics, writer)
                save_center_diagnostics(kge_model, train_triples, relation2id, args, step)
                save_region_diagnostics(kge_model, train_triples, relation2id, args, step)
                save_spectral_diagnostics(kge_model, relation2id, args, step)
                save_nonlinear_endpoint_diagnostics(kge_model, relation2id, args, step)
                save_local_ot_diagnostics(kge_model, args, step)
                save_pair_geometry_diagnostics(kge_model, args, step)
                save_spin_diagnostics(kge_model, args, step)
                if args.save_best_valid and metrics['MRR'] > best_valid_mrr:
                    best_valid_mrr = metrics['MRR']
                    save_model(
                        kge_model, optimizer, {
                            'step': step,
                            'current_learning_rate': current_learning_rate,
                            'current_geometry_learning_rate':
                                current_geometry_learning_rate,
                            'current_relation_learning_rate':
                                current_relation_learning_rate,
                            'current_reciprocal_residual_learning_rate':
                                current_reciprocal_residual_learning_rate,
                            'current_inverse_residual_learning_rate':
                                current_inverse_residual_learning_rate,
                            'current_tail_residual_learning_rate':
                                current_tail_residual_learning_rate,
                            'warm_up_steps': warm_up_steps,
                            'best_valid_mrr': best_valid_mrr
                        }, args, output_path=best_valid_path
                    )
                    logging.info(
                        'Saved new best Valid MRR %.6f at step %d',
                        best_valid_mrr, step
                    )
        
        save_variable_list = {
            'step': step, 
            'current_learning_rate': current_learning_rate,
            'current_geometry_learning_rate': current_geometry_learning_rate,
            'current_relation_learning_rate': current_relation_learning_rate,
            'current_reciprocal_residual_learning_rate':
                current_reciprocal_residual_learning_rate,
            'current_inverse_residual_learning_rate':
                current_inverse_residual_learning_rate,
            'current_tail_residual_learning_rate':
                current_tail_residual_learning_rate,
            'warm_up_steps': warm_up_steps,
            'best_valid_mrr': best_valid_mrr
        }
        save_model(kge_model, optimizer, save_variable_list, args)
        
    if args.do_valid:
        logging.info('Evaluating on Valid Dataset...')
        metrics = kge_model.test_step(kge_model, valid_triples, all_true_triples, args)
        log_metrics('Valid', step, metrics, writer)
        if args.do_train:
            save_center_diagnostics(kge_model, train_triples, relation2id, args, step)
            save_region_diagnostics(kge_model, train_triples, relation2id, args, step)
            save_spectral_diagnostics(kge_model, relation2id, args, step)
            save_nonlinear_endpoint_diagnostics(kge_model, relation2id, args, step)
            save_local_ot_diagnostics(kge_model, args, step)
            save_pair_geometry_diagnostics(kge_model, args, step)
            save_spin_diagnostics(kge_model, args, step)
        if args.do_train and args.save_best_valid and metrics['MRR'] > best_valid_mrr:
            best_valid_mrr = metrics['MRR']
            save_model(
                kge_model, optimizer, {
                    'step': step,
                    'current_learning_rate': current_learning_rate,
                    'current_geometry_learning_rate':
                        current_geometry_learning_rate,
                    'current_relation_learning_rate':
                        current_relation_learning_rate,
                    'current_reciprocal_residual_learning_rate':
                        current_reciprocal_residual_learning_rate,
                    'current_inverse_residual_learning_rate':
                        current_inverse_residual_learning_rate,
                    'current_tail_residual_learning_rate':
                        current_tail_residual_learning_rate,
                    'warm_up_steps': warm_up_steps,
                    'best_valid_mrr': best_valid_mrr
                }, args, output_path=best_valid_path
            )
            logging.info(
                'Saved new best Valid MRR %.6f at step %d',
                best_valid_mrr, step
            )
    
    if args.do_test:
        if args.test_best_valid:
            best_valid_path = os.path.join(args.save_path, 'best_valid')
            checkpoint = torch.load(
                os.path.join(best_valid_path, 'checkpoint'),
                map_location='cpu'
            )
            kge_model.load_state_dict(checkpoint['model_state_dict'])
            configure_double_center_stage(kge_model, args.double_center_init_method, checkpoint)
            if args.cuda:
                kge_model = kge_model.cuda()
            step = checkpoint['step']
            logging.info('Loaded best Valid checkpoint from step %d', step)
        logging.info('Evaluating on Test Dataset...')
        metrics = kge_model.test_step(kge_model, test_triples, all_true_triples, args)
        log_metrics('Test', step, metrics,writer)
    
    if args.evaluate_train:
        logging.info('Evaluating on Training Dataset...')
        metrics = kge_model.test_step(kge_model, train_triples, all_true_triples, args)
        log_metrics('Train', step, metrics,writer)
        
if __name__ == '__main__':
    main(parse_args())
