"""Trainer-owned, query-specific hard-negative caches with train-only filtering."""

import hashlib

import numpy as np
import torch


class PersistentNegativeCache:
    def __init__(self, train_triples, nentity, capacity=64, draw_size=64,
                 score_batch_size=64, seed=0):
        if min(nentity, capacity, draw_size, score_batch_size) < 1:
            raise ValueError('Negative cache sizes must be positive')
        triples = np.asarray(train_triples, dtype=np.int64)
        if triples.ndim != 2 or triples.shape[1] != 3 or not len(triples):
            raise ValueError('Cache requires nonempty training triples')
        if triples.min() < 0 or triples[:, (0, 2)].max() >= nentity:
            raise ValueError('Training entity IDs are out of range')
        self.nentity = int(nentity)
        self.capacity = int(capacity)
        self.draw_size = int(draw_size)
        self.score_batch_size = int(score_batch_size)
        self.training_digest = hashlib.sha256(triples.tobytes()).hexdigest()
        true = {}
        for head, relation, tail in triples.tolist():
            true.setdefault((0, relation, tail), set()).add(head)
            true.setdefault((1, relation, head), set()).add(tail)
        self.true = {key: np.asarray(sorted(values), dtype=np.int64) for key, values in true.items()}
        if any(len(values) >= nentity for values in self.true.values()):
            raise ValueError('A training query has no available negative entity')
        self.entries = {}
        self.rng = np.random.RandomState(int(seed) % (2 ** 32))

    def _valid_mask(self, values, key):
        return ((values >= 0) & (values < self.nentity)
                & ~np.isin(values, self.true[key]))

    def _uniform(self, key, size):
        if len(self.true[key]) > self.nentity // 2:
            allowed = np.setdiff1d(np.arange(self.nentity), self.true[key])
            return self.rng.choice(allowed, size=size)
        result = []
        remaining = size
        while remaining:
            values = self.rng.randint(self.nentity, size=max(2 * remaining, 16))
            values = values[self._valid_mask(values, key)][:remaining]
            result.append(values)
            remaining -= len(values)
        return np.concatenate(result)

    @torch.no_grad()
    def sample(self, model, positive, uniform_negative, mode):
        if model.model_name not in ('TransERR', 'RegionTransERR'):
            raise ValueError('Negative cache currently supports original and region TransERR only')
        if mode not in ('head-batch', 'tail-batch'):
            raise ValueError('Cache requires head-batch or tail-batch')
        if positive.ndim != 2 or positive.shape[1] != 3 or not len(positive):
            raise ValueError('Expected a nonempty positive triple batch')
        if (uniform_negative.ndim != 2 or len(uniform_negative) != len(positive)
                or self.draw_size >= uniform_negative.shape[1]):
            raise ValueError('Cache must leave at least one uniform negative per query')
        triples = positive.detach().cpu().numpy()
        negatives = uniform_negative.detach().cpu().numpy().copy()
        direction, fixed_column = (0, 2) if mode == 'head-batch' else (1, 0)
        keys = [(direction, int(row[1]), int(row[fixed_column])) for row in triples]
        first_rows, hits = {}, 0
        for row, key in enumerate(keys):
            if key not in self.true:
                raise ValueError('Cache received a query absent from the training set')
            target_column = 0 if mode == 'head-batch' else 2
            if triples[row, target_column] not in self.true[key]:
                raise ValueError('Cache received a positive absent from the training set')
            mask = self._valid_mask(negatives[row], key)
            if not mask.all():
                negatives[row, ~mask] = self._uniform(key, int((~mask).sum()))
            hits += int(key in self.entries)
            first_rows.setdefault(key, row)

        unique_keys = list(first_rows)
        pools = []
        for key in unique_keys:
            # One refresh per query per batch bounds duplicate-query scoring cost.
            old = self.entries.get(key, np.empty(0, dtype=np.int64))
            pool = np.unique(np.concatenate((old, negatives[first_rows[key]])))
            pools.append(pool[self._valid_mask(pool, key)])
        updates = {}
        device = model.entity_embedding.device
        for start in range(0, len(unique_keys), self.score_batch_size):
            selected_keys = unique_keys[start:start + self.score_batch_size]
            selected_pools = pools[start:start + self.score_batch_size]
            candidates = np.empty((len(selected_keys), max(map(len, selected_pools))), dtype=np.int64)
            for row, pool in enumerate(selected_pools):
                candidates[row] = pool[0]
                candidates[row, :len(pool)] = pool
            query = torch.as_tensor(triples[[first_rows[key] for key in selected_keys]], device=device)
            values = model((query, torch.as_tensor(candidates, device=device)), mode).detach().cpu().numpy()
            if not np.isfinite(values).all():
                raise ValueError('Nonfinite scores during negative-cache refresh')
            for row, (key, pool) in enumerate(zip(selected_keys, selected_pools)):
                # Pools are ID-sorted; stable sorting gives deterministic score ties.
                order = np.argsort(-values[row, :len(pool)], kind='stable')[:self.capacity]
                updates[key] = pool[order].copy()
        self.entries.update(updates)
        for row, key in enumerate(keys):
            entry = self.entries[key]
            negatives[row, -self.draw_size:] = self.rng.choice(
                entry, size=self.draw_size, replace=len(entry) < self.draw_size)
        return torch.as_tensor(negatives, device=uniform_negative.device), {
            'negative_cache_fraction': self.draw_size / negatives.shape[1],
            'negative_cache_hit_fraction': hits / len(keys),
            'negative_cache_queries': float(len(self.entries)),
            'negative_cache_refresh_candidates': float(np.mean([len(pool) for pool in pools])),
        }

    def state_dict(self):
        algorithm, keys, position, has_gauss, cached_gaussian = self.rng.get_state()
        return {
            'version': 1, 'training_digest': self.training_digest,
            'nentity': self.nentity, 'capacity': self.capacity, 'draw_size': self.draw_size,
            'score_batch_size': self.score_batch_size,
            'entries': {key: torch.from_numpy(value.copy()) for key, value in self.entries.items()},
            'rng': (algorithm, torch.from_numpy(keys.astype(np.int64)), position,
                    has_gauss, cached_gaussian),
        }

    def load_state_dict(self, state):
        expected = {'version': 1, 'training_digest': self.training_digest,
                    'nentity': self.nentity, 'capacity': self.capacity,
                    'draw_size': self.draw_size, 'score_batch_size': self.score_batch_size}
        if any(state.get(key) != value for key, value in expected.items()):
            raise ValueError('Negative-cache checkpoint does not match training data or configuration')
        entries = {}
        for key, tensor in state['entries'].items():
            if key not in self.true or tensor.dtype != torch.long or tensor.ndim != 1:
                raise ValueError('Invalid cached query or entity tensor')
            values = tensor.detach().cpu().numpy().copy()
            if (not 0 < len(values) <= self.capacity or len(np.unique(values)) != len(values)
                    or not self._valid_mask(values, key).all()):
                raise ValueError('Cached entries contain duplicates or invalid/known-positive entities')
            entries[key] = values
        algorithm, keys, position, has_gauss, cached_gaussian = state['rng']
        rng = np.random.RandomState(0)
        rng.set_state((algorithm, keys.cpu().numpy().astype(np.uint32), position,
                       has_gauss, cached_gaussian))
        self.entries, self.rng = entries, rng
