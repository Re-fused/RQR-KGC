"""Training utilities shared by TransERR entry points."""

