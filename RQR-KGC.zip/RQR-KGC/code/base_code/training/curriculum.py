"""Curriculum hard-negative sampling and grouped loss helpers."""

import numpy as np
import torch
import torch.nn.functional as F


def adaptive_hard_count_cap(
        relation_pool_size, nentity, negative_sample_size,
        min_ratio, max_ratio, hard_available):
    """Cap hard negatives using relation-pool coverage."""
    coverage = relation_pool_size / float(nentity)
    hard_ratio_cap = np.clip(
        max_ratio * (1.0 - coverage), min_ratio, max_ratio
    )
    return min(
        int(round(negative_sample_size * hard_ratio_cap)),
        hard_available,
    )


def curriculum_progress(step, start_step, ramp_steps):
    """Return the linear curriculum progress in the closed interval [0, 1]."""
    if step <= start_step:
        return 0.0
    return min(1.0, (step - start_step) / float(ramp_steps))


def select_curriculum_negatives(
        uniform_negative, hard_negative, hard_count_cap, progress):
    """Replace the final uniform candidates with scheduled hard candidates."""
    if uniform_negative.dim() != 2 or hard_negative.dim() != 2:
        raise ValueError('curriculum negative samples must be matrices')
    if uniform_negative.size(0) != hard_negative.size(0):
        raise ValueError('uniform and hard batches must have equal size')
    if hard_count_cap.shape != uniform_negative.shape[:1]:
        raise ValueError('hard_count_cap must contain one value per query')
    if not 0.0 <= progress <= 1.0:
        raise ValueError('curriculum progress must be between 0 and 1')

    negative_size = uniform_negative.size(1)
    hard_size = hard_negative.size(1)
    hard_count = torch.round(
        hard_count_cap.float() * progress
    ).long().clamp(min=0, max=min(negative_size, hard_size))
    position = torch.arange(
        negative_size, device=uniform_negative.device
    ).unsqueeze(0)
    hard_start = negative_size - hard_count.unsqueeze(1)
    hard_mask = position >= hard_start
    hard_index = (position - hard_start).clamp(
        min=0, max=max(0, hard_size - 1)
    )
    selected_hard = torch.gather(
        hard_negative, dim=1, index=hard_index
    )
    selected = torch.where(hard_mask, selected_hard, uniform_negative)
    return selected, hard_mask, hard_count


def masked_negative_log_likelihood(
        raw_negative_score, mask, adversarial, temperature):
    """Reduce one negative group while ignoring candidates outside its mask."""
    valid = mask.any(dim=1)
    mask_float = mask.to(raw_negative_score.dtype)
    log_likelihood = F.logsigmoid(-raw_negative_score)
    if adversarial:
        logits = (
            raw_negative_score * temperature
        ).masked_fill(~mask, float('-inf'))
        logits = torch.where(
            valid.unsqueeze(1), logits, torch.zeros_like(logits)
        )
        weight = F.softmax(logits, dim=1).detach() * mask_float
        weight = weight / weight.sum(dim=1, keepdim=True).clamp_min(1.0)
        score = (weight * log_likelihood).sum(dim=1)
    else:
        score = (
            mask_float * log_likelihood
        ).sum(dim=1) / mask_float.sum(dim=1).clamp_min(1.0)
    return score, valid

