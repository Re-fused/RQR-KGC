#!/usr/bin/python3

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import logging
import math

import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint as activation_checkpoint


from torch.utils.data import DataLoader

from dataloader import TestDataset
from models.adaptive_metric_clifford import (
    adaptive_metric_clifford_product,
)
from models.bidirectional_relative_quaternion import (
    analytic_inverse_relative_relation,
    apply_bounded_relation_residual,
    reciprocal_cycle_consistency,
    relative_relation_frames,
    score_relative_quaternion,
)
from models.biquaternion import (
    biquaternion_product,
    normalize_biquaternion,
)
from models.double_center import grouped_double_center_distance
from models.region import region_distance
from models.spectral import spectral_mix
from models.nonlinear_phase import fold_transform, kerr_transform
from models.local_ot import local_ot_distance, validate_local_ot
from models.implicit_quadratic import quadratic_correction
from models.bures_state import affine_state, bures_distance
from models.higher_spin import SPIN_MODELS, apply_spin_operator, spin_operator, split_spin_relation
from models.mixed_spin import (
    MIXED_SPIN_MODEL, apply_mixed_spin, compact_mixed_frame,
    mixed_spin_dimensions, split_mixed_relation,
)
from models.cayley_residual import (
    full_plane_coefficients,
    pack_cayley_generator,
    rank2_plane_coefficients,
)
from models.quaternion import (
    hamilton_product,
    normalize_quaternion,
    quaternion_conjugate,
)
from models.matrix_algebra import (
    complex_matrix2_product,
    normalize_complex_matrix2,
    normalize_real_matrix2,
    real_matrix2_product,
    residual_kronecker_complex_matrix2,
)
from models.householder_shear import apply_householder_shear
from models.midpoint_cartan_complex import midpoint_cartan_frames
from models.port_hamiltonian import (
    cayley_split_port_hamiltonian_flow,
    laplace_endpoint_distance,
    port_hamiltonian_flow,
)
from models.rank_quaternion_operator import (
    geodesic_rank_quaternion_transform,
    rank_quaternion_transform,
)
from models.rank_defect_local_global import (
    balanced_matrix_shape,
    local_global_rank_defect_transform,
)
from training.curriculum import (
    curriculum_progress,
    masked_negative_log_likelihood,
    select_curriculum_negatives as select_scheduled_negatives,
)


_CAYLEY_RESIDUAL_RECIPROCAL_MODELS = (
    'FullCayleyBidirectionalResidualReciprocalRelativeQuaternionTransERR',
    'Rank2CayleyBidirectionalResidualReciprocalRelativeQuaternionTransERR',
)

_PORT_HAMILTONIAN_MODELS = (
    'PortHamiltonianTransERR',
    'StochasticPortHamiltonianTransERR',
    'CayleyPortHamiltonianTransERR',
)

_RANK_QUATERNION_OPERATOR_MODELS = {
    'Rank2QuaternionOperatorTransERR': 2,
    'Rank4QuaternionOperatorTransERR': 4,
    'GeodesicRank2QuaternionTransERR': 2,
}

_GEODESIC_RANK_QUATERNION_MODELS = frozenset({
    'GeodesicRank2QuaternionTransERR',
})

_CONJUGATE_GATED_RECIPROCAL_MODELS = frozenset({
    'ConjugateGatedBidirectionalResidualReciprocalRelativeQuaternionTransERR',
    'InverseConjugateGatedBidirectionalResidualReciprocalRelativeQuaternionTransERR',
})

_COUPLED_TRANSLATION_RESIDUAL_MODELS = frozenset({
    'CoupledTranslationResidualReciprocalRelativeQuaternionTransERR',
    'GatedCoupledTranslationResidualReciprocalRelativeQuaternionTransERR',
})

_ADVANCED_DEFORMATION_RECIPROCAL_MODELS = frozenset({
    'PolarBidirectionalResidualReciprocalRelativeQuaternionTransERR',
    'FlowBidirectionalResidualReciprocalRelativeQuaternionTransERR',
})

_BILINEAR_RESIDUAL_RECIPROCAL_MODELS = frozenset({
    'BilinearResidualBidirectionalRelativeQuaternionTransERR',
})

_RELATION_METRIC_RECIPROCAL_MODELS = frozenset({
    'RelationMetricBidirectionalRelativeQuaternionTransERR',
})

_HAMILTON_COMPATIBILITY_RECIPROCAL_MODELS = frozenset({
    'HamiltonCompatibilityBidirectionalRelativeQuaternionTransERR',
})

_RESIDUAL_ENERGY_RECIPROCAL_MODELS = frozenset({
    'ResidualEnergyBidirectionalRelativeQuaternionTransERR',
})

_TWO_SIDED_RECIPROCAL_MODELS = frozenset({
    'TwoSidedBidirectionalRelativeQuaternionTransERR',
})

_ADAPTIVE_MOMENT_RECIPROCAL_MODELS = frozenset({
    'AdaptiveMomentBidirectionalResidualReciprocalRelativeQuaternionTransERR',
})

_BLOCK_TRANSPORT_RECIPROCAL_MODELS = frozenset({
    'BlockQuaternionTransportBidirectionalRelativeQuaternionTransERR',
})

_INTERLEAVED_BLOCK_TRANSPORT_RECIPROCAL_MODELS = frozenset({
    'InterleavedBlockQuaternionTransportBidirectionalRelativeQuaternionTransERR',
})

RANK_DEFECT_LOCAL_GLOBAL_MODEL = (
    'RankDefectLocalGlobalBidirectionalResidualReciprocalRelativeQuaternionTransERR'
)

_RANK_DEFECT_LOCAL_GLOBAL_MODELS = frozenset({
    RANK_DEFECT_LOCAL_GLOBAL_MODEL,
})

class KGEModel(nn.Module):
    def __init__(self, model_name, nentity, nrelation, hidden_dim, gamma, 
                 double_entity_embedding=False, double_relation_embedding=False,
                 triple_relation_embedding=False, context_rank=16,
                 context_gate_init=-2.0, context_delta_bound=0.05,
                 scale_bound=0.1, complex_dim=500,
                 hyperbolic_dim=250, router_temperature=1.0,
                 dual_gate_init=-4.0, dual_weight_bound=0.1,
                 dual_init_scale=0.1, subspace_groups=10,
                 biquaternion_fusion_bound=0.25,
                 biquaternion_fusion_gate_init=-4.0,
                 lie_angle_bound=math.pi, screw_distance_bound=0.1,
                 mobius_c_bound=0.1,
                 mobius_denominator_epsilon=1e-6,
                 frame_temperature=1.0, frame_relative_prior=2.0,
                 frame_min_weight=0.0,
                 block_frame_temperature=0.05,
                 block_frame_relative_prior=2.0,
                 block_frame_min_weight=0.02,
                 orthogonal_temperature=1.0,
                 orthogonal_cayley_prior=1.0,
                 residual_so4_bound=0.0,
                 relation_bias_bound=1.0,
                 role_delta_bound=0.01,
                 reciprocal_residual_bound=0.01,
                 soft_extremal_group_size=8,
                 soft_extremal_temperature=0.35,
                 soft_extremal_gate_init=-2.2,
                 max_mean_group_size=8,
                 max_mean_gate_init=-5.0,
                 mean_variance_group_size=8,
                 mean_variance_temperature=0.1,
                 mean_variance_gate_init=-2.2,
                 pmean_group_size=8,
                 pmean_exponent_bound=1.0,
                 pmean_exponent_init=-4.0,
                 householder_group_dim=8,
                 householder_shear_bound=0.5,
                 kronecker_identity_floor=0.03,
                 cartan_stretch_bound=0.5,
                 port_block_dim=4, port_steps=1,
                 port_rotation_bound=0.25,
                 port_damping_bound=0.1,
                 port_damping_init=0.001,
                 port_nonlinear_bound=0.25,
                 port_log_scale_bound=0.5,
                 quaternion_operator_bound=0.1,
                 polar_rank=4, polar_bound=0.5,
                 flow_rank=16, flow_scale_bound=0.25,
                 flow_shift_bound=0.1,
                 cayley_residual_start_step=20000,
                 rank_defect_rows=0,
                 local_global_rank=4,
                 rank_defect_max_rank=4,
                 rank_defect_cayley_bound=0.25,
                 rank_defect_start_step=0,
                 rank_defect_ramp_steps=4000,
                 relation_head_defect_ranks=None,
                 relation_tail_defect_ranks=None,
                 double_center_temperature=0.5,
                 double_center_init_scale=0.1,
                 region_width_bound=0.02,
                 region_width_init_fraction=0.01,
                 region_inner_weight=0.1,
                 double_center_groups=1,
                 kerr_phase_bound=math.pi / 2,
                 kerr_intensity_scale=0.0,
                 local_ot_window=5, local_ot_temperature=0.1,
                 local_ot_prior_mix=0.2, local_ot_chunk_size=1048576,
                 local_ot_max_iter=128, local_ot_tolerance=1e-5,
                 local_ot_identity=False,
                 quadratic_rank=4, quadratic_bound=1., quadratic_self_init=.5,
                 quadratic_cross_weight=1., quadratic_self_weight=1.,
                 bures_stretch_bound=.5, bures_diagonal_floor=.1,
                 bures_jitter=1e-4, bures_smoothing=1e-4,
                 bures_distance_scale=0., bures_pair_chunk=16384):
        super(KGEModel, self).__init__()
        self.model_name = model_name
        self.nentity = nentity
        self.nrelation = nrelation
        self.hidden_dim = hidden_dim
        self.epsilon = 2.0
        
        self.gamma = nn.Parameter(
            torch.Tensor([gamma]), 
            requires_grad=False
        )
        
        self.embedding_range = nn.Parameter(
            torch.Tensor([(self.gamma.item() + self.epsilon) / hidden_dim]), 
            requires_grad=False
        )
        
        self.entity_dim = hidden_dim*2 if double_entity_embedding else hidden_dim
        self.relation_dim = hidden_dim*2 if double_relation_embedding else hidden_dim
        self.relation_dim = hidden_dim*3 if triple_relation_embedding else hidden_dim
        if model_name in SPIN_MODELS:
            if (not triple_relation_embedding or double_entity_embedding
                    or double_relation_embedding or hidden_dim < 8 or hidden_dim % 8):
                raise ValueError('Spin models require -tr and single-width entities divisible by eight')
            self.relation_dim = hidden_dim * 2
        if model_name == MIXED_SPIN_MODEL:
            low_dim, high_dim = mixed_spin_dimensions(hidden_dim)
            if not triple_relation_embedding or double_entity_embedding or double_relation_embedding:
                raise ValueError('Mixed spin requires -tr and single-width entities')
            self.relation_dim = hidden_dim + 2 * (low_dim + high_dim // 2)
        if (model_name == 'MidpointCartanComplexTransERR'
                and double_relation_embedding
                and not triple_relation_embedding):
            self.relation_dim = hidden_dim * 2
        self.context_rank = int(context_rank)
        self.context_delta_bound = float(context_delta_bound)
        self.scale_bound = float(scale_bound)
        self.complex_dim = int(complex_dim)
        self.hyperbolic_dim = int(hyperbolic_dim)
        self.router_temperature = float(router_temperature)
        self.dual_weight_bound = float(dual_weight_bound)
        self.dual_init_scale = float(dual_init_scale)
        self.biquaternion_fusion_bound = float(
            biquaternion_fusion_bound
        )
        self.biquaternion_fusion_gate_init = float(
            biquaternion_fusion_gate_init
        )
        self.subspace_groups = int(subspace_groups)
        self.lie_angle_bound = float(lie_angle_bound)
        self.screw_distance_bound = float(screw_distance_bound)
        self.mobius_c_bound = float(mobius_c_bound)
        self.mobius_denominator_epsilon = float(
            mobius_denominator_epsilon
        )
        self.frame_temperature = float(frame_temperature)
        self.frame_relative_prior = float(frame_relative_prior)
        self.frame_min_weight = float(frame_min_weight)
        self.block_frame_temperature = float(block_frame_temperature)
        self.block_frame_relative_prior = float(
            block_frame_relative_prior
        )
        self.block_frame_min_weight = float(block_frame_min_weight)
        self.orthogonal_temperature = float(orthogonal_temperature)
        self.orthogonal_cayley_prior = float(orthogonal_cayley_prior)
        self.residual_so4_bound = float(residual_so4_bound)
        self.relation_bias_bound = float(relation_bias_bound)
        self.role_delta_bound = float(role_delta_bound)
        self.reciprocal_residual_bound = float(
            reciprocal_residual_bound
        )
        self.soft_extremal_group_size = int(
            soft_extremal_group_size
        )
        self.soft_extremal_temperature = float(
            soft_extremal_temperature
        )
        self.max_mean_group_size = int(max_mean_group_size)
        self.mean_variance_group_size = int(
            mean_variance_group_size
        )
        self.mean_variance_temperature = float(
            mean_variance_temperature
        )
        self.pmean_group_size = int(pmean_group_size)
        self.pmean_exponent_bound = float(pmean_exponent_bound)
        self.householder_group_dim = int(householder_group_dim)
        self.householder_shear_bound = float(householder_shear_bound)
        self.kronecker_identity_floor = float(kronecker_identity_floor)
        self.cartan_stretch_bound = float(cartan_stretch_bound)
        self.port_block_dim = int(port_block_dim)
        self.port_steps = int(port_steps)
        self.port_rotation_bound = float(port_rotation_bound)
        self.port_damping_bound = float(port_damping_bound)
        self.port_damping_init = float(port_damping_init)
        self.port_nonlinear_bound = float(port_nonlinear_bound)
        self.port_log_scale_bound = float(port_log_scale_bound)
        self.quaternion_operator_bound = float(
            quaternion_operator_bound
        )
        self.polar_rank = int(polar_rank)
        self.polar_bound = float(polar_bound)
        self.flow_rank = int(flow_rank)
        self.flow_scale_bound = float(flow_scale_bound)
        self.flow_shift_bound = float(flow_shift_bound)
        self.cayley_residual_start_step = int(cayley_residual_start_step)
        self.rank_defect_rows = int(rank_defect_rows)
        self.local_global_rank = int(local_global_rank)
        self.rank_defect_max_rank = int(rank_defect_max_rank)
        self.rank_defect_cayley_bound = float(rank_defect_cayley_bound)
        self.rank_defect_start_step = int(rank_defect_start_step)
        self.rank_defect_ramp_steps = int(rank_defect_ramp_steps)
        self.current_training_step = 0
        
        self.entity_embedding = nn.Parameter(torch.zeros(nentity, self.entity_dim))
        nn.init.uniform_(
            tensor=self.entity_embedding, 
            a=-self.embedding_range.item(), 
            b=self.embedding_range.item()
        )
        
        if model_name in SPIN_MODELS:
            # Consume the baseline RNG draws, then retain one frame per adjacent pair.
            full_relation = torch.empty(nrelation, hidden_dim * 3)
            nn.init.uniform_(full_relation, -self.embedding_range.item(), self.embedding_range.item())
            source, translation, target = full_relation.chunk(3, dim=-1)
            source = source.reshape(nrelation, 4, hidden_dim // 8, 2)[..., 0].reshape(nrelation, -1)
            target = target.reshape(nrelation, 4, hidden_dim // 8, 2)[..., 0].reshape(nrelation, -1)
            relation_initialization = torch.cat((source, translation, target), -1)
        elif model_name == MIXED_SPIN_MODEL:
            # Keep the baseline entity/translation draws and sampler RNG stream.
            full_relation = torch.empty(nrelation, hidden_dim * 3)
            nn.init.uniform_(full_relation, -self.embedding_range.item(), self.embedding_range.item())
            source, translation, target = full_relation.chunk(3, dim=-1)
            relation_initialization = torch.cat((compact_mixed_frame(source), translation,
                                                  compact_mixed_frame(target)), dim=-1)
        elif model_name == 'MidpointCartanComplexTransERR':
            # Draw a full TransERR relation table before retaining two thirds,
            # preserving the fair-control initialization and sampler RNG stream.
            full_relation = torch.zeros(nrelation, hidden_dim * 3)
            nn.init.uniform_(
                tensor=full_relation,
                a=-self.embedding_range.item(),
                b=self.embedding_range.item()
            )
            relation_initialization = full_relation[
                :, :self.relation_dim
            ].clone()
        else:
            relation_initialization = torch.zeros(
                nrelation, self.relation_dim
            )
            nn.init.uniform_(
                tensor=relation_initialization,
                a=-self.embedding_range.item(),
                b=self.embedding_range.item()
            )
        self.relation_embedding = nn.Parameter(relation_initialization)

        if model_name in ('KerrTransERR', 'FoldTransERR', 'LocalOTTransERR',
                          'ImplicitQuadraticTransERR', 'BuresTransERR'):
            if (not triple_relation_embedding or double_entity_embedding
                    or double_relation_embedding or self.entity_dim < 4 or self.entity_dim % 4):
                raise ValueError('%s requires triple-width relations and single-width entities divisible by four' % model_name)
        if model_name == 'ImplicitQuadraticTransERR':
            if not isinstance(quadratic_rank, int) or not 1 <= quadratic_rank <= self.entity_dim:
                raise ValueError('quadratic_rank must be in [1, entity_dim]')
            if not math.isfinite(quadratic_bound) or quadratic_bound < 0:
                raise ValueError('quadratic_bound must be finite and nonnegative')
            if not math.isfinite(quadratic_self_init) or not -1 < quadratic_self_init < 1:
                raise ValueError('quadratic_self_init must be in (-1, 1)')
            if any(not math.isfinite(v) or not 0 <= v <= 1
                   for v in (quadratic_cross_weight, quadratic_self_weight)):
                raise ValueError('Quadratic ablation weights must be in [0, 1]')
            self.quadratic_rank = quadratic_rank
            self.quadratic_bound = float(quadratic_bound)
            self.quadratic_scale = self.embedding_range.item()
            if not math.isfinite(self.quadratic_scale) or self.quadratic_scale <= 0:
                raise ValueError('ImplicitQuadraticTransERR requires gamma + 2 > 0')
            self.quadratic_cross_weight = float(quadratic_cross_weight)
            self.quadratic_self_weight = float(quadratic_self_weight)
            # Extra projections must not change entity initialization or sampler RNG.
            generator = torch.Generator(device='cpu').manual_seed(torch.initial_seed() ^ 0x51554144)
            source = torch.randn(nrelation, quadratic_rank, self.entity_dim, generator=generator)
            target = torch.randn(nrelation, quadratic_rank, self.entity_dim, generator=generator)
            self.quadratic_source_projection = nn.Parameter(F.normalize(source, dim=-1))
            self.quadratic_target_projection = nn.Parameter(F.normalize(target, dim=-1))
            self.quadratic_output_raw = nn.Parameter(torch.zeros(nrelation, self.entity_dim, quadratic_rank))
            self.quadratic_self_raw = nn.Parameter(torch.full(
                (nrelation, 2, quadratic_rank), math.atanh(quadratic_self_init)))
        if model_name == 'BuresTransERR':
            if not math.isfinite(bures_stretch_bound) or not 0 <= bures_stretch_bound <= 4:
                raise ValueError('bures_stretch_bound must be in [0, 4]')
            if any(not math.isfinite(v) or v <= 0
                   for v in (bures_diagonal_floor, bures_jitter, bures_smoothing)):
                raise ValueError('Bures floor, jitter and smoothing must be finite and positive')
            if not math.isfinite(bures_distance_scale) or bures_distance_scale < 0:
                raise ValueError('bures_distance_scale must be nonnegative; zero calibrates once')
            if not isinstance(bures_pair_chunk, int) or bures_pair_chunk < 1:
                raise ValueError('bures_pair_chunk must be a positive integer')
            self.bures_scale = self.embedding_range.item()
            if not math.isfinite(self.bures_scale) or self.bures_scale <= 0:
                raise ValueError('BuresTransERR requires gamma + 2 > 0')
            self.bures_stretch_bound = float(bures_stretch_bound)
            self.bures_diagonal_floor = float(bures_diagonal_floor)
            self.bures_jitter = float(bures_jitter)
            self.bures_smoothing = float(bures_smoothing)
            self.bures_pair_chunk = bures_pair_chunk
            self.bures_stretch_raw = nn.Parameter(torch.zeros(nrelation, 2, 2, self.entity_dim // 4))
            self.bures_tail_offset = nn.Parameter(torch.zeros(nrelation, self.entity_dim))
            self.register_buffer('bures_distance_scale', torch.tensor(float(bures_distance_scale)))
            self.register_buffer('bures_calibration_distances', torch.zeros(2))
            self.calibrate_bures_scale()
        if model_name == 'LocalOTTransERR':
            validate_local_ot(self.entity_dim, local_ot_window, local_ot_temperature,
                              local_ot_prior_mix, local_ot_chunk_size, local_ot_max_iter,
                              local_ot_tolerance)
            self.local_ot_window = local_ot_window
            self.local_ot_temperature = local_ot_temperature
            self.local_ot_prior_mix = local_ot_prior_mix
            self.local_ot_chunk_size = local_ot_chunk_size
            self.local_ot_max_iter = local_ot_max_iter
            self.local_ot_tolerance = local_ot_tolerance
            self.local_ot_identity = local_ot_identity
        if model_name == 'KerrTransERR':
            if not math.isfinite(kerr_phase_bound) or kerr_phase_bound <= 0:
                raise ValueError('kerr_phase_bound must be finite and positive')
            if not math.isfinite(kerr_intensity_scale) or kerr_intensity_scale < 0:
                raise ValueError('kerr_intensity_scale must be finite and nonnegative')
            self.kerr_phase_bound = float(kerr_phase_bound)
            self.kerr_intensity_scale = float(kerr_intensity_scale or self.embedding_range.item())
            scale_squared = self.kerr_intensity_scale * self.kerr_intensity_scale
            if (self.kerr_intensity_scale <= 0 or not math.isfinite(scale_squared)
                    or scale_squared < torch.finfo(torch.float32).tiny):
                raise ValueError('kerr_intensity_scale must have a representable positive square')
            self.kerr_coefficients_raw = nn.Parameter(torch.zeros(
                nrelation, 2, 2, self.entity_dim // 4))

        if model_name == 'SpectralTransERR':
            if (not triple_relation_embedding or double_entity_embedding
                    or self.entity_dim % 4 or self.entity_dim < 12):
                raise ValueError('SpectralTransERR requires triple-width relations and at least three single-width quaternions')
            self.spectral_phase = nn.Parameter(torch.zeros(
                nrelation, 2, (self.entity_dim // 4 - 1) // 2))

        if model_name == 'RegionTransERR':
            if not triple_relation_embedding or double_entity_embedding or self.entity_dim % 4:
                raise ValueError('RegionTransERR requires triple-width relations and single-width entities divisible by 4')
            if not math.isfinite(region_width_bound) or region_width_bound < 0:
                raise ValueError('region_width_bound must be finite and nonnegative')
            if not 0 < region_width_init_fraction < 1:
                raise ValueError('region_width_init_fraction must be strictly between 0 and 1')
            if not 0 < region_inner_weight <= 1:
                raise ValueError('region_inner_weight must be in (0, 1]')
            self.region_width_bound = float(region_width_bound)
            self.region_inner_weight = float(region_inner_weight)
            initial_logit = math.log(region_width_init_fraction / (1 - region_width_init_fraction))
            self.region_width_logits = nn.Parameter(torch.full((nrelation, self.entity_dim // 4), initial_logit))

        if model_name == 'DoubleCenterTransERR':
            if not triple_relation_embedding or double_entity_embedding:
                raise ValueError('DoubleCenterTransERR requires --triple_relation_embedding and single-width entities')
            if self.entity_dim % 4:
                raise ValueError('DoubleCenterTransERR dimension must be divisible by 4')
            if not math.isfinite(double_center_temperature) or double_center_temperature <= 0:
                raise ValueError('double_center_temperature must be finite and positive')
            if not math.isfinite(double_center_init_scale) or double_center_init_scale < 0:
                raise ValueError('double_center_init_scale must be finite and nonnegative')
            if (not isinstance(double_center_groups, int)
                    or isinstance(double_center_groups, bool)
                    or double_center_groups < 1
                    or self.entity_dim % (4 * double_center_groups)):
                raise ValueError('double_center_groups must be positive and divide the quaternion count')
            self.double_center_groups = double_center_groups
            self.double_center_temperature = float(double_center_temperature)
            self.center_offset = nn.Parameter(torch.zeros(nrelation, self.entity_dim))
            # Draw the new parameter without changing the control's sampler RNG.
            with torch.random.fork_rng(devices=[]):
                radius = double_center_init_scale * self.embedding_range.item()
                nn.init.uniform_(self.center_offset, -radius, radius)

        if model_name in (
                'ReciprocalTransERR',
                'ReciprocalRelativeQuaternionTransERR',
                'RoleSeparatedReciprocalTransERR',
                'BoundedRoleReciprocalTransERR'):
            # Head prediction is represented as the inverse triple
            # (tail, inverse_relation, head).  Preserve the global RNG state
            # so the existing negative-sampling stream remains comparable.
            self.inverse_relation_embedding = nn.Parameter(torch.zeros(
                nrelation, self.relation_dim
            ))
            with torch.random.fork_rng(devices=[]):
                nn.init.uniform_(
                    tensor=self.inverse_relation_embedding,
                    a=-self.embedding_range.item(),
                    b=self.embedding_range.item()
                )

        if model_name in (
                'CoupledReciprocalTransERR',
                'CoupledReciprocalRelativeQuaternionTransERR',
                'BidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'RoleResidualBidirectionalRelativeQuaternionTransERR',
                'BilinearResidualBidirectionalRelativeQuaternionTransERR',
                'RelationMetricBidirectionalRelativeQuaternionTransERR',
                'HamiltonCompatibilityBidirectionalRelativeQuaternionTransERR',
                'ResidualEnergyBidirectionalRelativeQuaternionTransERR',
                'ConjugateGatedBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'InverseConjugateGatedBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'SoftExtremalBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'MaxMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'MeanVarianceBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'PMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR'
                ) or model_name in _CAYLEY_RESIDUAL_RECIPROCAL_MODELS \
                or model_name in _TWO_SIDED_RECIPROCAL_MODELS \
                or model_name in _ADAPTIVE_MOMENT_RECIPROCAL_MODELS \
                or model_name in _BLOCK_TRANSPORT_RECIPROCAL_MODELS \
                or model_name in _INTERLEAVED_BLOCK_TRANSPORT_RECIPROCAL_MODELS \
                or model_name in _RANK_QUATERNION_OPERATOR_MODELS \
                or model_name in _ADVANCED_DEFORMATION_RECIPROCAL_MODELS \
                or model_name in _RANK_DEFECT_LOCAL_GLOBAL_MODELS:
            if self.reciprocal_residual_bound <= 0.0:
                raise ValueError(
                    'reciprocal_residual_bound must be positive'
                )
            # The analytic inverse shares the forward relation parameters.
            # A bounded residual only learns directional deviations.
            self.inverse_relation_residual = nn.Parameter(torch.zeros(
                nrelation, self.relation_dim
            ))

        if model_name in (
                'TailResidualReciprocalTransERR',
                'TailResidualReciprocalRelativeQuaternionTransERR',
                'BidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'RoleResidualBidirectionalRelativeQuaternionTransERR',
                'BilinearResidualBidirectionalRelativeQuaternionTransERR',
                'RelationMetricBidirectionalRelativeQuaternionTransERR',
                'HamiltonCompatibilityBidirectionalRelativeQuaternionTransERR',
                'ResidualEnergyBidirectionalRelativeQuaternionTransERR',
                'ConjugateGatedBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'InverseConjugateGatedBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'SoftExtremalBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'MaxMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'MeanVarianceBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'PMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR'
                ) or model_name in _CAYLEY_RESIDUAL_RECIPROCAL_MODELS \
                or model_name in _TWO_SIDED_RECIPROCAL_MODELS \
                or model_name in _ADAPTIVE_MOMENT_RECIPROCAL_MODELS \
                or model_name in _BLOCK_TRANSPORT_RECIPROCAL_MODELS \
                or model_name in _INTERLEAVED_BLOCK_TRANSPORT_RECIPROCAL_MODELS \
                or model_name in _RANK_QUATERNION_OPERATOR_MODELS \
                or model_name in _ADVANCED_DEFORMATION_RECIPROCAL_MODELS \
                or model_name in _RANK_DEFECT_LOCAL_GLOBAL_MODELS:
            if self.reciprocal_residual_bound <= 0.0:
                raise ValueError(
                    'reciprocal_residual_bound must be positive'
                )
            # Keep the analytic inverse exact for head prediction. Only the
            # empirically beneficial tail direction receives extra capacity.
            self.tail_relation_residual = nn.Parameter(torch.zeros(
                nrelation, self.relation_dim
            ))

        if model_name in _CONJUGATE_GATED_RECIPROCAL_MODELS:
            # One zero-initialized gate per relation/quaternion block.  This
            # starts exactly as the v73 right-Hamilton action and can only
            # introduce a bounded conjugate action when supported by data.
            self.conjugate_gate = nn.Parameter(torch.zeros(
                nrelation, self.entity_dim // 4
            ))

        if model_name in _BILINEAR_RESIDUAL_RECIPROCAL_MODELS:
            # Zero makes the score exactly v73.  Tanh in the score keeps this
            # compatibility correction bounded during early training.
            self.bilinear_residual_embedding = nn.Parameter(torch.zeros(
                nrelation, self.entity_dim
            ))

        if model_name in _RELATION_METRIC_RECIPROCAL_MODELS:
            # One shared 4x4 local metric per relation.  A zero table maps to
            # the identity, so the initial energy is exactly v73's L1 norm.
            self.residual_metric_embedding = nn.Parameter(torch.zeros(
                nrelation, 4, 4
            ))

        if model_name in _HAMILTON_COMPATIBILITY_RECIPROCAL_MODELS:
            self.hamilton_compatibility_embedding = nn.Parameter(torch.zeros(
                nrelation, self.entity_dim
            ))

        if model_name in _RESIDUAL_ENERGY_RECIPROCAL_MODELS:
            # A zero-initialized, relation-specific quadratic residual gate
            # leaves the v73 score exact at initialization.
            self.residual_energy_gate = nn.Parameter(torch.zeros(nrelation, 4))

        if model_name in _TWO_SIDED_RECIPROCAL_MODELS:
            self.two_sided_left_raw = nn.Parameter(torch.zeros(
                nrelation, self.entity_dim
            ))

        if model_name in _ADAPTIVE_MOMENT_RECIPROCAL_MODELS:
            group_count = (hidden_dim + self.mean_variance_group_size - 1) // self.mean_variance_group_size
            self.adaptive_variance_gate = nn.Parameter(torch.zeros(nrelation, group_count))
            self.adaptive_max_gate = nn.Parameter(torch.zeros(nrelation, group_count))

        if model_name in _BLOCK_TRANSPORT_RECIPROCAL_MODELS:
            quaternion_blocks = self.entity_dim // 4
            if quaternion_blocks % 2 != 0:
                raise ValueError(
                    'BlockQuaternionTransport requires an even quaternion block count'
                )
            self.block_transport_angle = nn.Parameter(torch.zeros(
                nrelation, 2, quaternion_blocks // 2
            ))

        if model_name in _INTERLEAVED_BLOCK_TRANSPORT_RECIPROCAL_MODELS:
            quaternion_blocks = self.entity_dim // 4
            if quaternion_blocks % 2 != 0:
                raise ValueError(
                    'InterleavedBlockQuaternionTransport requires an even quaternion block count'
                )
            self.interleaved_block_transport_angle = nn.Parameter(torch.zeros(
                nrelation, 2, 2, quaternion_blocks // 2
            ))

        if model_name in _CAYLEY_RESIDUAL_RECIPROCAL_MODELS:
            if self.residual_so4_bound <= 0.0:
                raise ValueError(
                    'residual_so4_bound must be positive for Cayley '
                    'residual reciprocal models'
                )
            if self.cayley_residual_start_step < 0:
                raise ValueError(
                    'cayley_residual_start_step must be non-negative'
                )
            if self.entity_dim % 4 != 0:
                raise ValueError(
                    '%s requires hidden_dim divisible by 4' % model_name
                )

            if model_name.startswith('FullCayley'):
                generator_dim = 3 * self.entity_dim // 2
            else:
                generator_dim = 2 * self.entity_dim
            self.cayley_residual_embedding = nn.Parameter(torch.empty(
                nrelation, generator_dim
            ))
            # Preserve the v73 initialization and sampler random stream.
            with torch.random.fork_rng(devices=[]):
                nn.init.uniform_(
                    self.cayley_residual_embedding,
                    -self.embedding_range.item(),
                    self.embedding_range.item(),
                )
            self.cayley_residual_gate = nn.Parameter(torch.zeros(
                nrelation, 1
            ))

        if model_name == (
                'SoftExtremalBidirectionalResidualReciprocalRelativeQuaternionTransERR'):
            if self.soft_extremal_group_size <= 1:
                raise ValueError(
                    'soft_extremal_group_size must be greater than 1'
                )
            if self.soft_extremal_temperature <= 0.0:
                raise ValueError(
                    'soft_extremal_temperature must be positive'
                )
            group_count = (
                hidden_dim + self.soft_extremal_group_size - 1
            ) // self.soft_extremal_group_size
            self.soft_extremal_gate = nn.Parameter(torch.full(
                (nrelation, group_count),
                float(soft_extremal_gate_init)
            ))

        if model_name == (
                'MaxMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR'):
            if self.max_mean_group_size <= 1:
                raise ValueError(
                    'max_mean_group_size must be greater than 1'
                )
            group_count = (
                hidden_dim + self.max_mean_group_size - 1
            ) // self.max_mean_group_size
            self.max_mean_gate = nn.Parameter(torch.full(
                (nrelation, group_count), float(max_mean_gate_init)
            ))

        if model_name == (
                'MeanVarianceBidirectionalResidualReciprocalRelativeQuaternionTransERR'):
            if self.mean_variance_group_size <= 1:
                raise ValueError(
                    'mean_variance_group_size must be greater than 1'
                )
            if self.mean_variance_temperature <= 0.0:
                raise ValueError(
                    'mean_variance_temperature must be positive'
                )
            group_count = (
                hidden_dim + self.mean_variance_group_size - 1
            ) // self.mean_variance_group_size
            self.mean_variance_gate = nn.Parameter(torch.full(
                (nrelation, group_count),
                float(mean_variance_gate_init)
            ))

        if model_name == (
                'PMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR'):
            if self.pmean_group_size <= 1:
                raise ValueError(
                    'pmean_group_size must be greater than 1'
                )
            if self.pmean_exponent_bound <= 0.0:
                raise ValueError(
                    'pmean_exponent_bound must be positive'
                )
            group_count = (
                hidden_dim + self.pmean_group_size - 1
            ) // self.pmean_group_size
            self.pmean_exponent_raw = nn.Parameter(torch.full(
                (nrelation, group_count), float(pmean_exponent_init)
            ))

        if model_name == (
                'BidirectionalTranslationResidualReciprocalRelativeQuaternionTransERR'):
            if self.reciprocal_residual_bound <= 0.0:
                raise ValueError(
                    'reciprocal_residual_bound must be positive'
                )
            translation_dim = self.relation_dim // 3
            # Preserve the analytic rotation and learn only the directional
            # translation mismatch in each prediction direction.
            self.inverse_relation_residual = nn.Parameter(torch.zeros(
                nrelation, translation_dim
            ))
            self.tail_relation_residual = nn.Parameter(torch.zeros(
                nrelation, translation_dim
            ))

        if model_name in _COUPLED_TRANSLATION_RESIDUAL_MODELS:
            if self.reciprocal_residual_bound <= 0.0:
                raise ValueError(
                    'reciprocal_residual_bound must be positive'
                )
            translation_dim = self.relation_dim // 3
            # One translation residual defines both prediction directions;
            # the inverse direction receives its analytically required sign.
            self.tail_relation_residual = nn.Parameter(torch.zeros(
                nrelation, translation_dim
            ))
            if model_name == (
                    'GatedCoupledTranslationResidualReciprocalRelativeQuaternionTransERR'):
                self.forward_translation_residual_gate = nn.Parameter(
                    torch.zeros(nrelation, 1)
                )
                self.inverse_translation_residual_gate = nn.Parameter(
                    torch.zeros(nrelation, 1)
                )

        if model_name in _RANK_DEFECT_LOCAL_GLOBAL_MODELS:
            if self.entity_dim % 4 != 0:
                raise ValueError(
                    'RankDefectLocalGlobal requires hidden_dim divisible by 4'
                )
            rows, columns = balanced_matrix_shape(
                self.entity_dim, self.rank_defect_rows
            )
            self.rank_defect_rows = rows
            self.rank_defect_columns = columns
            axis_limit = min(rows, columns)
            if not 0 < self.local_global_rank <= axis_limit:
                raise ValueError(
                    'local_global_rank must be in [1, min(rows, columns)]'
                )
            if not 0 < self.rank_defect_max_rank <= axis_limit:
                raise ValueError(
                    'rank_defect_max_rank must be in [1, min(rows, columns)]'
                )
            if self.rank_defect_cayley_bound <= 0.0:
                raise ValueError('rank_defect_cayley_bound must be positive')
            if self.rank_defect_start_step < 0:
                raise ValueError('rank_defect_start_step must be non-negative')
            if self.rank_defect_ramp_steps <= 0:
                raise ValueError('rank_defect_ramp_steps must be positive')

            if relation_head_defect_ranks is None:
                relation_head_defect_ranks = [0] * nrelation
            if relation_tail_defect_ranks is None:
                relation_tail_defect_ranks = [0] * nrelation
            head_ranks = torch.as_tensor(
                relation_head_defect_ranks, dtype=torch.long
            )
            tail_ranks = torch.as_tensor(
                relation_tail_defect_ranks, dtype=torch.long
            )
            if head_ranks.shape != (nrelation,) or tail_ranks.shape != (nrelation,):
                raise ValueError(
                    'relation defect ranks must each have shape [nrelation]'
                )
            if ((head_ranks < 0).any() or (tail_ranks < 0).any()
                    or (head_ranks > self.rank_defect_max_rank).any()
                    or (tail_ranks > self.rank_defect_max_rank).any()):
                raise ValueError(
                    'relation defect ranks must be within configured maximum'
                )
            self.register_buffer(
                'relation_defect_ranks',
                torch.stack([head_ranks, tail_ranks], dim=1),
            )
            self.register_buffer(
                'rank_defect_progress', torch.tensor(0.0)
            )

            defect_rank = self.rank_defect_max_rank
            rotation_rank = self.local_global_rank
            self.rank_defect_left_basis = nn.Parameter(torch.empty(
                nrelation, 2, rows, defect_rank
            ))
            self.rank_defect_right_basis = nn.Parameter(torch.empty(
                nrelation, 2, columns, defect_rank
            ))
            self.local_global_left_basis = nn.Parameter(torch.empty(
                nrelation, 2, rows, rotation_rank
            ))
            self.local_global_right_basis = nn.Parameter(torch.empty(
                nrelation, 2, columns, rotation_rank
            ))
            # Extra geometry must not perturb v73's sampler RNG stream.
            with torch.random.fork_rng(devices=[]):
                for parameter, width in (
                        (self.rank_defect_left_basis, rows),
                        (self.rank_defect_right_basis, columns),
                        (self.local_global_left_basis, rows),
                        (self.local_global_right_basis, columns)):
                    nn.init.normal_(
                        parameter,
                        mean=0.0,
                        std=1.0 / math.sqrt(float(width)),
                    )
            self.local_global_left_generator = nn.Parameter(torch.zeros(
                nrelation, 2, rotation_rank, rotation_rank
            ))
            self.local_global_right_generator = nn.Parameter(torch.zeros(
                nrelation, 2, rotation_rank, rotation_rank
            ))

        if model_name == (
                'PolarBidirectionalResidualReciprocalRelativeQuaternionTransERR'):
            if self.polar_rank <= 0 or self.polar_rank > self.entity_dim:
                raise ValueError('polar_rank must be in [1, entity_dim]')
            if not 0.0 < self.polar_bound < 1.0:
                raise ValueError('polar_bound must be in (0, 1)')
            # Two endpoint-specific low-rank SPD factors. Zero coefficients
            # make the deformation exactly identity at initialization.
            self.polar_direction = nn.Parameter(torch.empty(
                nrelation, 2, self.polar_rank, self.entity_dim
            ))
            with torch.random.fork_rng(devices=[]):
                nn.init.normal_(
                    self.polar_direction,
                    mean=0.0,
                    std=1.0 / math.sqrt(float(self.entity_dim)),
                )
            self.polar_coefficient = nn.Parameter(torch.zeros(
                nrelation, 2, self.polar_rank
            ))

        if model_name == (
                'FlowBidirectionalResidualReciprocalRelativeQuaternionTransERR'):
            if self.entity_dim % 2 != 0:
                raise ValueError('Flow model requires an even entity_dim')
            if self.flow_rank <= 0:
                raise ValueError('flow_rank must be positive')
            if self.flow_scale_bound <= 0.0:
                raise ValueError('flow_scale_bound must be positive')
            if self.flow_shift_bound <= 0.0:
                raise ValueError('flow_shift_bound must be positive')
            half_dim = self.entity_dim // 2
            # [relation, endpoint role, coupling layer, rank, dimension].
            # Zero up-projections make both coupling layers exact identities.
            self.flow_down = nn.Parameter(torch.empty(
                nrelation, 2, 2, self.flow_rank, half_dim
            ))
            with torch.random.fork_rng(devices=[]):
                nn.init.normal_(
                    self.flow_down,
                    mean=0.0,
                    std=1.0 / math.sqrt(float(half_dim)),
                )
            self.flow_scale_up = nn.Parameter(torch.zeros(
                nrelation, 2, 2, half_dim, self.flow_rank
            ))
            self.flow_shift_up = nn.Parameter(torch.zeros(
                nrelation, 2, 2, half_dim, self.flow_rank
            ))

        if model_name == 'RoleSeparatedReciprocalTransERR':
            # Keep source and target entity roles identical at initialization,
            # then let asymmetric relations specialize them independently.
            self.target_entity_embedding = nn.Parameter(
                self.entity_embedding.detach().clone()
            )

        if model_name in (
                'BoundedRoleReciprocalTransERR',
                'RoleResidualBidirectionalRelativeQuaternionTransERR'):
            if self.role_delta_bound <= 0.0:
                raise ValueError('role_delta_bound must be positive')
            # A zero residual starts exactly at ReciprocalTransERR.  Tanh
            # prevents sparse entities from losing their shared anchor.
            self.role_delta_embedding = nn.Parameter(torch.zeros(
                nentity, self.entity_dim
            ))

        if model_name == 'ContextTransERR':
            if self.context_rank <= 0 or self.context_rank > hidden_dim:
                raise ValueError('context_rank must be in [1, hidden_dim]')
            if self.context_delta_bound <= 0.0:
                raise ValueError('context_delta_bound must be positive')

            # The down projection sees the transformed head. The zero
            # initialized up projection makes the initial model exactly
            # TransERR while still receiving a first-order gradient.
            self.context_down = nn.Parameter(
                torch.empty(nrelation, self.context_rank, hidden_dim)
            )
            # Do not advance the global RNG: fair control runs must see the
            # same DataLoader shuffle and negative samples at the same seed.
            with torch.random.fork_rng(devices=[]):
                nn.init.normal_(
                    self.context_down, mean=0.0,
                    std=1.0 / math.sqrt(float(hidden_dim))
                )
            self.context_up = nn.Parameter(
                torch.zeros(nrelation, hidden_dim, self.context_rank)
            )
            self.context_gate = nn.Parameter(
                torch.full((nrelation, 1), float(context_gate_init))
            )

        if model_name in ('ScaleGroupTransERR', 'ScaleDimTransERR'):
            if not 0.0 < self.scale_bound < 1.0:
                raise ValueError('scale_bound must be in (0, 1)')
            scale_dim = 4 if model_name == 'ScaleGroupTransERR' else hidden_dim
            # Zero logits give unit scales, so both variants start exactly
            # from the TransERR scoring function without advancing the RNG.
            self.head_scale = nn.Parameter(torch.zeros(nrelation, scale_dim))
            self.tail_scale = nn.Parameter(torch.zeros(nrelation, scale_dim))

        if model_name in (
                'RelationEntityBiasTransERR',
                'DomainRangeGatedSO4TransERR'):
            if self.relation_bias_bound <= 0.0:
                raise ValueError('relation_bias_bound must be positive')
            # Relation-conditioned domain/range priors. Zero initialization
            # keeps the initial score exactly equal to TransERR.
            self.head_entity_bias = nn.Parameter(torch.zeros(
                nrelation, nentity
            ))
            self.tail_entity_bias = nn.Parameter(torch.zeros(
                nrelation, nentity
            ))

        if model_name in (
                'DomainRangeProjectionTransERR',
                'ProjectedGatedSO4TransERR'):
            if self.relation_bias_bound <= 0.0:
                raise ValueError('relation_bias_bound must be positive')
            # Shared entity features generalize the relation's domain/range
            # preference instead of memorizing one bias per entity.
            self.domain_projection = nn.Parameter(torch.zeros(
                nrelation, self.entity_dim
            ))
            self.range_projection = nn.Parameter(torch.zeros(
                nrelation, self.entity_dim
            ))

        if model_name == 'MoGeoTransERR':
            if self.complex_dim <= 0 or self.complex_dim % 2 != 0:
                raise ValueError('complex_dim must be a positive even integer')
            if self.hyperbolic_dim <= 0:
                raise ValueError('hyperbolic_dim must be positive')
            if self.router_temperature <= 0.0:
                raise ValueError('router_temperature must be positive')

            self.complex_entity_embedding = nn.Parameter(
                torch.empty(nentity, self.complex_dim)
            )
            self.complex_relation_embedding = nn.Parameter(
                torch.empty(nrelation, self.complex_dim)
            )
            self.hyperbolic_entity_embedding = nn.Parameter(
                torch.empty(nentity, self.hyperbolic_dim)
            )
            self.hyperbolic_relation_embedding = nn.Parameter(
                torch.empty(nrelation, self.hyperbolic_dim)
            )
            # Keep the training sampler RNG identical to TransERR.
            with torch.random.fork_rng(devices=[]):
                nn.init.uniform_(
                    self.complex_entity_embedding,
                    -self.embedding_range.item(), self.embedding_range.item()
                )
                nn.init.uniform_(
                    self.complex_relation_embedding,
                    -self.embedding_range.item(), self.embedding_range.item()
                )
                nn.init.uniform_(
                    self.hyperbolic_entity_embedding, -0.01, 0.01
                )
                nn.init.uniform_(
                    self.hyperbolic_relation_embedding, -0.01, 0.01
                )

            # Start mostly from TransERR while allowing both new experts to
            # receive gradients immediately.
            self.router_logits = nn.Parameter(torch.zeros(nrelation, 3))
            with torch.no_grad():
                self.router_logits[:, 0] = 2.0
            inverse_softplus_one = math.log(math.expm1(1.0))
            self.expert_scale_raw = nn.Parameter(
                torch.full((3,), inverse_softplus_one)
            )
            self.expert_bias = nn.Parameter(torch.zeros(3))
            self.curvature_raw = nn.Parameter(
                torch.full((nrelation, 1), inverse_softplus_one)
            )

        if model_name == 'DualQuaternionTransERR':
            if self.entity_dim % 4 != 0:
                raise ValueError('DualQuaternionTransERR requires hidden_dim divisible by 4')
            if self.dual_weight_bound <= 0.0:
                raise ValueError('dual_weight_bound must be positive')
            if self.dual_init_scale <= 0.0:
                raise ValueError('dual_init_scale must be positive')
            self.dual_entity_embedding = nn.Parameter(
                torch.empty(nentity, self.entity_dim)
            )
            self.dual_relation_embedding = nn.Parameter(
                torch.empty(nrelation, self.relation_dim)
            )
            dual_range = self.embedding_range.item() * self.dual_init_scale
            with torch.random.fork_rng(devices=[]):
                nn.init.uniform_(
                    self.dual_entity_embedding, -dual_range, dual_range
                )
                nn.init.uniform_(
                    self.dual_relation_embedding, -dual_range, dual_range
                )
            self.dual_gate = nn.Parameter(
                torch.full((nrelation, 1), float(dual_gate_init))
            )

        if (model_name in (
                'BiquaternionTransERR',
                'AdaptiveBiquaternionFusionTransERR',
                'ConvexBiquaternionFusionTransERR',
                'OctonionTransERR')
                and self.entity_dim % 8 != 0):
            raise ValueError(
                '%s requires hidden_dim divisible by 8' % model_name
            )

        if model_name == 'AdaptiveBiquaternionFusionTransERR':
            if self.biquaternion_fusion_bound <= 0.0:
                raise ValueError(
                    'biquaternion_fusion_bound must be positive'
                )
            # Zero initialization makes every initial score exactly TransERR.
            self.biquaternion_fusion_raw = nn.Parameter(torch.zeros(
                nrelation, 1
            ))

        if model_name == 'ConvexBiquaternionFusionTransERR':
            if self.biquaternion_fusion_bound <= 0.0:
                raise ValueError(
                    'biquaternion_fusion_bound must be positive'
                )
            self.biquaternion_fusion_raw = nn.Parameter(torch.full(
                (nrelation, 1), self.biquaternion_fusion_gate_init
            ))

        if model_name == 'AdaptiveMetricCliffordTransERR':
            if self.entity_dim % 4 != 0:
                raise ValueError(
                    'AdaptiveMetricCliffordTransERR requires hidden_dim '
                    'divisible by 4'
                )
            if self.relation_dim != 3 * self.entity_dim:
                raise ValueError(
                    'AdaptiveMetricCliffordTransERR requires relation_dim '
                    '== 3 * entity_dim'
                )
            # The effective metric is -1 + delta. Zero initialization makes
            # every block exactly Hamiltonian without consuming RNG state.
            self.clifford_signature_delta = nn.Parameter(torch.zeros(
                nrelation, 1
            ))

        matrix_width = {
            'RealMatrix2TransERR': 4,
            'ComplexMatrix2TransERR': 8,
            'ResidualKroneckerComplexMatrix2TransERR': 8,
        }.get(model_name)
        if matrix_width is not None:
            if self.entity_dim % matrix_width != 0:
                raise ValueError(
                    '%s requires hidden_dim divisible by %d'
                    % (model_name, matrix_width)
                )
            if self.relation_dim != 3 * self.entity_dim:
                raise ValueError(
                    '%s requires relation_dim == 3 * entity_dim'
                    % model_name
                )

        if model_name in _PORT_HAMILTONIAN_MODELS:
            if self.port_block_dim < 2:
                raise ValueError('port_block_dim must be at least 2')
            if self.entity_dim % 4 != 0:
                raise ValueError(
                    '%s requires hidden_dim divisible by 4 for its '
                    'quaternion frames' % model_name
                )
            if self.entity_dim % self.port_block_dim != 0:
                raise ValueError(
                    '%s requires hidden_dim divisible by port_block_dim'
                    % model_name
                )
            if self.relation_dim != 3 * self.entity_dim:
                raise ValueError(
                    '%s requires relation_dim == 3 * entity_dim'
                    % model_name
                )
            if self.port_steps <= 0:
                raise ValueError('port_steps must be positive')
            if self.port_rotation_bound < 0.0:
                raise ValueError(
                    'port_rotation_bound must be non-negative'
                )
            if self.port_damping_bound < 0.0:
                raise ValueError(
                    'port_damping_bound must be non-negative'
                )
            if not 0.0 <= self.port_nonlinear_bound < 1.0:
                raise ValueError(
                    'port_nonlinear_bound must be in [0, 1)'
                )
            if self.port_log_scale_bound < 0.0:
                raise ValueError(
                    'port_log_scale_bound must be non-negative'
                )
            if self.port_damping_bound == 0.0:
                if self.port_damping_init != 0.0:
                    raise ValueError(
                        'port_damping_init must be zero when the bound is zero'
                    )
                damping_raw_init = 0.0
            else:
                if not 0.0 <= self.port_damping_init < self.port_damping_bound:
                    raise ValueError(
                        'port_damping_init must be in '
                        '[0, port_damping_bound)'
                    )
                damping_fraction = max(
                    self.port_damping_init / self.port_damping_bound,
                    1e-6,
                )
                damping_raw_init = math.log(
                    damping_fraction / (1.0 - damping_fraction)
                )

            block_count = self.entity_dim // self.port_block_dim
            skew_width = (
                self.port_block_dim * (self.port_block_dim - 1) // 2
            )
            self.port_skew_embedding = nn.Parameter(torch.zeros(
                nrelation, block_count, skew_width
            ))
            self.port_damping_embedding = nn.Parameter(torch.full(
                (nrelation, block_count, self.port_block_dim),
                damping_raw_init,
            ))
            self.port_nonlinear_embedding = nn.Parameter(torch.zeros(
                nrelation, block_count, self.port_block_dim
            ))
            if model_name == 'StochasticPortHamiltonianTransERR':
                self.port_log_scale_embedding = nn.Parameter(torch.zeros(
                    nrelation, block_count, self.port_block_dim
                ))

        if model_name in _RANK_QUATERNION_OPERATOR_MODELS:
            if self.entity_dim % 4 != 0:
                raise ValueError(
                    '%s requires hidden_dim divisible by 4' % model_name
                )
            if self.relation_dim != 3 * self.entity_dim:
                raise ValueError(
                    '%s requires relation_dim == 3 * entity_dim'
                    % model_name
                )
            if self.quaternion_operator_bound <= 0.0:
                raise ValueError(
                    'quaternion_operator_bound must be positive'
                )

            self.quaternion_operator_rank = (
                _RANK_QUATERNION_OPERATOR_MODELS[model_name]
            )
            residual_rank = self.quaternion_operator_rank - 1
            operator_shape = (
                nrelation, 2, 2, residual_rank, self.entity_dim
            )
            coefficient_shape = (
                nrelation, 2, 2, residual_rank,
                self.entity_dim // 4
            )
            self.quaternion_operator_left = nn.Parameter(
                torch.zeros(operator_shape)
            )
            self.quaternion_operator_right = nn.Parameter(
                torch.zeros(operator_shape)
            )
            self.quaternion_operator_coefficient = nn.Parameter(
                torch.zeros(coefficient_shape)
            )

            # Start exactly at the Hamilton model while assigning each
            # dormant residual term a distinct deterministic basis action.
            quaternion_width = self.entity_dim // 4
            with torch.no_grad():
                for term in range(residual_rank):
                    component = 1 + term % 3
                    start = component * quaternion_width
                    end = start + quaternion_width
                    self.quaternion_operator_left[
                        :, :, :, term, start:end
                    ] = 1.0
                    self.quaternion_operator_right[
                        :, :, :, term, :quaternion_width
                    ] = 1.0

        if model_name == 'MidpointCartanComplexTransERR':
            if self.entity_dim % 8 != 0:
                raise ValueError(
                    'MidpointCartanComplexTransERR requires hidden_dim '
                    'divisible by 8'
                )
            if self.entity_dim != hidden_dim:
                raise ValueError(
                    'MidpointCartanComplexTransERR does not use '
                    '--double_entity_embedding'
                )
            if self.relation_dim != 2 * self.entity_dim:
                raise ValueError(
                    'MidpointCartanComplexTransERR requires relation_dim '
                    '== 2 * entity_dim'
                )
            if self.cartan_stretch_bound < 0.0:
                raise ValueError(
                    'cartan_stretch_bound must be non-negative'
                )

        if model_name == 'ResidualKroneckerComplexMatrix2TransERR':
            if not 0.0 <= self.kronecker_identity_floor < 0.05:
                raise ValueError(
                    'kronecker_identity_floor must be in [0, 0.05)'
                )
            group_count = self.entity_dim // 8
            identity = torch.zeros(nrelation, 2, self.entity_dim)
            identity[:, :, :group_count] = 1.0
            identity[:, :, 3 * group_count:4 * group_count] = 1.0
            self.kronecker_left_embedding = nn.Parameter(identity)

            target_weights = torch.tensor([0.05, 0.90, 0.05])
            raw_weights = target_weights.clone()
            floor = self.kronecker_identity_floor
            raw_weights[0] = (raw_weights[0] - floor) / (1.0 - floor)
            raw_weights[1:] = raw_weights[1:] / (1.0 - floor)
            initial_logits = torch.log(raw_weights).view(1, 1, 1, 3)
            self.kronecker_branch_logits = nn.Parameter(
                initial_logits.repeat(nrelation, 2, group_count, 1)
            )

        if model_name == 'HouseholderShearTransERR':
            if self.householder_group_dim < 2:
                raise ValueError(
                    'householder_group_dim must be at least 2'
                )
            if self.entity_dim % self.householder_group_dim != 0:
                raise ValueError(
                    'HouseholderShearTransERR requires hidden_dim '
                    'divisible by householder_group_dim'
                )
            if self.relation_dim != 3 * self.entity_dim:
                raise ValueError(
                    'HouseholderShearTransERR requires '
                    'relation_dim == 3 * entity_dim'
                )
            if self.householder_shear_bound < 0.0:
                raise ValueError(
                    'householder_shear_bound must be non-negative'
                )
            group_count = self.entity_dim // self.householder_group_dim
            with torch.random.fork_rng(devices=[]):
                self.householder_second_axis_embedding = nn.Parameter(
                    torch.empty(nrelation, 2, self.entity_dim)
                )
                nn.init.uniform_(
                    self.householder_second_axis_embedding,
                    -self.embedding_range.item(),
                    self.embedding_range.item()
                )
            self.householder_shear_raw = nn.Parameter(torch.zeros(
                nrelation, 2, group_count
            ))

        if model_name == 'ResidualSubspaceTransERR':
            if self.subspace_groups <= 1:
                raise ValueError('subspace_groups must be greater than 1')
            if self.entity_dim % self.subspace_groups != 0:
                raise ValueError(
                    'hidden_dim must be divisible by subspace_groups'
                )
            # Uniform logits make the initial metric exactly unweighted.
            self.subspace_logits = nn.Parameter(
                torch.zeros(nrelation, self.subspace_groups)
            )

        if model_name == 'AdaptiveFrameTransERR':
            if self.frame_temperature <= 0.0:
                raise ValueError('frame_temperature must be positive')
            if not 0.0 <= self.frame_min_weight < 1.0 / 3.0:
                raise ValueError(
                    'frame_min_weight must be in [0, 1/3)'
                )
            # Branch order: direct TransERR, RelativeQuaternion, and
            # PreTranslationRelative. Favor the strongest observed branch
            # initially while preserving gradients to all three branches.
            self.frame_router_logits = nn.Parameter(
                torch.zeros(nrelation, 3)
            )
            with torch.no_grad():
                self.frame_router_logits[:, 1] = self.frame_relative_prior

        if model_name == 'BlockAdaptiveFrameTransERR':
            if self.entity_dim % 4 != 0:
                raise ValueError(
                    'BlockAdaptiveFrameTransERR requires hidden_dim divisible by 4'
                )
            if self.block_frame_temperature <= 0.0:
                raise ValueError('block_frame_temperature must be positive')
            if not 0.0 <= self.block_frame_min_weight < 1.0 / 3.0:
                raise ValueError(
                    'block_frame_min_weight must be in [0, 1/3)'
                )
            self.block_frame_router_logits = nn.Parameter(torch.zeros(
                nrelation, self.entity_dim // 4, 3
            ))
            with torch.no_grad():
                self.block_frame_router_logits[
                    :, :, 1
                ] = self.block_frame_relative_prior

        geometric_models = (
            'BiRotorTransERR', 'CliffordRotorTransERR',
            'LieGeodesicTransERR', 'ScrewFrameTransERR',
            'CayleyOrthogonalTransERR', 'CayleyFrameFusionTransERR',
            'BlockCayleyFrameFusionTransERR',
            'ResidualSO4TransERR', 'CoupledResidualSO4TransERR',
            'RelativeResidualSO4TransERR', 'GatedResidualSO4TransERR',
            'DomainRangeGatedSO4TransERR', 'ProjectedGatedSO4TransERR',
            'RelativeGatedSO4TransERR',
            'RelativeCayleyFusionTransERR',
            'DecoupledRelativeCayleyFusionTransERR',
            'QuaternionMobiusTransERR'
        )
        if model_name in geometric_models:
            if self.relation_dim != 3 * self.entity_dim:
                raise ValueError(
                    '%s requires relation_dim == 3 * entity_dim'
                    % model_name
                )

        quaternion_geometric_models = (
            'BiRotorTransERR', 'LieGeodesicTransERR',
            'ScrewFrameTransERR', 'CayleyOrthogonalTransERR',
            'CayleyFrameFusionTransERR',
            'BlockCayleyFrameFusionTransERR',
            'ResidualSO4TransERR', 'CoupledResidualSO4TransERR',
            'RelativeResidualSO4TransERR', 'GatedResidualSO4TransERR',
            'DomainRangeGatedSO4TransERR', 'ProjectedGatedSO4TransERR',
            'RelativeGatedSO4TransERR',
            'RelativeCayleyFusionTransERR',
            'DecoupledRelativeCayleyFusionTransERR',
            'QuaternionMobiusTransERR'
        )
        if (model_name in quaternion_geometric_models
                and self.entity_dim % 4 != 0):
            raise ValueError(
                '%s requires hidden_dim divisible by 4' % model_name
            )

        if model_name == 'BiRotorTransERR':
            # The stored TransERR relation chunks remain the right actions.
            # Identity left rotors make the initial score exactly TransERR.
            self.birotor_left_embedding = nn.Parameter(
                torch.zeros(nrelation, 2 * self.entity_dim)
            )
            quaternion_width = self.entity_dim // 4
            with torch.no_grad():
                self.birotor_left_embedding[
                    :, :quaternion_width
                ] = 1.0
                self.birotor_left_embedding[
                    :, self.entity_dim:
                    self.entity_dim + quaternion_width
                ] = 1.0

        if model_name == 'CliffordRotorTransERR':
            if self.entity_dim % 8 != 0:
                raise ValueError(
                    'CliffordRotorTransERR requires hidden_dim divisible by 8'
                )

        if model_name in ('LieGeodesicTransERR', 'ScrewFrameTransERR'):
            if not 0.0 < self.lie_angle_bound <= 2.0 * math.pi:
                raise ValueError(
                    'lie_angle_bound must be in (0, 2*pi]'
                )

        if model_name == 'ScrewFrameTransERR':
            if self.screw_distance_bound <= 0.0:
                raise ValueError('screw_distance_bound must be positive')
            self.screw_distance_embedding = nn.Parameter(
                torch.zeros(nrelation, self.entity_dim // 4)
            )

        if model_name in (
                'CayleyOrthogonalTransERR', 'CayleyFrameFusionTransERR',
                'BlockCayleyFrameFusionTransERR',
                'RelativeCayleyFusionTransERR',
                'DecoupledRelativeCayleyFusionTransERR'):
            # Four generator channels come from each original relation chunk;
            # these two extra channels complete a 4x4 skew matrix per side.
            self.cayley_extra_embedding = nn.Parameter(
                torch.zeros(nrelation, self.entity_dim)
            )

        if model_name in (
                'CayleyFrameFusionTransERR',
                'RelativeCayleyFusionTransERR',
                'DecoupledRelativeCayleyFusionTransERR'):
            if self.orthogonal_temperature <= 0.0:
                raise ValueError('orthogonal_temperature must be positive')
            if not 0.0 <= self.frame_min_weight < 0.5:
                raise ValueError('frame_min_weight must be in [0, 1/2)')
            self.orthogonal_router_logits = nn.Parameter(
                torch.zeros(nrelation, 2)
            )
            with torch.no_grad():
                if model_name in (
                        'RelativeCayleyFusionTransERR',
                        'DecoupledRelativeCayleyFusionTransERR'):
                    self.orthogonal_router_logits[
                        :, 0
                    ] = self.frame_relative_prior
                self.orthogonal_router_logits[
                    :, 1
                ] = self.orthogonal_cayley_prior

        if model_name == 'BlockCayleyFrameFusionTransERR':
            if self.block_frame_temperature <= 0.0:
                raise ValueError('block_frame_temperature must be positive')
            if not 0.0 <= self.block_frame_min_weight < 0.5:
                raise ValueError(
                    'block_frame_min_weight must be in [0, 1/2)'
                )
            self.block_orthogonal_router_logits = nn.Parameter(torch.zeros(
                nrelation, self.entity_dim // 4, 2
            ))
            with torch.no_grad():
                self.block_orthogonal_router_logits[
                    :, :, 1
                ] = self.orthogonal_cayley_prior

        if model_name == 'ResidualSO4TransERR':
            if self.residual_so4_bound < 0.0:
                raise ValueError('residual_so4_bound must be non-negative')
            # Per side: four base and two extra skew-generator channels.
            # Zero generators produce identity residual maps exactly.
            self.residual_so4_embedding = nn.Parameter(torch.zeros(
                nrelation, 3 * self.entity_dim
            ))

        if model_name == 'CoupledResidualSO4TransERR':
            if self.residual_so4_bound < 0.0:
                raise ValueError('residual_so4_bound must be non-negative')
            # One six-channel SO(4) generator per quaternion block. Applying
            # opposite half steps to head and tail keeps both corrections on
            # one coherent relative transform and halves the parameter count.
            self.coupled_residual_so4_embedding = nn.Parameter(torch.zeros(
                nrelation, 3 * self.entity_dim // 2
            ))

        if model_name == 'RelativeResidualSO4TransERR':
            if self.residual_so4_bound < 0.0:
                raise ValueError('residual_so4_bound must be non-negative')
            # A single relation map moves the transformed head into the
            # unchanged tail/translation frame.
            self.relative_residual_so4_embedding = nn.Parameter(torch.zeros(
                nrelation, 3 * self.entity_dim // 2
            ))

        if model_name in (
                'GatedResidualSO4TransERR',
                'DomainRangeGatedSO4TransERR',
                'ProjectedGatedSO4TransERR',
                'RelativeGatedSO4TransERR'):
            if self.residual_so4_bound < 0.0:
                raise ValueError('residual_so4_bound must be non-negative')
            # Independent SO(4) corrections provide the geometric branch.
            # Zero generators make both branches identical at initialization.
            self.residual_so4_embedding = nn.Parameter(torch.zeros(
                nrelation, 3 * self.entity_dim
            ))
            # Each relation chooses between the original and geometric
            # residual independently for every quaternion coordinate block.
            self.residual_so4_gate_logits = nn.Parameter(torch.zeros(
                nrelation, self.entity_dim // 4
            ))

        if model_name == 'DecoupledRelativeCayleyFusionTransERR':
            # Begin with exactly the coupled Cayley generators, then let the
            # two branches optimize their incompatible parameter semantics
            # independently without changing the sampler RNG stream.
            self.cayley_relation_embedding = nn.Parameter(torch.cat([
                self.relation_embedding[:, :self.entity_dim],
                self.relation_embedding[:, 2 * self.entity_dim:],
            ], dim=1).detach().clone())

        if model_name == 'QuaternionMobiusTransERR':
            if self.mobius_c_bound <= 0.0:
                raise ValueError('mobius_c_bound must be positive')
            if self.mobius_denominator_epsilon <= 0.0:
                raise ValueError(
                    'mobius_denominator_epsilon must be positive'
                )
            # [head_c, head_d, tail_b, tail_c, tail_d].  Zero c/b and
            # identity d reduce both fractional maps to TransERR at step 0.
            self.mobius_aux_embedding = nn.Parameter(
                torch.zeros(nrelation, 5 * self.entity_dim)
            )
            quaternion_width = self.entity_dim // 4
            with torch.no_grad():
                self.mobius_aux_embedding[
                    :, self.entity_dim:
                    self.entity_dim + quaternion_width
                ] = 1.0
                self.mobius_aux_embedding[
                    :, 4 * self.entity_dim:
                    4 * self.entity_dim + quaternion_width
                ] = 1.0
        
        if model_name == 'pRotatE':
            self.modulus = nn.Parameter(torch.Tensor([[0.5 * self.embedding_range.item()]]))
        
        #Do not forget to modify this line when you add a new model in the "forward" function
        if (model_name not in ['TransE', 'DistMult', 'ComplEx', 'RotatE',
                              'pRotatE', 'TransERR', 'SpectralTransERR', 'KerrTransERR', 'FoldTransERR', 'LocalOTTransERR',
                              'ImplicitQuadraticTransERR', 'BuresTransERR',
                              'DoubleCenterTransERR', 'RegionTransERR', 'ReciprocalTransERR',
                              'ReciprocalRelativeQuaternionTransERR',
                              'CoupledReciprocalTransERR',
                              'CoupledReciprocalRelativeQuaternionTransERR',
                              'TailResidualReciprocalTransERR',
                              'TailResidualReciprocalRelativeQuaternionTransERR',
                              'BidirectionalResidualReciprocalRelativeQuaternionTransERR',
                              'RoleResidualBidirectionalRelativeQuaternionTransERR',
                              'BilinearResidualBidirectionalRelativeQuaternionTransERR',
                              'RelationMetricBidirectionalRelativeQuaternionTransERR',
                              'HamiltonCompatibilityBidirectionalRelativeQuaternionTransERR',
                              'ResidualEnergyBidirectionalRelativeQuaternionTransERR',
                              'TwoSidedBidirectionalRelativeQuaternionTransERR',
                              'ConjugateGatedBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                              'InverseConjugateGatedBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                              'FullCayleyBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                              'Rank2CayleyBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                              'BidirectionalTranslationResidualReciprocalRelativeQuaternionTransERR',
                              'CoupledTranslationResidualReciprocalRelativeQuaternionTransERR',
                              'GatedCoupledTranslationResidualReciprocalRelativeQuaternionTransERR',
                              'SoftExtremalBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                              'MaxMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                              'MeanVarianceBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                              'PMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                              'RoleSeparatedReciprocalTransERR',
                              'BoundedRoleReciprocalTransERR',
                              'ContextTransERR',
                              'RelationEntityBiasTransERR',
                              'DomainRangeProjectionTransERR',
                              'ScaleGroupTransERR', 'ScaleDimTransERR',
                              'MoGeoTransERR', 'DualQuaternionTransERR',
                              'OctonionTransERR', 'BiquaternionTransERR',
                              'AdaptiveBiquaternionFusionTransERR',
                              'ConvexBiquaternionFusionTransERR',
                              'AdaptiveMetricCliffordTransERR',
                              'RealMatrix2TransERR',
                              'ComplexMatrix2TransERR',
                              'ResidualKroneckerComplexMatrix2TransERR',
                              'MidpointCartanComplexTransERR',
                              'HouseholderShearTransERR',
                              'PortHamiltonianTransERR',
                              'StochasticPortHamiltonianTransERR',
                              'CayleyPortHamiltonianTransERR',
                              'RelativeQuaternionTransERR',
                              'AdaptiveFrameTransERR',
                              'BlockAdaptiveFrameTransERR',
                              'ResidualSubspaceTransERR',
                              'SymmetricRelativeTransERR',
                              'PreTranslationRelativeTransERR',
                              'BiRotorTransERR',
                              'CliffordRotorTransERR',
                              'LieGeodesicTransERR',
                              'ScrewFrameTransERR',
                              'CayleyOrthogonalTransERR',
                              'CayleyFrameFusionTransERR',
                              'BlockCayleyFrameFusionTransERR',
                              'ResidualSO4TransERR',
                              'CoupledResidualSO4TransERR',
                              'RelativeResidualSO4TransERR',
                              'GatedResidualSO4TransERR',
                              'DomainRangeGatedSO4TransERR',
                              'ProjectedGatedSO4TransERR',
                              'RelativeGatedSO4TransERR',
                              'RelativeCayleyFusionTransERR',
                              'DecoupledRelativeCayleyFusionTransERR',
                              'QuaternionMobiusTransERR']
                and model_name not in SPIN_MODELS
                and model_name != MIXED_SPIN_MODEL
                and model_name not in _RANK_QUATERNION_OPERATOR_MODELS
                and model_name not in _ADAPTIVE_MOMENT_RECIPROCAL_MODELS
                and model_name not in _BLOCK_TRANSPORT_RECIPROCAL_MODELS
                and model_name not in _INTERLEAVED_BLOCK_TRANSPORT_RECIPROCAL_MODELS
                and model_name not in _ADVANCED_DEFORMATION_RECIPROCAL_MODELS
                and model_name not in _RANK_DEFECT_LOCAL_GLOBAL_MODELS):
            raise ValueError('model %s not supported' % model_name)
            
        if model_name == 'RotatE' and (not double_entity_embedding or double_relation_embedding):
            raise ValueError('RotatE should use --double_entity_embedding')

        if model_name == 'ComplEx' and (not double_entity_embedding or not double_relation_embedding):
            raise ValueError('ComplEx should use --double_entity_embedding and --double_relation_embedding')

        if (model_name == 'MidpointCartanComplexTransERR'
                and (not double_relation_embedding
                     or triple_relation_embedding)):
            raise ValueError(
                'MidpointCartanComplexTransERR should use '
                '--double_relation_embedding only'
            )

        if (model_name in ('TransERR', 'SpectralTransERR', 'KerrTransERR', 'FoldTransERR', 'LocalOTTransERR',
                           'ImplicitQuadraticTransERR', 'BuresTransERR',
                          'DoubleCenterTransERR', 'RegionTransERR', 'ReciprocalTransERR',
                          'ReciprocalRelativeQuaternionTransERR',
                          'CoupledReciprocalTransERR',
                          'CoupledReciprocalRelativeQuaternionTransERR',
                          'TailResidualReciprocalTransERR',
                          'TailResidualReciprocalRelativeQuaternionTransERR',
                          'BidirectionalResidualReciprocalRelativeQuaternionTransERR',
                          'RoleResidualBidirectionalRelativeQuaternionTransERR',
                          'BilinearResidualBidirectionalRelativeQuaternionTransERR',
                          'RelationMetricBidirectionalRelativeQuaternionTransERR',
                          'HamiltonCompatibilityBidirectionalRelativeQuaternionTransERR',
                          'ResidualEnergyBidirectionalRelativeQuaternionTransERR',
                          'TwoSidedBidirectionalRelativeQuaternionTransERR',
                          'FullCayleyBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                          'Rank2CayleyBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                          'BidirectionalTranslationResidualReciprocalRelativeQuaternionTransERR',
                          'CoupledTranslationResidualReciprocalRelativeQuaternionTransERR',
                          'GatedCoupledTranslationResidualReciprocalRelativeQuaternionTransERR',
                          'SoftExtremalBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                          'MaxMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                          'MeanVarianceBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                          'PMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                          'RoleSeparatedReciprocalTransERR',
                          'BoundedRoleReciprocalTransERR',
                          'ContextTransERR',
                          'RelationEntityBiasTransERR',
                          'DomainRangeProjectionTransERR',
                          'ScaleGroupTransERR', 'ScaleDimTransERR',
                          'MoGeoTransERR', 'DualQuaternionTransERR',
                          'OctonionTransERR', 'BiquaternionTransERR',
                          'AdaptiveBiquaternionFusionTransERR',
                          'ConvexBiquaternionFusionTransERR',
                          'AdaptiveMetricCliffordTransERR',
                          'RealMatrix2TransERR',
                          'ComplexMatrix2TransERR',
                          'ResidualKroneckerComplexMatrix2TransERR',
                          'HouseholderShearTransERR',
                          'PortHamiltonianTransERR',
                          'StochasticPortHamiltonianTransERR',
                          'CayleyPortHamiltonianTransERR',
                          'RelativeQuaternionTransERR',
                          'AdaptiveFrameTransERR',
                          'BlockAdaptiveFrameTransERR',
                          'ResidualSubspaceTransERR',
                          'SymmetricRelativeTransERR',
                          'PreTranslationRelativeTransERR',
                          'BiRotorTransERR',
                          'CliffordRotorTransERR',
                          'LieGeodesicTransERR',
                          'ScrewFrameTransERR',
                          'CayleyOrthogonalTransERR',
                          'CayleyFrameFusionTransERR',
                          'BlockCayleyFrameFusionTransERR',
                          'ResidualSO4TransERR',
                          'CoupledResidualSO4TransERR',
                          'RelativeResidualSO4TransERR',
                          'GatedResidualSO4TransERR',
                          'DomainRangeGatedSO4TransERR',
                          'ProjectedGatedSO4TransERR',
                          'RelativeGatedSO4TransERR',
                          'RelativeCayleyFusionTransERR',
                          'DecoupledRelativeCayleyFusionTransERR',
                          'QuaternionMobiusTransERR')
                or model_name in _RANK_QUATERNION_OPERATOR_MODELS
                or model_name in _ADVANCED_DEFORMATION_RECIPROCAL_MODELS
                or model_name in _RANK_DEFECT_LOCAL_GLOBAL_MODELS
                ) and (not triple_relation_embedding):
            raise ValueError('%s should use --triple_relation_embedding' % model_name)
        
    def forward(self, sample, mode='single'):
        '''
        Forward function that calculate the score of a batch of triples.
        In the 'single' mode, sample is a batch of triple.
        In the 'head-batch' or 'tail-batch' mode, sample consists two part.
        The first part is usually the positive sample.
        And the second part is the entities in the negative samples.
        Because negative samples and positive samples usually share two elements 
        in their triple ((head, relation) or (relation, tail)).
        '''

        role_separated = (
            self.model_name == 'RoleSeparatedReciprocalTransERR'
        )
        bounded_role = self.model_name in (
            'BoundedRoleReciprocalTransERR',
            'RoleResidualBidirectionalRelativeQuaternionTransERR'
        )

        def select_entity(index, role):
            table = self.entity_embedding
            if role_separated and role == 'target':
                table = self.target_entity_embedding
            selected = torch.index_select(table, dim=0, index=index)
            if bounded_role:
                delta = torch.index_select(
                    self.role_delta_embedding, dim=0, index=index
                )
                sign = 1.0 if role == 'source' else -1.0
                selected = selected + (
                    sign * self.role_delta_bound * torch.tanh(delta)
                )
            return selected

        if mode in ('single', 'head-single', 'tail-single'):
            batch_size, negative_sample_size = sample.size(0), 1
            relation_id = sample[:, 1]

            head_role = 'source'
            tail_role = 'target'
            if role_separated and mode == 'head-single':
                head_role, tail_role = 'target', 'source'
            elif bounded_role and mode == 'head-single':
                head_role, tail_role = 'target', 'source'
            
            head = select_entity(sample[:, 0], head_role).unsqueeze(1)
            
            relation = torch.index_select(
                self.relation_embedding, 
                dim=0, 
                index=sample[:,1]
            ).unsqueeze(1)
            
            tail = select_entity(sample[:, 2], tail_role).unsqueeze(1)
            
        elif mode == 'head-batch':
            tail_part, head_part = sample
            batch_size, negative_sample_size = head_part.size(0), head_part.size(1)
            relation_id = tail_part[:, 1]
            
            head = select_entity(
                head_part.view(-1), 'target'
            ).view(batch_size, negative_sample_size, -1)
            
            relation = torch.index_select(
                self.relation_embedding, 
                dim=0, 
                index=tail_part[:, 1]
            ).unsqueeze(1)
            
            tail = select_entity(
                tail_part[:, 2], 'source'
            ).unsqueeze(1)
            
        elif mode == 'tail-batch':
            head_part, tail_part = sample
            batch_size, negative_sample_size = tail_part.size(0), tail_part.size(1)
            relation_id = head_part[:, 1]
            
            head = select_entity(
                head_part[:, 0], 'source'
            ).unsqueeze(1)
            
            relation = torch.index_select(
                self.relation_embedding,
                dim=0,
                index=head_part[:, 1]
            ).unsqueeze(1)
            
            tail = select_entity(
                tail_part.view(-1), 'target'
            ).view(batch_size, negative_sample_size, -1)
            
        else:
            raise ValueError('mode %s not supported' % mode)

        score_mode = mode
        cayley_inverse_direction = mode in ('head-batch', 'head-single')
        independent_reciprocal = self.model_name in (
                'ReciprocalTransERR',
                'ReciprocalRelativeQuaternionTransERR',
                'RoleSeparatedReciprocalTransERR',
                'BoundedRoleReciprocalTransERR')
        coupled_reciprocal = self.model_name in (
            'CoupledReciprocalTransERR',
            'CoupledReciprocalRelativeQuaternionTransERR'
        )
        tail_residual_reciprocal = self.model_name in (
            'TailResidualReciprocalTransERR',
            'TailResidualReciprocalRelativeQuaternionTransERR'
        )
        bidirectional_residual_reciprocal = self.model_name in (
                'BidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'RoleResidualBidirectionalRelativeQuaternionTransERR',
                'BilinearResidualBidirectionalRelativeQuaternionTransERR',
                'RelationMetricBidirectionalRelativeQuaternionTransERR',
                'HamiltonCompatibilityBidirectionalRelativeQuaternionTransERR',
                'ResidualEnergyBidirectionalRelativeQuaternionTransERR',
                'ConjugateGatedBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'InverseConjugateGatedBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'SoftExtremalBidirectionalResidualReciprocalRelativeQuaternionTransERR',
            'MaxMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR',
            'MeanVarianceBidirectionalResidualReciprocalRelativeQuaternionTransERR',
            'PMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR'
        ) or self.model_name in _CAYLEY_RESIDUAL_RECIPROCAL_MODELS \
            or self.model_name in _TWO_SIDED_RECIPROCAL_MODELS \
            or self.model_name in _ADAPTIVE_MOMENT_RECIPROCAL_MODELS \
            or self.model_name in _BLOCK_TRANSPORT_RECIPROCAL_MODELS \
            or self.model_name in _INTERLEAVED_BLOCK_TRANSPORT_RECIPROCAL_MODELS \
            or self.model_name in _RANK_QUATERNION_OPERATOR_MODELS \
            or self.model_name in _ADVANCED_DEFORMATION_RECIPROCAL_MODELS \
            or self.model_name in _RANK_DEFECT_LOCAL_GLOBAL_MODELS
        bidirectional_translation_residual_reciprocal = (
            self.model_name ==
            'BidirectionalTranslationResidualReciprocalRelativeQuaternionTransERR'
        )
        coupled_translation_residual_reciprocal = (
            self.model_name in _COUPLED_TRANSLATION_RESIDUAL_MODELS
        )
        if (independent_reciprocal or coupled_reciprocal
                or tail_residual_reciprocal
                or bidirectional_residual_reciprocal
                or bidirectional_translation_residual_reciprocal
                or coupled_translation_residual_reciprocal):
            if mode in ('head-batch', 'head-single'):
                if coupled_translation_residual_reciprocal:
                    relation = self._coupled_translation_residual_relation(
                        relation, relation_id, inverse=True
                    )
                elif bidirectional_translation_residual_reciprocal:
                    relation = self._translation_residual_inverse_relation(
                        relation, relation_id
                    )
                elif (coupled_reciprocal
                        or bidirectional_residual_reciprocal):
                    relation = self._coupled_inverse_relation(
                        relation, relation_id
                    )
                elif tail_residual_reciprocal:
                    relation = self._analytic_inverse_relation(relation)
                else:
                    relation = torch.index_select(
                        self.inverse_relation_embedding,
                        dim=0,
                        index=relation_id
                    ).unsqueeze(1)
                head, tail = tail, head
                score_mode = 'tail-batch'
            elif mode in ('single', 'tail-single', 'tail-batch'):
                if coupled_translation_residual_reciprocal:
                    relation = self._coupled_translation_residual_relation(
                        relation, relation_id, inverse=False
                    )
                elif bidirectional_translation_residual_reciprocal:
                    relation = self._translation_residual_relation(
                        relation, relation_id,
                        self.tail_relation_residual
                    )
                elif (tail_residual_reciprocal
                        or bidirectional_residual_reciprocal):
                    relation = self._tail_residual_relation(
                        relation, relation_id
                    )
                score_mode = 'tail-batch'
            
        model_func = {
            'TransE': self.TransE,
            'DistMult': self.DistMult,
            'ComplEx': self.ComplEx,
            'RotatE': self.RotatE,
            'pRotatE': self.pRotatE,
            'TransERR': self.TransERR,
            'SpinThreeHalfTransERR': self.SpinTransERR,
            'SharedQuaternion8TransERR': self.SpinTransERR,
            MIXED_SPIN_MODEL: self.MixedSpinTransERR,
            'BiquaternionTransERR': self.BiquaternionTransERR,
            'RealMatrix2TransERR': self.RealMatrix2TransERR,
            'ComplexMatrix2TransERR': self.ComplexMatrix2TransERR,
            'MidpointCartanComplexTransERR': (
                self.MidpointCartanComplexTransERR
            ),
            'ReciprocalTransERR': self.TransERR,
            'ReciprocalRelativeQuaternionTransERR': (
                self.RelativeQuaternionTransERR
            ),
            'CoupledReciprocalTransERR': self.TransERR,
            'CoupledReciprocalRelativeQuaternionTransERR': (
                self.RelativeQuaternionTransERR
            ),
            'TailResidualReciprocalTransERR': self.TransERR,
            'TailResidualReciprocalRelativeQuaternionTransERR': (
                self.RelativeQuaternionTransERR
            ),
            'BidirectionalResidualReciprocalRelativeQuaternionTransERR': (
                self.RelativeQuaternionTransERR
            ),
            'RoleResidualBidirectionalRelativeQuaternionTransERR': (
                self.RelativeQuaternionTransERR
            ),
            'BidirectionalTranslationResidualReciprocalRelativeQuaternionTransERR': (
                self.RelativeQuaternionTransERR
            ),
            'CoupledTranslationResidualReciprocalRelativeQuaternionTransERR': (
                self.RelativeQuaternionTransERR
            ),
            'GatedCoupledTranslationResidualReciprocalRelativeQuaternionTransERR': (
                self.RelativeQuaternionTransERR
            ),
            'RoleSeparatedReciprocalTransERR': self.TransERR,
            'BoundedRoleReciprocalTransERR': self.TransERR,
        }

        if self.model_name == 'DoubleCenterTransERR':
            score = self.DoubleCenterTransERR(head, relation, tail, relation_id)
        elif self.model_name == 'SpectralTransERR':
            score = self.SpectralTransERR(head, relation, tail, relation_id)
        elif self.model_name == 'KerrTransERR':
            score = self.KerrTransERR(head, relation, tail, relation_id)
        elif self.model_name == 'FoldTransERR':
            score = self.FoldTransERR(head, relation, tail)
        elif self.model_name == 'LocalOTTransERR':
            score = self.LocalOTTransERR(head, relation, tail)
        elif self.model_name == 'ImplicitQuadraticTransERR':
            score = self.ImplicitQuadraticTransERR(head, relation, tail, relation_id)
        elif self.model_name == 'BuresTransERR':
            score = self.BuresTransERR(head, relation, tail, relation_id)
        elif self.model_name == 'RegionTransERR':
            score = self.RegionTransERR(head, relation, tail, relation_id)
        elif self.model_name == 'ContextTransERR':
            score = self.ContextTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'RelationEntityBiasTransERR':
            score = self.RelationEntityBiasTransERR(
                head, relation, tail, relation_id, sample, mode
            )
        elif self.model_name == 'DomainRangeProjectionTransERR':
            score = self.DomainRangeProjectionTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name in ('ScaleGroupTransERR', 'ScaleDimTransERR'):
            score = self.ScaleTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'MoGeoTransERR':
            score = self.MoGeoTransERR(
                head, relation, tail, relation_id, sample, mode
            )
        elif self.model_name == 'DualQuaternionTransERR':
            score = self.DualQuaternionTransERR(
                head, relation, tail, relation_id, sample, mode
            )
        elif self.model_name == 'OctonionTransERR':
            score = self.OctonionTransERR(head, relation, tail, mode)
        elif self.model_name == 'AdaptiveBiquaternionFusionTransERR':
            score = self.AdaptiveBiquaternionFusionTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'ConvexBiquaternionFusionTransERR':
            score = self.ConvexBiquaternionFusionTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'AdaptiveMetricCliffordTransERR':
            score = self.AdaptiveMetricCliffordTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'ResidualKroneckerComplexMatrix2TransERR':
            score = self.ResidualKroneckerComplexMatrix2TransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'HouseholderShearTransERR':
            score = self.HouseholderShearTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name in _PORT_HAMILTONIAN_MODELS:
            score = self.PortHamiltonianTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'RelativeQuaternionTransERR':
            score = self.RelativeQuaternionTransERR(
                head, relation, tail, mode
            )
        elif self.model_name == 'AdaptiveFrameTransERR':
            score = self.AdaptiveFrameTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'BlockAdaptiveFrameTransERR':
            score = self.BlockAdaptiveFrameTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'ResidualSubspaceTransERR':
            score = self.ResidualSubspaceTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'SymmetricRelativeTransERR':
            score = self.SymmetricRelativeTransERR(
                head, relation, tail, mode
            )
        elif self.model_name == 'PreTranslationRelativeTransERR':
            score = self.PreTranslationRelativeTransERR(
                head, relation, tail, mode
            )
        elif self.model_name == 'BiRotorTransERR':
            score = self.BiRotorTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'CliffordRotorTransERR':
            score = self.CliffordRotorTransERR(
                head, relation, tail, mode
            )
        elif self.model_name == 'LieGeodesicTransERR':
            score = self.LieGeodesicTransERR(
                head, relation, tail, mode
            )
        elif self.model_name == 'ScrewFrameTransERR':
            score = self.ScrewFrameTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'CayleyOrthogonalTransERR':
            score = self.CayleyOrthogonalTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'CayleyFrameFusionTransERR':
            score = self.CayleyFrameFusionTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'BlockCayleyFrameFusionTransERR':
            score = self.BlockCayleyFrameFusionTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'ResidualSO4TransERR':
            score = self.ResidualSO4TransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'CoupledResidualSO4TransERR':
            score = self.CoupledResidualSO4TransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'RelativeResidualSO4TransERR':
            score = self.RelativeResidualSO4TransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'GatedResidualSO4TransERR':
            score = self.GatedResidualSO4TransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'DomainRangeGatedSO4TransERR':
            score = self.DomainRangeGatedSO4TransERR(
                head, relation, tail, relation_id, sample, mode
            )
        elif self.model_name == 'ProjectedGatedSO4TransERR':
            score = self.ProjectedGatedSO4TransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'RelativeGatedSO4TransERR':
            score = self.RelativeGatedSO4TransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'RelativeCayleyFusionTransERR':
            score = self.RelativeCayleyFusionTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'DecoupledRelativeCayleyFusionTransERR':
            score = self.RelativeCayleyFusionTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name == 'QuaternionMobiusTransERR':
            score = self.QuaternionMobiusTransERR(
                head, relation, tail, relation_id, mode
            )
        elif self.model_name in _CAYLEY_RESIDUAL_RECIPROCAL_MODELS:
            score = self.CayleyResidualRelativeQuaternionTransERR(
                head,
                relation,
                tail,
                relation_id,
                cayley_inverse_direction,
            )
        elif self.model_name in _RANK_QUATERNION_OPERATOR_MODELS:
            score = self.RankQuaternionOperatorTransERR(
                head,
                relation,
                tail,
                relation_id,
                cayley_inverse_direction,
            )
        elif self.model_name in _RANK_DEFECT_LOCAL_GLOBAL_MODELS:
            score = self.RankDefectLocalGlobalRelativeQuaternionTransERR(
                head,
                relation,
                tail,
                relation_id,
                cayley_inverse_direction,
            )
        elif self.model_name == (
                'PolarBidirectionalResidualReciprocalRelativeQuaternionTransERR'):
            score = self.PolarRelativeQuaternionTransERR(
                head, relation, tail, relation_id,
                cayley_inverse_direction,
            )
        elif self.model_name == (
                'FlowBidirectionalResidualReciprocalRelativeQuaternionTransERR'):
            score = self.FlowRelativeQuaternionTransERR(
                head, relation, tail, relation_id,
                cayley_inverse_direction,
            )
        elif self.model_name in _CONJUGATE_GATED_RECIPROCAL_MODELS:
            score = self.ConjugateGatedRelativeQuaternionTransERR(
                head, relation, tail, relation_id,
                inverse_conjugate=(
                    self.model_name
                    == 'InverseConjugateGatedBidirectionalResidualReciprocalRelativeQuaternionTransERR'
                ),
            )
        elif self.model_name in _BILINEAR_RESIDUAL_RECIPROCAL_MODELS:
            score = self.BilinearResidualRelativeQuaternionTransERR(
                head, relation, tail, relation_id
            )
        elif self.model_name in _RELATION_METRIC_RECIPROCAL_MODELS:
            score = self.RelationMetricRelativeQuaternionTransERR(
                head, relation, tail, relation_id
            )
        elif self.model_name in _HAMILTON_COMPATIBILITY_RECIPROCAL_MODELS:
            score = self.HamiltonCompatibilityRelativeQuaternionTransERR(
                head, relation, tail, relation_id
            )
        elif self.model_name in _RESIDUAL_ENERGY_RECIPROCAL_MODELS:
            score = self.ResidualEnergyRelativeQuaternionTransERR(
                head, relation, tail, relation_id
            )
        elif self.model_name in _TWO_SIDED_RECIPROCAL_MODELS:
            score = self.TwoSidedRelativeQuaternionTransERR(
                head, relation, tail, relation_id, cayley_inverse_direction
            )
        elif self.model_name in _ADAPTIVE_MOMENT_RECIPROCAL_MODELS:
            score = self.AdaptiveMomentRelativeQuaternionTransERR(
                head, relation, tail, relation_id
            )
        elif self.model_name in _BLOCK_TRANSPORT_RECIPROCAL_MODELS:
            score = self.BlockQuaternionTransportRelativeQuaternionTransERR(
                head, relation, tail, relation_id, cayley_inverse_direction
            )
        elif self.model_name in _INTERLEAVED_BLOCK_TRANSPORT_RECIPROCAL_MODELS:
            score = self.InterleavedBlockQuaternionTransportRelativeQuaternionTransERR(
                head, relation, tail, relation_id, cayley_inverse_direction
            )
        elif self.model_name == (
                'SoftExtremalBidirectionalResidualReciprocalRelativeQuaternionTransERR'):
            score = self.SoftExtremalRelativeQuaternionTransERR(
                head, relation, tail, relation_id, score_mode
            )
        elif self.model_name == (
                'MaxMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR'):
            score = self.MaxMeanRelativeQuaternionTransERR(
                head, relation, tail, relation_id, score_mode
            )
        elif self.model_name == (
                'MeanVarianceBidirectionalResidualReciprocalRelativeQuaternionTransERR'):
            score = self.MeanVarianceRelativeQuaternionTransERR(
                head, relation, tail, relation_id, score_mode
            )
        elif self.model_name == (
                'PMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR'):
            score = self.PMeanRelativeQuaternionTransERR(
                head, relation, tail, relation_id, score_mode
            )
        elif self.model_name in model_func:
            score = model_func[self.model_name](
                head, relation, tail, score_mode
            )
        else:
            raise ValueError('model %s not supported' % self.model_name)
        
        return score
    
    def TransE(self, head, relation, tail, mode):
        if mode == 'head-batch':
            score = head + (relation - tail)
        else:
            score = (head + relation) - tail

        score = self.gamma.item() - torch.norm(score, p=1, dim=2)
        return score

    def DistMult(self, head, relation, tail, mode):
        if mode == 'head-batch':
            score = head * (relation * tail)
        else:
            score = (head * relation) * tail

        score = score.sum(dim = 2)
        return score

    def ComplEx(self, head, relation, tail, mode):
        re_head, im_head = torch.chunk(head, 2, dim=2)
        re_relation, im_relation = torch.chunk(relation, 2, dim=2)
        re_tail, im_tail = torch.chunk(tail, 2, dim=2)

        if mode == 'head-batch':
            re_score = re_relation * re_tail + im_relation * im_tail
            im_score = re_relation * im_tail - im_relation * re_tail
            score = re_head * re_score + im_head * im_score
        else:
            re_score = re_head * re_relation - im_head * im_relation
            im_score = re_head * im_relation + im_head * re_relation
            score = re_score * re_tail + im_score * im_tail

        score = score.sum(dim = 2)
        return score

    def RotatE(self, head, relation, tail, mode):
        pi = 3.14159265358979323846
        
        re_head, im_head = torch.chunk(head, 2, dim=2)
        re_tail, im_tail = torch.chunk(tail, 2, dim=2)

        #Make phases of relations uniformly distributed in [-pi, pi]

        phase_relation = relation/(self.embedding_range.item()/pi)

        re_relation = torch.cos(phase_relation)
        im_relation = torch.sin(phase_relation)

        if mode == 'head-batch':
            re_score = re_relation * re_tail + im_relation * im_tail
            im_score = re_relation * im_tail - im_relation * re_tail
            re_score = re_score - re_head
            im_score = im_score - im_head
        else:
            re_score = re_head * re_relation - im_head * im_relation
            im_score = re_head * im_relation + im_head * re_relation
            re_score = re_score - re_tail
            im_score = im_score - im_tail

        score = torch.stack([re_score, im_score], dim = 0)
        score = score.norm(dim = 0)

        score = self.gamma.item() - score.sum(dim = 2)
        return score

    def pRotatE(self, head, relation, tail, mode):
        pi = 3.14159262358979323846
        
        #Make phases of entities and relations uniformly distributed in [-pi, pi]

        phase_head = head/(self.embedding_range.item()/pi)
        phase_relation = relation/(self.embedding_range.item()/pi)
        phase_tail = tail/(self.embedding_range.item()/pi)

        if mode == 'head-batch':
            score = phase_head + (phase_relation - phase_tail)
        else:
            score = (phase_head + phase_relation) - phase_tail

        score = torch.sin(score)            
        score = torch.abs(score)

        score = self.gamma.item() - score.sum(dim = 2) * self.modulus
        return score

    def _analytic_inverse_relation(self, relation):
        """Return the exact reverse transformation in stored relation form."""
        if self.model_name in (
                'CoupledReciprocalRelativeQuaternionTransERR',
                'TailResidualReciprocalRelativeQuaternionTransERR',
                'BidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'RoleResidualBidirectionalRelativeQuaternionTransERR',
                'BilinearResidualBidirectionalRelativeQuaternionTransERR',
                'RelationMetricBidirectionalRelativeQuaternionTransERR',
                'HamiltonCompatibilityBidirectionalRelativeQuaternionTransERR',
                'ResidualEnergyBidirectionalRelativeQuaternionTransERR',
                'ConjugateGatedBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'InverseConjugateGatedBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'FullCayleyBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'Rank2CayleyBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'BidirectionalTranslationResidualReciprocalRelativeQuaternionTransERR',
                'SoftExtremalBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'MaxMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'MeanVarianceBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'PMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR') \
                or self.model_name in _COUPLED_TRANSLATION_RESIDUAL_MODELS \
                or self.model_name in _TWO_SIDED_RECIPROCAL_MODELS \
                or self.model_name in _ADAPTIVE_MOMENT_RECIPROCAL_MODELS \
                or self.model_name in _BLOCK_TRANSPORT_RECIPROCAL_MODELS \
                or self.model_name in _INTERLEAVED_BLOCK_TRANSPORT_RECIPROCAL_MODELS \
                or self.model_name in _RANK_QUATERNION_OPERATOR_MODELS \
                or self.model_name in _ADVANCED_DEFORMATION_RECIPROCAL_MODELS \
                or self.model_name in _RANK_DEFECT_LOCAL_GLOBAL_MODELS:
            return analytic_inverse_relative_relation(relation)
        first, translation, third = torch.chunk(relation, 3, dim=2)
        return torch.cat([third, -translation, first], dim=2)

    def _coupled_inverse_relation(self, relation, relation_id):
        """Build an analytic inverse plus a bounded head residual."""
        analytic_inverse = self._analytic_inverse_relation(relation)
        return apply_bounded_relation_residual(
            analytic_inverse,
            self.inverse_relation_residual,
            relation_id,
            self.reciprocal_residual_bound,
        )

    def _tail_residual_relation(self, relation, relation_id):
        return apply_bounded_relation_residual(
            relation,
            self.tail_relation_residual,
            relation_id,
            self.reciprocal_residual_bound,
        )

    def _translation_residual_relation(
            self, relation, relation_id, residual_table):
        first, translation, third = torch.chunk(relation, 3, dim=2)
        residual = torch.index_select(
            residual_table, dim=0, index=relation_id
        ).unsqueeze(1)
        translation = translation + (
            self.reciprocal_residual_bound * torch.tanh(residual)
        )
        return torch.cat([first, translation, third], dim=2)

    def _translation_residual_inverse_relation(
            self, relation, relation_id):
        analytic_inverse = self._analytic_inverse_relation(relation)
        return self._translation_residual_relation(
            analytic_inverse,
            relation_id,
            self.inverse_relation_residual
        )

    def _coupled_translation_residual_relation(
            self, relation, relation_id, inverse=False):
        if inverse:
            relation = self._analytic_inverse_relation(relation)
        first, translation, third = torch.chunk(relation, 3, dim=2)
        residual = torch.index_select(
            self.tail_relation_residual, dim=0, index=relation_id
        ).unsqueeze(1)
        residual = self.reciprocal_residual_bound * torch.tanh(residual)
        if self.model_name == (
                'GatedCoupledTranslationResidualReciprocalRelativeQuaternionTransERR'):
            gate_table = (
                self.inverse_translation_residual_gate if inverse
                else self.forward_translation_residual_gate
            )
            gate = torch.sigmoid(torch.index_select(
                gate_table, dim=0, index=relation_id
            )).unsqueeze(1)
            residual = gate * residual
        translation = (
            translation - residual if inverse
            else translation + residual
        )
        return torch.cat([first, translation, third], dim=2)

    def TransERR(self, head, relation, tail, mode):
        wh, r, wt = torch.chunk(relation, 3, dim=2)
        wh = self.q_norm(wh)
        wt = self.q_norm(wt)
        score = self._calc(head,wh) + r - self._calc(tail,wt)
        score = self.gamma.item() - torch.norm(score, p=1, dim=2)
        return score

    def SpectralTransERR(self, head, relation, tail, relation_id):
        wh, translation, wt = torch.chunk(relation, 3, dim=2)
        phases = self.spectral_phase.index_select(0, relation_id)
        source = spectral_mix(self._calc(head, self.q_norm(wh)), phases[:, 0].unsqueeze(1))
        target = spectral_mix(self._calc(tail, self.q_norm(wt)), phases[:, 1].unsqueeze(1))
        return self.gamma.item() - torch.norm(source + translation - target, p=1, dim=2)

    def SpinTransERR(self, head, relation, tail, mode):
        source_frame, translation, target_frame = split_spin_relation(relation, self.entity_dim)
        source = apply_spin_operator(head, spin_operator(source_frame, self.model_name))
        target = apply_spin_operator(tail, spin_operator(target_frame, self.model_name))
        return self.gamma.item() - (source + translation - target).norm(p=1, dim=-1)

    def MixedSpinTransERR(self, head, relation, tail, mode):
        source_frame, translation, target_frame = split_mixed_relation(relation, self.entity_dim)
        source = apply_mixed_spin(head, source_frame)
        target = apply_mixed_spin(tail, target_frame)
        return self.gamma.item() - (source + translation - target).norm(p=1, dim=-1)

    def effective_kerr_coefficients(self):
        return (self.kerr_phase_bound / 2) * self.kerr_coefficients_raw.tanh()

    def KerrTransERR(self, head, relation, tail, relation_id):
        wh, translation, wt = relation.chunk(3, dim=-1)
        coefficients = self.effective_kerr_coefficients().index_select(0, relation_id)
        source = kerr_transform(self._calc(head, self.q_norm(wh)),
                                coefficients[:, 0].unsqueeze(1), self.kerr_intensity_scale)
        target = kerr_transform(self._calc(tail, self.q_norm(wt)),
                                coefficients[:, 1].unsqueeze(1), self.kerr_intensity_scale)
        return self.gamma.item() - (source + translation - target).norm(p=1, dim=-1)

    def FoldTransERR(self, head, relation, tail):
        wh, translation, wt = relation.chunk(3, dim=-1)
        source = fold_transform(self._calc(head, self.q_norm(wh)))
        target = fold_transform(self._calc(tail, self.q_norm(wt)))
        return self.gamma.item() - (source + translation - target).norm(p=1, dim=-1)

    def LocalOTTransERR(self, head, relation, tail):
        wh, translation, wt = relation.chunk(3, dim=-1)
        source = self._calc(head, self.q_norm(wh)) + translation
        target = self._calc(tail, self.q_norm(wt))
        return self.gamma.item() - local_ot_distance(
            source, target, self.local_ot_window, self.local_ot_temperature,
            self.local_ot_prior_mix, self.local_ot_chunk_size, self.local_ot_max_iter,
            self.local_ot_tolerance, self.local_ot_identity)

    def quadratic_endpoint_correction(self, source, target, relation_id):
        return quadratic_correction(
            source, target, self.quadratic_source_projection[relation_id],
            self.quadratic_target_projection[relation_id],
            self.quadratic_bound * self.quadratic_output_raw[relation_id].tanh(),
            self.quadratic_self_raw[relation_id].tanh(), self.quadratic_scale,
            self.quadratic_cross_weight, self.quadratic_self_weight)

    def ImplicitQuadraticTransERR(self, head, relation, tail, relation_id):
        wh, translation, wt = relation.chunk(3, -1)
        source, target = self._calc(head, self.q_norm(wh)), self._calc(tail, self.q_norm(wt))
        residual = source + translation - target
        correction = self.quadratic_endpoint_correction(source, target, relation_id)
        return self.gamma.item() - (residual + correction).norm(p=1, dim=-1)

    def bures_endpoint_states(self, head, relation, tail, relation_id):
        wh, head_offset, wt = relation.chunk(3, -1)
        stretch = self.bures_stretch_bound * self.bures_stretch_raw[relation_id].tanh()
        common = dict(scale=self.bures_scale, diagonal_floor=self.bures_diagonal_floor,
                      jitter=self.bures_jitter)
        source = affine_state(head, self.q_norm(wh), stretch[:, 0].unsqueeze(1), head_offset, **common)
        target = affine_state(tail, self.q_norm(wt), stretch[:, 1].unsqueeze(1),
                              self.bures_tail_offset[relation_id].unsqueeze(1), **common)
        return source, target

    def bures_pair_distance(self, head, relation, tail, relation_id):
        source, target = self.bures_endpoint_states(head, relation, tail, relation_id)
        return bures_distance(source, target, self.bures_smoothing * self.bures_scale)

    @torch.no_grad()
    def calibrate_bures_scale(self):
        count = min(self.nentity, 128)
        ids = torch.arange(count, device=self.entity_embedding.device) * self.nentity // count
        rid = torch.arange(count, device=ids.device) % self.nrelation
        head = self.entity_embedding[ids].unsqueeze(1)
        tail = self.entity_embedding[ids.roll(1)].unsqueeze(1)
        relation = self.relation_embedding[rid].unsqueeze(1)
        wh, translation, wt = relation.chunk(3, -1)
        reference = (self._calc(head, self.q_norm(wh)) + translation -
                     self._calc(tail, self.q_norm(wt))).norm(p=1, dim=-1).mean()
        distance = self.bures_pair_distance(head, relation, tail, rid).mean()
        self.bures_calibration_distances.copy_(torch.stack((reference, distance)))
        if self.bures_distance_scale.item() == 0:
            ratio = reference / distance
            if not torch.isfinite(ratio) or ratio <= 0:
                raise ValueError('Bures initialization produced an invalid calibration scale')
            self.bures_distance_scale.copy_(ratio)

    def BuresTransERR(self, head, relation, tail, relation_id):
        candidates = max(head.size(1), tail.size(1))
        chunk = max(1, self.bures_pair_chunk // head.size(0))
        distances = []
        for start in range(0, candidates, chunk):
            h = head[:, start:start + chunk] if head.size(1) > 1 else head
            t = tail[:, start:start + chunk] if tail.size(1) > 1 else tail
            if torch.is_grad_enabled():
                distance = activation_checkpoint(self.bures_pair_distance, h, relation, t, relation_id,
                                                 use_reentrant=False, preserve_rng_state=False)
            else:
                distance = self.bures_pair_distance(h, relation, t, relation_id)
            distances.append(distance)
        return self.gamma.item() - self.bures_distance_scale * torch.cat(distances, dim=1)

    def effective_region_width(self):
        return self.region_width_bound * torch.sigmoid(self.region_width_logits)

    def RegionTransERR(self, head, relation, tail, relation_id):
        if self.region_width_bound == 0:
            return self.TransERR(head, relation, tail, 'single')
        wh, translation, wt = torch.chunk(relation, 3, dim=2)
        residual = self._calc(head, self.q_norm(wh)) + translation - self._calc(tail, self.q_norm(wt))
        width = self.effective_region_width()[relation_id].unsqueeze(1)
        return self.gamma.item() - region_distance(residual, width, self.region_inner_weight)

    def DoubleCenterTransERR(self, head, relation, tail, relation_id):
        if getattr(self, 'double_center_warmup_active', False):
            return self.TransERR(head, relation, tail, 'single')
        wh, translation, wt = torch.chunk(relation, 3, dim=2)
        residual = (self._calc(head, self.q_norm(wh)) + translation
                    - self._calc(tail, self.q_norm(wt)))
        offset = self.center_offset.index_select(0, relation_id).unsqueeze(1)
        distance = grouped_double_center_distance(
            residual, offset, self.double_center_temperature, self.double_center_groups)
        return self.gamma.item() - distance

    def BiquaternionTransERR(self, head, relation, tail, mode):
        """Original TransERR score with complexified-quaternion products."""
        wh, translation, wt = torch.chunk(relation, 3, dim=2)
        wh = normalize_biquaternion(wh)
        wt = normalize_biquaternion(wt)
        residual = (
            biquaternion_product(head, wh)
            + translation
            - biquaternion_product(tail, wt)
        )
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def biquaternion_fusion_weight(self, relation_id):
        raw = torch.index_select(
            self.biquaternion_fusion_raw, dim=0, index=relation_id
        )
        return self.biquaternion_fusion_bound * torch.tanh(raw)

    def AdaptiveBiquaternionFusionTransERR(
            self, head, relation, tail, relation_id, mode):
        """Apply a bounded relation-wise Biquaternion score residual."""
        quaternion_score = self.TransERR(head, relation, tail, mode)
        biquaternion_score = self.BiquaternionTransERR(
            head, relation, tail, mode
        )
        weight = self.biquaternion_fusion_weight(relation_id)
        return quaternion_score + weight * (
            biquaternion_score - quaternion_score
        )

    def convex_biquaternion_fusion_weight(self, relation_id):
        raw = torch.index_select(
            self.biquaternion_fusion_raw, dim=0, index=relation_id
        )
        return self.biquaternion_fusion_bound * torch.sigmoid(raw)

    def ConvexBiquaternionFusionTransERR(
            self, head, relation, tail, relation_id, mode):
        """Convexly interpolate TransERR and Biquaternion scores."""
        quaternion_score = self.TransERR(head, relation, tail, mode)
        biquaternion_score = self.BiquaternionTransERR(
            head, relation, tail, mode
        )
        weight = self.convex_biquaternion_fusion_weight(relation_id)
        return quaternion_score + weight * (
            biquaternion_score - quaternion_score
        )

    def effective_clifford_signature(self):
        """Return each relation's Cl(diag(-1, s_r)) metric value."""
        return -1.0 + self.clifford_signature_delta

    def AdaptiveMetricCliffordTransERR(
            self, head, relation, tail, relation_id, mode):
        """Apply one learned Clifford signature to both relation frames."""
        wh, translation, wt = torch.chunk(relation, 3, dim=2)
        wh = normalize_quaternion(wh)
        wt = normalize_quaternion(wt)
        signature = torch.index_select(
            self.effective_clifford_signature(), 0, relation_id
        ).unsqueeze(1)
        transformed_head = adaptive_metric_clifford_product(
            head, wh, signature
        )
        transformed_tail = adaptive_metric_clifford_product(
            tail, wt, signature
        )
        residual = transformed_head + translation - transformed_tail
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def RealMatrix2TransERR(self, head, relation, tail, mode):
        """TransERR with blockwise 2x2 real matrix multiplication."""
        wh, translation, wt = torch.chunk(relation, 3, dim=2)
        transformed_head = real_matrix2_product(
            head, normalize_real_matrix2(wh)
        )
        transformed_tail = real_matrix2_product(
            tail, normalize_real_matrix2(wt)
        )
        residual = transformed_head + translation - transformed_tail
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def ComplexMatrix2TransERR(self, head, relation, tail, mode):
        """TransERR with blockwise 2x2 complex matrix multiplication."""
        wh, translation, wt = torch.chunk(relation, 3, dim=2)
        transformed_head = complex_matrix2_product(
            head, normalize_complex_matrix2(wh)
        )
        transformed_tail = complex_matrix2_product(
            tail, normalize_complex_matrix2(wt)
        )
        residual = transformed_head + translation - transformed_tail
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def MidpointCartanComplexTransERR(self, head, relation, tail, mode):
        """Score with a bounded complex frame and its analytic inverse."""
        raw_frame, translation = torch.chunk(relation, 2, dim=2)
        frame, inverse_frame = midpoint_cartan_frames(
            raw_frame,
            self.embedding_range,
            self.cartan_stretch_bound,
        )
        transformed_head = complex_matrix2_product(head, frame)
        transformed_tail = complex_matrix2_product(tail, inverse_frame)
        residual = transformed_head + translation - transformed_tail
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def ResidualKroneckerComplexMatrix2TransERR(
            self, head, relation, tail, relation_id, mode):
        """Mix one-sided and two-sided complex matrix relation actions."""
        wh, translation, wt = torch.chunk(relation, 3, dim=2)
        left = self.kronecker_left_embedding.index_select(0, relation_id)
        logits = self.kronecker_branch_logits.index_select(0, relation_id)
        transformed_head = residual_kronecker_complex_matrix2(
            head, wh, left[:, 0].unsqueeze(1), logits[:, 0],
            self.kronecker_identity_floor
        )
        transformed_tail = residual_kronecker_complex_matrix2(
            tail, wt, left[:, 1].unsqueeze(1), logits[:, 1],
            self.kronecker_identity_floor
        )
        residual = transformed_head + translation - transformed_tail
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def HouseholderShearTransERR(
            self, head, relation, tail, relation_id, mode):
        """TransERR with invertible double-reflection shear frames."""
        wh, translation, wt = torch.chunk(relation, 3, dim=2)
        second_axes = self.householder_second_axis_embedding.index_select(
            0, relation_id
        )
        shear = self.householder_shear_bound * torch.tanh(
            self.householder_shear_raw.index_select(0, relation_id)
        )
        transformed_head = apply_householder_shear(
            head, wh, second_axes[:, 0].unsqueeze(1), shear[:, 0],
            self.householder_group_dim
        )
        transformed_tail = apply_householder_shear(
            tail, wt, second_axes[:, 1].unsqueeze(1), shear[:, 1],
            self.householder_group_dim
        )
        residual = transformed_head + translation - transformed_tail
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def _port_effective_parameters(self, relation_id=None):
        """Return bounded physical parameters, optionally for a batch."""
        skew_raw = self.port_skew_embedding
        damping_raw = self.port_damping_embedding
        nonlinear_raw = self.port_nonlinear_embedding
        log_scale_raw = getattr(
            self, 'port_log_scale_embedding', None
        )
        if relation_id is not None:
            skew_raw = skew_raw.index_select(0, relation_id)
            damping_raw = damping_raw.index_select(0, relation_id)
            nonlinear_raw = nonlinear_raw.index_select(0, relation_id)
            if log_scale_raw is not None:
                log_scale_raw = log_scale_raw.index_select(0, relation_id)

        if self.model_name == 'CayleyPortHamiltonianTransERR':
            # Cayley(J) is stable for every skew J, so this variant does not
            # need the gradient-saturating hard tanh bound.
            skew = self.port_rotation_bound * skew_raw
        else:
            skew = self.port_rotation_bound * torch.tanh(skew_raw)
        damping = self.port_damping_bound * torch.sigmoid(damping_raw)
        nonlinear = self.port_nonlinear_bound * torch.tanh(nonlinear_raw)
        log_scale = None
        if log_scale_raw is not None:
            log_scale = (
                self.port_log_scale_bound * torch.tanh(log_scale_raw)
            )
        return skew, damping, nonlinear, log_scale

    def PortHamiltonianTransERR(
            self, head, relation, tail, relation_id, mode):
        """Apply dissipative Hamiltonian dynamics in TransERR coordinates."""
        wh, translation, wt = torch.chunk(relation, 3, dim=2)
        source = self._calc(head, self.q_norm(wh))
        target = self._calc(tail, self.q_norm(wt))
        if self.model_name == 'CayleyPortHamiltonianTransERR':
            unique_relation, relation_index = torch.unique(
                relation_id, sorted=False, return_inverse=True
            )
            skew, damping, nonlinear, log_scale = (
                self._port_effective_parameters(unique_relation)
            )
            flowed_source = cayley_split_port_hamiltonian_flow(
                source,
                skew,
                damping,
                nonlinear,
                self.port_block_dim,
                self.port_steps,
                relation_index=relation_index,
            )
        else:
            skew, damping, nonlinear, log_scale = (
                self._port_effective_parameters(relation_id)
            )
            flowed_source = port_hamiltonian_flow(
                source,
                skew,
                damping,
                nonlinear,
                self.port_block_dim,
                self.port_steps,
            )
        predicted_target = flowed_source + translation
        residual = predicted_target - target
        if log_scale is not None:
            distance = laplace_endpoint_distance(residual, log_scale)
        else:
            distance = torch.norm(residual, p=1, dim=2)
        return self.gamma.item() - distance

    def port_parameter_regularization(self):
        """Regularize effective values rather than damping logits."""
        skew, damping, nonlinear, log_scale = (
            self._port_effective_parameters()
        )
        terms = [
            skew.pow(2).mean(),
            damping.pow(2).mean(),
            nonlinear.pow(2).mean(),
        ]
        if log_scale is not None:
            terms.append(log_scale.pow(2).mean())
        return torch.stack(terms).mean()

    def RelationEntityBiasTransERR(
            self, head, relation, tail, relation_id, sample, mode):
        """Add relation-specific domain and range priors to TransERR."""
        score = self.TransERR(head, relation, tail, mode)
        return score + self._relation_entity_bias(
            relation_id, sample, mode
        )

    def _relation_entity_bias(self, relation_id, sample, mode):
        if mode == 'single':
            head_id = sample[:, 0].unsqueeze(1)
            tail_id = sample[:, 2].unsqueeze(1)
        elif mode == 'head-batch':
            positive_sample, head_id = sample
            tail_id = positive_sample[:, 2].unsqueeze(1)
        elif mode == 'tail-batch':
            positive_sample, tail_id = sample
            head_id = positive_sample[:, 0].unsqueeze(1)
        else:
            raise ValueError('mode %s not supported' % mode)

        bound = self.relation_bias_bound
        relation_index = relation_id.unsqueeze(1)
        head_bias = bound * torch.tanh(
            self.head_entity_bias[relation_index, head_id]
        )
        tail_bias = bound * torch.tanh(
            self.tail_entity_bias[relation_index, tail_id]
        )
        return head_bias + tail_bias

    def DomainRangeProjectionTransERR(
            self, head, relation, tail, relation_id, mode):
        """Score relation domain/range compatibility in shared entity space."""
        score = self.TransERR(head, relation, tail, mode)
        return score + self._domain_range_projection(
            head, tail, relation_id
        )

    def _domain_range_projection(self, head, tail, relation_id):
        domain = self.domain_projection.index_select(
            0, relation_id
        ).unsqueeze(1)
        range_direction = self.range_projection.index_select(
            0, relation_id
        ).unsqueeze(1)
        head_feature = F.normalize(head, p=2, dim=2, eps=1e-9)
        tail_feature = F.normalize(tail, p=2, dim=2, eps=1e-9)
        bound = self.relation_bias_bound
        domain_score = bound * torch.tanh(torch.sum(
            head_feature * domain, dim=2
        ))
        range_score = bound * torch.tanh(torch.sum(
            tail_feature * range_direction, dim=2
        ))
        return domain_score + range_score

    def RelativeQuaternionTransERR(self, head, relation, tail, mode):
        """Parameterize tail orientation relative to a shared base frame."""
        return score_relative_quaternion(
            head, relation, tail, self.gamma.item()
        )

    def update_rank_defect_progress(self, step):
        """Persist the deterministic local-global continuation schedule."""
        if self.model_name not in _RANK_DEFECT_LOCAL_GLOBAL_MODELS:
            return
        step = int(step)
        progress = (
            (step - self.rank_defect_start_step)
            / float(self.rank_defect_ramp_steps)
        )
        self.rank_defect_progress.fill_(
            min(max(progress, 0.0), 1.0)
        )

    def _rank_defect_endpoint_parameters(self, relation_id, endpoint_role):
        """Select one endpoint's tied geometry for a relation batch."""
        def select(parameter):
            return parameter.index_select(0, relation_id)[:, endpoint_role]

        return {
            'defect_left_basis': select(self.rank_defect_left_basis),
            'defect_right_basis': select(self.rank_defect_right_basis),
            'defect_ranks': self.relation_defect_ranks.index_select(
                0, relation_id
            )[:, endpoint_role],
            'rotation_left_basis': select(self.local_global_left_basis),
            'rotation_left_generator': select(
                self.local_global_left_generator
            ),
            'rotation_right_basis': select(self.local_global_right_basis),
            'rotation_right_generator': select(
                self.local_global_right_generator
            ),
        }

    def _rank_defect_local_global_transform(
            self, value, relation_id, endpoint_role):
        parameters = self._rank_defect_endpoint_parameters(
            relation_id, endpoint_role
        )
        return local_global_rank_defect_transform(
            value,
            self.rank_defect_rows,
            **parameters,
            cayley_bound=self.rank_defect_cayley_bound,
            progress=self.rank_defect_progress,
        )

    def RankDefectLocalGlobalRelativeQuaternionTransERR(
            self, head, relation, tail, relation_id,
            inverse_direction=False):
        """Extend v73 with global Cayley mixing and cardinality rank defect."""
        if self.rank_defect_progress.item() == 0.0:
            return score_relative_quaternion(
                head, relation, tail, self.gamma.item()
            )
        source_frame, translation, _, target_frame = (
            relative_relation_frames(relation)
        )
        source_role = 1 if inverse_direction else 0
        target_role = 0 if inverse_direction else 1
        transformed_head = self._rank_defect_local_global_transform(
            hamilton_product(head, source_frame),
            relation_id,
            source_role,
        )
        transformed_tail = self._rank_defect_local_global_transform(
            hamilton_product(tail, target_frame),
            relation_id,
            target_role,
        )
        residual = transformed_head + translation - transformed_tail
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def rank_defect_geometry_regularization(self):
        """Penalize only effective rotations; projector norms are invariant."""
        left = (
            self.local_global_left_generator
            - self.local_global_left_generator.transpose(-1, -2)
        )
        right = (
            self.local_global_right_generator
            - self.local_global_right_generator.transpose(-1, -2)
        )
        progress = self.rank_defect_progress.to(left.dtype)
        return progress.square() * (
            torch.tanh(left).square().mean()
            + torch.tanh(right).square().mean()
        ) / 2.0

    def _polar_deform(self, value, relation_id, endpoint_role):
        """Apply a bounded low-rank symmetric positive deformation."""
        direction = self.polar_direction.index_select(
            0, relation_id
        )[:, endpoint_role]
        direction = F.normalize(direction, p=2, dim=-1, eps=1e-9)
        coefficient = torch.tanh(self.polar_coefficient.index_select(
            0, relation_id
        )[:, endpoint_role])
        projection = torch.einsum('bnd,brd->bnr', value, direction)
        delta = torch.einsum(
            'bnr,brd->bnd', projection * coefficient.unsqueeze(1), direction
        )
        return value + (self.polar_bound / self.polar_rank) * delta

    def PolarRelativeQuaternionTransERR(
            self, head, relation, tail, relation_id, inverse_direction=False):
        """Compose v73 quaternion frames with low-rank polar deformation."""
        source_frame, translation, _, target_frame = (
            relative_relation_frames(relation)
        )
        source_role = 1 if inverse_direction else 0
        target_role = 0 if inverse_direction else 1
        transformed_head = self._calc(
            self._polar_deform(head, relation_id, source_role),
            source_frame,
        )
        transformed_tail = self._calc(
            self._polar_deform(tail, relation_id, target_role),
            target_frame,
        )
        residual = transformed_head + translation - transformed_tail
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def _flow_coupling_parameters(
            self, relation_id, endpoint_role, layer, conditioner):
        down = self.flow_down.index_select(
            0, relation_id
        )[:, endpoint_role, layer]
        scale_up = self.flow_scale_up.index_select(
            0, relation_id
        )[:, endpoint_role, layer]
        shift_up = self.flow_shift_up.index_select(
            0, relation_id
        )[:, endpoint_role, layer]
        hidden = torch.tanh(torch.einsum(
            'bnd,brd->bnr', conditioner, down
        ))
        normalizer = math.sqrt(float(self.flow_rank))
        log_scale = self.flow_scale_bound * torch.tanh(
            torch.einsum('bnr,bdr->bnd', hidden, scale_up) / normalizer
        )
        shift = self.flow_shift_bound * torch.tanh(
            torch.einsum('bnr,bdr->bnd', hidden, shift_up) / normalizer
        )
        return log_scale, shift

    def _flow_deform(
            self, value, relation_id, endpoint_role, inverse=False):
        """Apply or invert a two-layer relation-conditioned affine flow."""
        if not inverse:
            for layer in range(2):
                conditioner, transformed = torch.chunk(value, 2, dim=2)
                log_scale, shift = self._flow_coupling_parameters(
                    relation_id, endpoint_role, layer, conditioner
                )
                transformed = transformed * torch.exp(log_scale) + shift
                value = torch.cat([transformed, conditioner], dim=2)
            return value

        for layer in reversed(range(2)):
            transformed, conditioner = torch.chunk(value, 2, dim=2)
            log_scale, shift = self._flow_coupling_parameters(
                relation_id, endpoint_role, layer, conditioner
            )
            original = (transformed - shift) * torch.exp(-log_scale)
            value = torch.cat([conditioner, original], dim=2)
        return value

    def FlowRelativeQuaternionTransERR(
            self, head, relation, tail, relation_id, inverse_direction=False):
        """Compose v73 quaternion frames with an invertible nonlinear flow."""
        source_frame, translation, _, target_frame = (
            relative_relation_frames(relation)
        )
        source_role = 1 if inverse_direction else 0
        target_role = 0 if inverse_direction else 1
        transformed_head = self._calc(
            self._flow_deform(head, relation_id, source_role),
            source_frame,
        )
        transformed_tail = self._calc(
            self._flow_deform(tail, relation_id, target_role),
            target_frame,
        )
        residual = transformed_head + translation - transformed_tail
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def ConjugateGatedRelativeQuaternionTransERR(
            self, head, relation, tail, relation_id, inverse_conjugate=False):
        """Blend v73's right action with a tied quaternion conjugate action."""
        source_frame, translation, _, target_frame = (
            relative_relation_frames(relation)
        )
        gate = 0.25 * torch.tanh(self.conjugate_gate.index_select(
            0, relation_id
        )).unsqueeze(1).repeat_interleave(4, dim=2)

        def transform(value, frame):
            right_action = self._calc(value, frame)
            if inverse_conjugate:
                conjugate_action = self._calc(
                    self._calc(frame, value), self.q_conjugate(frame)
                )
            else:
                conjugate_action = self._calc(
                    self._calc(self.q_conjugate(frame), value), frame
                )
            return right_action + gate * (conjugate_action - right_action)

        residual = (
            transform(head, source_frame) + translation
            - transform(tail, target_frame)
        )
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def BilinearResidualRelativeQuaternionTransERR(
            self, head, relation, tail, relation_id):
        """Add bounded relation-aware endpoint compatibility to v73."""
        source_frame, translation, _, target_frame = (
            relative_relation_frames(relation)
        )
        transformed_head = self._calc(head, source_frame)
        transformed_tail = self._calc(tail, target_frame)
        base_score = self.gamma.item() - torch.norm(
            transformed_head + translation - transformed_tail, p=1, dim=2
        )
        weight = 0.25 * torch.tanh(
            self.bilinear_residual_embedding.index_select(0, relation_id)
        ).unsqueeze(1)
        compatibility = torch.sum(
            F.normalize(transformed_head, p=2, dim=2, eps=1e-9)
            * weight
            * F.normalize(transformed_tail, p=2, dim=2, eps=1e-9),
            dim=2
        )
        return base_score + compatibility

    def RelationMetricRelativeQuaternionTransERR(
            self, head, relation, tail, relation_id):
        """Evaluate v73 residuals in a relation-specific local metric."""
        source_frame, translation, _, target_frame = (
            relative_relation_frames(relation)
        )
        residual = (
            self._calc(head, source_frame) + translation
            - self._calc(tail, target_frame)
        )
        raw_metric = self.residual_metric_embedding.index_select(
            0, relation_id
        )
        lower = 0.1 * torch.tanh(torch.tril(raw_metric, diagonal=-1))
        diagonal = torch.exp(0.1 * torch.tanh(torch.diagonal(
            raw_metric, dim1=1, dim2=2
        )))
        metric = lower + torch.diag_embed(diagonal)
        grouped = residual.view(
            residual.size(0), residual.size(1), -1, 4
        )
        transformed = torch.einsum('bij,bngj->bngi', metric, grouped)
        return self.gamma.item() - transformed.reshape(
            transformed.size(0), transformed.size(1), -1
        ).abs().sum(dim=2)

    def HamiltonCompatibilityRelativeQuaternionTransERR(
            self, head, relation, tail, relation_id):
        """Add a bounded quaternion-product compatibility to the v73 score."""
        source_frame, translation, _, target_frame = (
            relative_relation_frames(relation)
        )
        transformed_head = self._calc(head, source_frame)
        transformed_tail = self._calc(tail, target_frame)
        residual = transformed_head + translation - transformed_tail
        base_score = self.gamma.item() - torch.norm(residual, p=1, dim=2)
        correlation = self._calc(
            self.q_conjugate(self.q_norm(transformed_head)),
            self.q_norm(transformed_tail)
        )
        weight = 0.1 * torch.tanh(
            self.hamilton_compatibility_embedding.index_select(0, relation_id)
        ).unsqueeze(1)
        return base_score + torch.sum(correlation * weight, dim=2)

    def ResidualEnergyRelativeQuaternionTransERR(
            self, head, relation, tail, relation_id):
        """Apply a relation-gated quadratic energy to the v73 residual."""
        source_frame, translation, _, target_frame = (
            relative_relation_frames(relation)
        )
        residual = (
            self._calc(head, source_frame) + translation
            - self._calc(tail, target_frame)
        )
        base_score = self.gamma.item() - torch.norm(residual, p=1, dim=2)
        grouped = residual.view(
            residual.size(0), residual.size(1), -1, 4
        )
        gate = 0.05 * torch.tanh(self.residual_energy_gate.index_select(
            0, relation_id
        )).unsqueeze(1).unsqueeze(1)
        correction = (grouped.square() * gate).sum(dim=3).mean(dim=2)
        return base_score + correction

    def TwoSidedRelativeQuaternionTransERR(
            self, head, relation, tail, relation_id, inverse_direction):
        """Use a bounded left quaternion action in addition to v73 frames."""
        source_frame, translation, _, target_frame = (
            relative_relation_frames(relation)
        )
        raw_left = self.two_sided_left_raw.index_select(
            0, relation_id
        ).unsqueeze(1)
        identity = torch.zeros_like(raw_left)
        identity[..., :raw_left.size(2) // 4] = 1.0
        left = identity + 0.05 * torch.tanh(raw_left)
        if inverse_direction:
            left = quaternion_conjugate(left)
        residual = (
            self._calc(head, source_frame) + translation
            - self._calc(tail, target_frame)
        )
        residual = residual + self._calc(left - identity, residual)
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def AdaptiveMomentRelativeQuaternionTransERR(
            self, head, relation, tail, relation_id):
        """Blend relation/group-specific variance and extremal corrections."""
        source_frame, translation, _, target_frame = relative_relation_frames(relation)
        residual = torch.abs(
            self._calc(head, source_frame) + translation
            - self._calc(tail, target_frame)
        )
        group_size = self.mean_variance_group_size
        group_count = self.adaptive_variance_gate.size(1)
        pad = group_count * group_size - residual.size(2)
        grouped = F.pad(residual, (0, pad)).view(
            residual.size(0), residual.size(1), group_count, group_size
        )
        mean = grouped.mean(dim=3)
        variance = grouped.var(dim=3, unbiased=False)
        extremal = grouped.amax(dim=3) - mean
        variance_gate = 0.1 * torch.tanh(
            self.adaptive_variance_gate.index_select(0, relation_id)
        ).unsqueeze(1)
        max_gate = 0.1 * torch.tanh(
            self.adaptive_max_gate.index_select(0, relation_id)
        ).unsqueeze(1)
        base_score = self.gamma.item() - torch.norm(residual, p=1, dim=2)
        correction = -group_size * (
            variance_gate * variance / self.mean_variance_temperature
            + max_gate * extremal
        ).sum(dim=2)
        return base_score + correction

    def _block_transport_angles(self, relation_id, inverse_direction):
        angles = self.block_transport_angle.index_select(0, relation_id)
        if inverse_direction:
            return -angles[:, 1], -angles[:, 0]
        return angles[:, 0], angles[:, 1]

    def _apply_block_quaternion_transport(self, value, angle):
        """Apply an SO(2) transport between adjacent quaternion blocks."""
        components = torch.stack(torch.chunk(value, 4, dim=2), dim=3)
        batch_size, candidate_count, block_count, _ = components.shape
        pairs = components.view(
            batch_size, candidate_count, block_count // 2, 2, 4
        )
        angle = (
            self.quaternion_operator_bound * torch.tanh(angle)
        ).unsqueeze(1).unsqueeze(3)
        cosine = torch.cos(angle)
        sine = torch.sin(angle)
        first = cosine * pairs[:, :, :, 0] + sine * pairs[:, :, :, 1]
        second = -sine * pairs[:, :, :, 0] + cosine * pairs[:, :, :, 1]
        transported = torch.stack([first, second], dim=3).reshape(
            batch_size, candidate_count, block_count, 4
        )
        return torch.cat([
            transported[:, :, :, component]
            for component in range(4)
        ], dim=2)

    def BlockQuaternionTransportRelativeQuaternionTransERR(
            self, head, relation, tail, relation_id, inverse_direction):
        """Extend v73 with inverse-paired local quaternion-block transport."""
        source_frame, translation, _, target_frame = (
            relative_relation_frames(relation)
        )
        source_angle, target_angle = self._block_transport_angles(
            relation_id, inverse_direction
        )
        transformed_head = self._apply_block_quaternion_transport(
            self._calc(head, source_frame), source_angle
        )
        transformed_tail = self._apply_block_quaternion_transport(
            self._calc(tail, target_frame), target_angle
        )
        residual = transformed_head + translation - transformed_tail
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def _apply_interleaved_block_transport(self, value, angles, reverse):
        """Apply two interleaved cyclic Givens layers to quaternion blocks."""
        components = torch.stack(torch.chunk(value, 4, dim=2), dim=3)
        batch_size, candidate_count, block_count, _ = components.shape
        layer_order = (1, 0) if reverse else (0, 1)
        result = components
        for layer in layer_order:
            angle = angles[:, layer]
            if reverse:
                angle = -angle
            angle = self.quaternion_operator_bound * torch.tanh(angle)
            left_index = torch.arange(
                layer, block_count, 2, device=value.device
            )
            right_index = (left_index + 1) % block_count
            left = result.index_select(2, left_index)
            right = result.index_select(2, right_index)
            cosine = torch.cos(angle).unsqueeze(1).unsqueeze(3)
            sine = torch.sin(angle).unsqueeze(1).unsqueeze(3)
            updated_left = cosine * left + sine * right
            updated_right = -sine * left + cosine * right
            next_result = result.clone()
            next_result[:, :, left_index] = updated_left
            next_result[:, :, right_index] = updated_right
            result = next_result
        return torch.cat([
            result[:, :, :, component] for component in range(4)
        ], dim=2)

    def InterleavedBlockQuaternionTransportRelativeQuaternionTransERR(
            self, head, relation, tail, relation_id, inverse_direction):
        """Use an inverse-paired two-layer cyclic block transport after v73."""
        source_frame, translation, _, target_frame = relative_relation_frames(relation)
        angles = self.interleaved_block_transport_angle.index_select(
            0, relation_id
        )
        if inverse_direction:
            head_angles, tail_angles = angles[:, 1], angles[:, 0]
        else:
            head_angles, tail_angles = angles[:, 0], angles[:, 1]
        transformed_head = self._apply_interleaved_block_transport(
            self._calc(head, source_frame), head_angles, inverse_direction
        )
        transformed_tail = self._apply_interleaved_block_transport(
            self._calc(tail, target_frame), tail_angles, inverse_direction
        )
        residual = transformed_head + translation - transformed_tail
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def _rank_quaternion_operator_parameters(
            self, relation_id, inverse_direction, side):
        direction = 1 if inverse_direction else 0
        left = self.quaternion_operator_left.index_select(
            0, relation_id
        )[:, direction, side].unsqueeze(1)
        right = self.quaternion_operator_right.index_select(
            0, relation_id
        )[:, direction, side].unsqueeze(1)
        coefficient = self.quaternion_operator_coefficient.index_select(
            0, relation_id
        )[:, direction, side].unsqueeze(1)
        return left, right, coefficient

    def RankQuaternionOperatorTransERR(
            self, head, relation, tail, relation_id,
            inverse_direction):
        """Replace each Hamilton action with a rank-K quaternion map."""
        source_frame, translation, _, target_frame = (
            relative_relation_frames(relation)
        )
        head_parameters = self._rank_quaternion_operator_parameters(
            relation_id, inverse_direction, side=0
        )
        tail_parameters = self._rank_quaternion_operator_parameters(
            relation_id, inverse_direction, side=1
        )
        transform = rank_quaternion_transform
        if self.model_name in _GEODESIC_RANK_QUATERNION_MODELS:
            transform = geodesic_rank_quaternion_transform
        transformed_head = transform(
            head,
            source_frame,
            *head_parameters,
            self.quaternion_operator_bound,
        )
        transformed_tail = transform(
            tail,
            target_frame,
            *tail_parameters,
            self.quaternion_operator_bound,
        )
        residual = transformed_head + translation - transformed_tail
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def CayleyResidualRelativeQuaternionTransERR(
            self, head, relation, tail, relation_id, inverse_direction):
        """Add an inverse-paired SO(4) correction to the v73 base frames."""
        source_frame, translation, _, target_frame = (
            relative_relation_frames(relation)
        )
        direct_head = hamilton_product(head, source_frame)
        direct_tail = hamilton_product(tail, target_frame)

        unique_relation_id, inverse = torch.unique(
            relation_id, sorted=False, return_inverse=True
        )
        raw_generator = self.cayley_residual_embedding.index_select(
            0, unique_relation_id
        ).unsqueeze(1)
        if self.model_name.startswith('FullCayley'):
            coefficients = full_plane_coefficients(
                raw_generator, self.embedding_range
            )
        else:
            coefficients = rank2_plane_coefficients(raw_generator)

        gate = self._cayley_residual_effective_gate().index_select(
            0, unique_relation_id
        ).unsqueeze(1)
        if inverse_direction:
            gate = -gate
        base_generator, extra_generator = pack_cayley_generator(
            coefficients, self.embedding_range, gate
        )
        head_matrix = self._cayley_matrix(
            0.5 * base_generator, 0.5 * extra_generator
        ).index_select(0, inverse)
        tail_matrix = self._cayley_matrix(
            -0.5 * base_generator, -0.5 * extra_generator
        ).index_select(0, inverse)

        residual = (
            self._apply_cayley_matrix(direct_head, head_matrix)
            + translation
            - self._apply_cayley_matrix(direct_tail, tail_matrix)
        )
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def _cayley_residual_effective_gate(self):
        gate = self.residual_so4_bound * torch.tanh(
            self.cayley_residual_gate
        )
        if (self.training
                and self.current_training_step
                < self.cayley_residual_start_step):
            gate = gate * 0.0
        return gate

    def SoftExtremalRelativeQuaternionTransERR(
            self, head, relation, tail, relation_id, mode):
        """Blend grouped L1 and soft-extremal residual distances."""
        base, translation, relative = torch.chunk(relation, 3, dim=2)
        wh = self.q_norm(base)
        relative = self.q_norm(relative)
        wt = self.q_norm(self._calc(wh, relative))
        residual = torch.abs(
            self._calc(head, wh) + translation
            - self._calc(tail, wt)
        )

        group_size = self.soft_extremal_group_size
        group_count = self.soft_extremal_gate.size(1)
        pad = group_count * group_size - residual.size(2)
        grouped = F.pad(residual, (0, pad)).view(
            residual.shape[:2] + (group_count, group_size)
        )
        mean_distance = grouped.mean(dim=3)
        temperature = self.soft_extremal_temperature
        soft_extremum = temperature * (
            torch.logsumexp(grouped / temperature, dim=3)
            - math.log(group_size)
        )
        gate = torch.sigmoid(torch.index_select(
            self.soft_extremal_gate, dim=0, index=relation_id
        )).unsqueeze(1)
        group_distance = group_size * (
            (1.0 - gate) * mean_distance + gate * soft_extremum
        )
        return self.gamma.item() - group_distance.sum(dim=2)

    def MaxMeanRelativeQuaternionTransERR(
            self, head, relation, tail, relation_id, mode):
        """Blend grouped L1 distance with decisive coordinate errors."""
        base, translation, relative = torch.chunk(relation, 3, dim=2)
        wh = self.q_norm(base)
        relative = self.q_norm(relative)
        wt = self.q_norm(self._calc(wh, relative))
        residual = torch.abs(
            self._calc(head, wh) + translation
            - self._calc(tail, wt)
        )

        group_size = self.max_mean_group_size
        group_count = self.max_mean_gate.size(1)
        pad = group_count * group_size - residual.size(2)
        grouped = F.pad(residual, (0, pad)).view(
            residual.shape[:2] + (group_count, group_size)
        )
        mean_distance = grouped.mean(dim=3)
        max_distance = grouped.amax(dim=3)
        gate = torch.sigmoid(torch.index_select(
            self.max_mean_gate, dim=0, index=relation_id
        )).unsqueeze(1)
        group_distance = group_size * (
            (1.0 - gate) * mean_distance + gate * max_distance
        )
        return self.gamma.item() - group_distance.sum(dim=2)

    def MeanVarianceRelativeQuaternionTransERR(
            self, head, relation, tail, relation_id, mode):
        """Use a second-order approximation of the soft-extremal metric."""
        base, translation, relative = torch.chunk(relation, 3, dim=2)
        wh = self.q_norm(base)
        relative = self.q_norm(relative)
        wt = self.q_norm(self._calc(wh, relative))
        residual = torch.abs(
            self._calc(head, wh) + translation
            - self._calc(tail, wt)
        )

        group_size = self.mean_variance_group_size
        group_count = self.mean_variance_gate.size(1)
        pad = group_count * group_size - residual.size(2)
        grouped = F.pad(residual, (0, pad)).view(
            residual.shape[:2] + (group_count, group_size)
        )
        mean_distance = grouped.mean(dim=3)
        variance = grouped.var(dim=3, unbiased=False)
        correction = variance / (
            2.0 * self.mean_variance_temperature
        )
        gate = torch.sigmoid(torch.index_select(
            self.mean_variance_gate, dim=0, index=relation_id
        )).unsqueeze(1)
        group_distance = group_size * (
            mean_distance + gate * correction
        )
        return self.gamma.item() - group_distance.sum(dim=2)

    def PMeanRelativeQuaternionTransERR(
            self, head, relation, tail, relation_id, mode):
        """Learn a relation/group-specific norm between L1 and L2."""
        base, translation, relative = torch.chunk(relation, 3, dim=2)
        wh = self.q_norm(base)
        relative = self.q_norm(relative)
        wt = self.q_norm(self._calc(wh, relative))
        residual = torch.abs(
            self._calc(head, wh) + translation
            - self._calc(tail, wt)
        )

        group_size = self.pmean_group_size
        group_count = self.pmean_exponent_raw.size(1)
        pad = group_count * group_size - residual.size(2)
        grouped = F.pad(residual, (0, pad)).view(
            residual.shape[:2] + (group_count, group_size)
        )
        exponent = 1.0 + self.pmean_exponent_bound * torch.sigmoid(
            torch.index_select(
                self.pmean_exponent_raw, dim=0, index=relation_id
            )
        ).unsqueeze(1)
        powered_mean = grouped.pow(
            exponent.unsqueeze(3)
        ).mean(dim=3).clamp_min(1e-12)
        group_distance = group_size * powered_mean.pow(
            exponent.reciprocal()
        )
        return self.gamma.item() - group_distance.sum(dim=2)

    def AdaptiveFrameTransERR(
            self, head, relation, tail, relation_id, mode):
        """Smoothly route each candidate across three affine frames."""
        base, translation, tail_or_relative = torch.chunk(
            relation, 3, dim=2
        )
        head_operator = self.q_norm(base)
        direct_tail_operator = self.q_norm(tail_or_relative)
        relative_tail_operator = self.q_norm(self._calc(
            head_operator, direct_tail_operator
        ))

        transformed_head = self._calc(head, head_operator)
        direct_tail = self._calc(tail, direct_tail_operator)
        relative_tail = self._calc(tail, relative_tail_operator)
        direct_residual = transformed_head + translation - direct_tail
        relative_residual = transformed_head + translation - relative_tail
        pretranslation_residual = (
            self._calc(head + translation, head_operator) - relative_tail
        )
        branch_scores = self.gamma.item() - torch.stack([
            torch.norm(direct_residual, p=1, dim=2),
            torch.norm(relative_residual, p=1, dim=2),
            torch.norm(pretranslation_residual, p=1, dim=2),
        ], dim=2)

        log_weights = torch.log(
            self.adaptive_frame_weights(relation_id).clamp_min(1e-12)
        ).unsqueeze(1)
        temperature = self.frame_temperature
        return temperature * torch.logsumexp(
            branch_scores / temperature + log_weights, dim=2
        )

    def adaptive_frame_weights(self, relation_id):
        weights = F.softmax(
            self.frame_router_logits.index_select(0, relation_id), dim=1
        )
        minimum = self.frame_min_weight
        if minimum != 0.0:
            weights = minimum + (1.0 - 3.0 * minimum) * weights
        return weights

    def BlockAdaptiveFrameTransERR(
            self, head, relation, tail, relation_id, mode):
        """Route each quaternion block across three affine frames."""
        base, translation, tail_or_relative = torch.chunk(
            relation, 3, dim=2
        )
        head_operator = self.q_norm(base)
        direct_tail_operator = self.q_norm(tail_or_relative)
        relative_tail_operator = self.q_norm(self._calc(
            head_operator, direct_tail_operator
        ))
        transformed_head = self._calc(head, head_operator)
        direct_tail = self._calc(tail, direct_tail_operator)
        relative_tail = self._calc(tail, relative_tail_operator)
        residuals = (
            transformed_head + translation - direct_tail,
            transformed_head + translation - relative_tail,
            self._calc(head + translation, head_operator) - relative_tail,
        )

        branch_block_distances = []
        for residual in residuals:
            branch_block_distances.append(sum(
                component.abs()
                for component in torch.chunk(residual, 4, dim=2)
            ))
        branch_block_distances = torch.stack(
            branch_block_distances, dim=3
        )
        log_weights = torch.log(
            self.block_adaptive_frame_weights(
                relation_id
            ).clamp_min(1e-12)
        ).unsqueeze(1)
        temperature = self.block_frame_temperature
        block_distance = -temperature * torch.logsumexp(
            -branch_block_distances / temperature + log_weights,
            dim=3
        )
        return self.gamma.item() - block_distance.sum(dim=2)

    def block_adaptive_frame_weights(self, relation_id):
        weights = F.softmax(
            self.block_frame_router_logits.index_select(
                0, relation_id
            ), dim=2
        )
        minimum = self.block_frame_min_weight
        if minimum != 0.0:
            weights = minimum + (1.0 - 3.0 * minimum) * weights
        return weights

    def SymmetricRelativeTransERR(self, head, relation, tail, mode):
        """Place head and tail operators symmetrically around a shared frame."""
        center, translation, half_delta = torch.chunk(relation, 3, dim=2)
        center = self.q_norm(center)
        half_delta = self.q_norm(half_delta)
        wh = self.q_norm(self._calc(
            center, self.q_conjugate(half_delta)
        ))
        wt = self.q_norm(self._calc(center, half_delta))
        residual = (
            self._calc(head, wh) + translation
            - self._calc(tail, wt)
        )
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def PreTranslationRelativeTransERR(self, head, relation, tail, mode):
        """Translate the head in its relation frame before orientation."""
        base, translation, relative = torch.chunk(relation, 3, dim=2)
        wh = self.q_norm(base)
        relative = self.q_norm(relative)
        wt = self.q_norm(self._calc(wh, relative))
        residual = (
            self._calc(head + translation, wh)
            - self._calc(tail, wt)
        )
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def BiRotorTransERR(
            self, head, relation, tail, relation_id, mode):
        """Apply a complete norm-preserving SO(4) action on each side."""
        head_right, translation, tail_right = torch.chunk(
            relation, 3, dim=2
        )
        left_relation = self.birotor_left_embedding.index_select(
            0, relation_id
        ).unsqueeze(1)
        head_left, tail_left = torch.chunk(left_relation, 2, dim=2)

        transformed_head = self._birotor_transform(
            head, self.q_norm(head_left), self.q_norm(head_right)
        )
        transformed_tail = self._birotor_transform(
            tail, self.q_norm(tail_left), self.q_norm(tail_right)
        )
        residual = transformed_head + translation - transformed_tail
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def _birotor_transform(self, value, left, right_action):
        # right_action stores conjugate(q_right), preserving compatibility
        # with TransERR's existing one-sided value * relation convention.
        return self._calc(self._calc(left, value), right_action)

    def LieGeodesicTransERR(self, head, relation, tail, mode):
        """Map symmetric relation generators to unit quaternions."""
        center, translation, delta = torch.chunk(relation, 3, dim=2)
        head_operator, _ = self._axis_angle_quaternion(center - delta)
        tail_operator, _ = self._axis_angle_quaternion(center + delta)
        residual = (
            self._calc(head, head_operator) + translation
            - self._calc(tail, tail_operator)
        )
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def _axis_angle_quaternion(self, generator):
        """Convert scalar-angle and vector-axis channels to unit quaternions."""
        raw_angle, raw_x, raw_y, raw_z = torch.chunk(
            generator, 4, dim=2
        )
        angle = self.lie_angle_bound * torch.tanh(
            raw_angle / self.embedding_range.clamp_min(1e-9)
        )
        axis_norm = torch.sqrt(
            raw_x.square() + raw_y.square() + raw_z.square()
        )
        safe_norm = axis_norm.clamp_min(1e-9)
        valid_axis = axis_norm > 1e-9
        axis_x = torch.where(
            valid_axis, raw_x / safe_norm, torch.ones_like(raw_x)
        )
        axis_y = torch.where(
            valid_axis, raw_y / safe_norm, torch.zeros_like(raw_y)
        )
        axis_z = torch.where(
            valid_axis, raw_z / safe_norm, torch.zeros_like(raw_z)
        )

        half_angle = 0.5 * angle
        sin_half = torch.sin(half_angle)
        quaternion = torch.cat([
            torch.cos(half_angle),
            axis_x * sin_half,
            axis_y * sin_half,
            axis_z * sin_half,
        ], dim=2)
        return quaternion, (axis_x, axis_y, axis_z)

    def CliffordRotorTransERR(self, head, relation, tail, mode):
        """Use associative Cl(3) even rotors over eight-component blocks."""
        raw_head_rotor, translation, raw_tail_rotor = torch.chunk(
            relation, 3, dim=2
        )
        head_rotor = self._clifford_rotor(raw_head_rotor)
        tail_rotor = self._clifford_rotor(raw_tail_rotor)
        transformed_head = self._clifford_rotor_action(head, head_rotor)
        transformed_tail = self._clifford_rotor_action(tail, tail_rotor)
        residual = transformed_head + translation - transformed_tail
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    @staticmethod
    def _clifford_rotor(raw_rotor):
        parts = torch.chunk(raw_rotor, 8, dim=2)
        coefficients = [
            parts[0] + parts[7],
            parts[1] + parts[6],
            parts[2] + parts[5],
            parts[3] + parts[4],
        ]
        denominator = torch.sqrt(sum(
            coefficient.square() for coefficient in coefficients
        )).clamp_min(1e-9)
        scalar, e12, e13, e23 = [
            coefficient / denominator for coefficient in coefficients
        ]
        zero = torch.zeros_like(scalar)
        # Bit-mask basis order: 1, e1, e2, e12, e3, e13, e23, e123.
        return torch.cat([
            scalar, zero, zero, e12, zero, e13, e23, zero
        ], dim=2)

    @staticmethod
    def _clifford_product(left, right):
        left_parts = torch.chunk(left, 8, dim=2)
        right_parts = torch.chunk(right, 8, dim=2)
        product_shape = left_parts[0] * right_parts[0]
        result = [torch.zeros_like(product_shape) for _ in range(8)]

        for left_mask in range(8):
            for right_mask in range(8):
                sign = 1.0
                for bit in range(3):
                    if left_mask & (1 << bit):
                        lower_right_bits = right_mask & ((1 << bit) - 1)
                        if bin(lower_right_bits).count('1') % 2:
                            sign = -sign
                output_mask = left_mask ^ right_mask
                result[output_mask] = (
                    result[output_mask]
                    + sign * left_parts[left_mask] * right_parts[right_mask]
                )
        return torch.cat(result, dim=2)

    @staticmethod
    def _clifford_reverse(value):
        reverse_signs = (1.0, 1.0, 1.0, -1.0,
                         1.0, -1.0, -1.0, -1.0)
        return torch.cat([
            sign * part
            for sign, part in zip(reverse_signs, torch.chunk(value, 8, dim=2))
        ], dim=2)

    def _clifford_rotor_action(self, value, rotor):
        return self._clifford_product(
            self._clifford_product(rotor, value),
            self._clifford_reverse(rotor)
        )

    def ScrewFrameTransERR(
            self, head, relation, tail, relation_id, mode):
        """Rotate around a shared axis and translate along that axis."""
        head_generator, translation, tail_generator = torch.chunk(
            relation, 3, dim=2
        )
        head_operator, head_axis = self._axis_angle_quaternion(
            head_generator
        )
        tail_operator, tail_axis = self._axis_angle_quaternion(
            tail_generator
        )
        transformed_head = self._rotate_quaternion_vectors(
            head, head_operator
        )
        transformed_tail = self._rotate_quaternion_vectors(
            tail, tail_operator
        )

        shared_axis = self._shared_screw_axis(head_axis, tail_axis)
        raw_distance = self.screw_distance_embedding.index_select(
            0, relation_id
        ).unsqueeze(1)
        axial_distance = self.screw_distance_bound * torch.tanh(raw_distance)
        scalar, offset_x, offset_y, offset_z = torch.chunk(
            translation, 4, dim=2
        )
        axis_x, axis_y, axis_z = shared_axis
        effective_translation = torch.cat([
            scalar,
            offset_x + axial_distance * axis_x,
            offset_y + axial_distance * axis_y,
            offset_z + axial_distance * axis_z,
        ], dim=2)
        residual = (
            transformed_head + effective_translation - transformed_tail
        )
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def _rotate_quaternion_vectors(self, value, operator):
        scalar, x, y, z = torch.chunk(value, 4, dim=2)
        pure_vector = torch.cat([
            torch.zeros_like(scalar), x, y, z
        ], dim=2)
        rotated = self._calc(
            self._calc(operator, pure_vector),
            self.q_conjugate(operator)
        )
        _, rotated_x, rotated_y, rotated_z = torch.chunk(
            rotated, 4, dim=2
        )
        return torch.cat([
            scalar, rotated_x, rotated_y, rotated_z
        ], dim=2)

    @staticmethod
    def _shared_screw_axis(head_axis, tail_axis):
        dot_product = sum(
            head_component * tail_component
            for head_component, tail_component in zip(head_axis, tail_axis)
        )
        alignment = torch.where(
            dot_product < 0.0,
            -torch.ones_like(dot_product),
            torch.ones_like(dot_product)
        )
        candidate = [
            head_component + alignment * tail_component
            for head_component, tail_component in zip(head_axis, tail_axis)
        ]
        candidate_norm = torch.sqrt(sum(
            component.square() for component in candidate
        ))
        safe_norm = candidate_norm.clamp_min(1e-9)
        valid_candidate = candidate_norm > 1e-9
        return tuple(
            torch.where(
                valid_candidate,
                component / safe_norm,
                head_component
            )
            for component, head_component in zip(candidate, head_axis)
        )

    def CayleyOrthogonalTransERR(
            self, head, relation, tail, relation_id, mode):
        """Apply exact blockwise orthogonal maps from skew generators."""
        _, translation, _ = torch.chunk(
            relation, 3, dim=2
        )

        # A training batch repeats the same small relation vocabulary many
        # times. Solve each relation's block matrices once, then gather them
        # back to samples instead of repeating thousands of identical solves.
        unique_relation_id, inverse = torch.unique(
            relation_id, sorted=False, return_inverse=True
        )
        unique_relation = self.relation_embedding.index_select(
            0, unique_relation_id
        ).unsqueeze(1)
        head_generator, _, tail_generator = torch.chunk(
            unique_relation, 3, dim=2
        )
        unique_extra = self.cayley_extra_embedding.index_select(
            0, unique_relation_id
        ).unsqueeze(1)
        head_extra, tail_extra = torch.chunk(unique_extra, 2, dim=2)
        head_matrix = self._cayley_matrix(
            head_generator, head_extra
        ).index_select(0, inverse)
        tail_matrix = self._cayley_matrix(
            tail_generator, tail_extra
        ).index_select(0, inverse)
        transformed_head = self._apply_cayley_matrix(head, head_matrix)
        transformed_tail = self._apply_cayley_matrix(tail, tail_matrix)
        residual = transformed_head + translation - transformed_tail
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def CayleyFrameFusionTransERR(
            self, head, relation, tail, relation_id, mode):
        """Fuse direct quaternion and general orthogonal frame scores."""
        head_generator, translation, tail_generator = torch.chunk(
            relation, 3, dim=2
        )
        direct_residual = (
            self._calc(head, self.q_norm(head_generator)) + translation
            - self._calc(tail, self.q_norm(tail_generator))
        )

        unique_relation_id, inverse = torch.unique(
            relation_id, sorted=False, return_inverse=True
        )
        unique_relation = self.relation_embedding.index_select(
            0, unique_relation_id
        ).unsqueeze(1)
        unique_head, _, unique_tail = torch.chunk(
            unique_relation, 3, dim=2
        )
        unique_extra = self.cayley_extra_embedding.index_select(
            0, unique_relation_id
        ).unsqueeze(1)
        head_extra, tail_extra = torch.chunk(unique_extra, 2, dim=2)
        head_matrix = self._cayley_matrix(
            unique_head, head_extra
        ).index_select(0, inverse)
        tail_matrix = self._cayley_matrix(
            unique_tail, tail_extra
        ).index_select(0, inverse)
        cayley_residual = (
            self._apply_cayley_matrix(head, head_matrix) + translation
            - self._apply_cayley_matrix(tail, tail_matrix)
        )

        branch_scores = self.gamma.item() - torch.stack([
            torch.norm(direct_residual, p=1, dim=2),
            torch.norm(cayley_residual, p=1, dim=2),
        ], dim=2)
        log_weights = torch.log(
            self.orthogonal_frame_weights(relation_id).clamp_min(1e-12)
        ).unsqueeze(1)
        temperature = self.orthogonal_temperature
        return temperature * torch.logsumexp(
            branch_scores / temperature + log_weights, dim=2
        )

    def RelativeCayleyFusionTransERR(
            self, head, relation, tail, relation_id, mode):
        """Fuse a shared quaternion frame with general SO(4) actions."""
        base, translation, relative = torch.chunk(relation, 3, dim=2)
        head_operator = self.q_norm(base)
        tail_operator = self.q_norm(self._calc(
            head_operator, self.q_norm(relative)
        ))
        relative_residual = (
            self._calc(head, head_operator) + translation
            - self._calc(tail, tail_operator)
        )

        unique_relation_id, inverse = torch.unique(
            relation_id, sorted=False, return_inverse=True
        )
        if self.model_name == 'DecoupledRelativeCayleyFusionTransERR':
            unique_generator = self.cayley_relation_embedding.index_select(
                0, unique_relation_id
            ).unsqueeze(1)
            unique_head, unique_tail = torch.chunk(
                unique_generator, 2, dim=2
            )
        else:
            unique_relation = self.relation_embedding.index_select(
                0, unique_relation_id
            ).unsqueeze(1)
            unique_head, _, unique_tail = torch.chunk(
                unique_relation, 3, dim=2
            )
        unique_extra = self.cayley_extra_embedding.index_select(
            0, unique_relation_id
        ).unsqueeze(1)
        head_extra, tail_extra = torch.chunk(unique_extra, 2, dim=2)
        head_matrix = self._cayley_matrix(
            unique_head, head_extra
        ).index_select(0, inverse)
        tail_matrix = self._cayley_matrix(
            unique_tail, tail_extra
        ).index_select(0, inverse)
        cayley_residual = (
            self._apply_cayley_matrix(head, head_matrix) + translation
            - self._apply_cayley_matrix(tail, tail_matrix)
        )

        branch_scores = self.gamma.item() - torch.stack([
            torch.norm(relative_residual, p=1, dim=2),
            torch.norm(cayley_residual, p=1, dim=2),
        ], dim=2)
        log_weights = torch.log(
            self.orthogonal_frame_weights(relation_id).clamp_min(1e-12)
        ).unsqueeze(1)
        temperature = self.orthogonal_temperature
        return temperature * torch.logsumexp(
            branch_scores / temperature + log_weights, dim=2
        )

    def orthogonal_frame_weights(self, relation_id):
        weights = F.softmax(
            self.orthogonal_router_logits.index_select(0, relation_id),
            dim=1
        )
        minimum = self.frame_min_weight
        if minimum != 0.0:
            weights = minimum + (1.0 - 2.0 * minimum) * weights
        return weights

    def BlockCayleyFrameFusionTransERR(
            self, head, relation, tail, relation_id, mode):
        """Select quaternion or SO(4) actions independently per block."""
        head_generator, translation, tail_generator = torch.chunk(
            relation, 3, dim=2
        )
        direct_residual = (
            self._calc(head, self.q_norm(head_generator)) + translation
            - self._calc(tail, self.q_norm(tail_generator))
        )

        unique_relation_id, inverse = torch.unique(
            relation_id, sorted=False, return_inverse=True
        )
        unique_relation = self.relation_embedding.index_select(
            0, unique_relation_id
        ).unsqueeze(1)
        unique_head, _, unique_tail = torch.chunk(
            unique_relation, 3, dim=2
        )
        unique_extra = self.cayley_extra_embedding.index_select(
            0, unique_relation_id
        ).unsqueeze(1)
        head_extra, tail_extra = torch.chunk(unique_extra, 2, dim=2)
        head_matrix = self._cayley_matrix(
            unique_head, head_extra
        ).index_select(0, inverse)
        tail_matrix = self._cayley_matrix(
            unique_tail, tail_extra
        ).index_select(0, inverse)
        cayley_residual = (
            self._apply_cayley_matrix(head, head_matrix) + translation
            - self._apply_cayley_matrix(tail, tail_matrix)
        )

        block_distances = torch.stack([
            sum(component.abs() for component in torch.chunk(
                direct_residual, 4, dim=2
            )),
            sum(component.abs() for component in torch.chunk(
                cayley_residual, 4, dim=2
            )),
        ], dim=3)
        weights = F.softmax(
            self.block_orthogonal_router_logits.index_select(
                0, relation_id
            ),
            dim=2
        )
        minimum = self.block_frame_min_weight
        if minimum != 0.0:
            weights = minimum + (1.0 - 2.0 * minimum) * weights
        temperature = self.block_frame_temperature
        block_distance = -temperature * torch.logsumexp(
            -block_distances / temperature
            + torch.log(weights.clamp_min(1e-12)).unsqueeze(1),
            dim=3
        )
        return self.gamma.item() - block_distance.sum(dim=2)

    def ResidualSO4TransERR(
            self, head, relation, tail, relation_id, mode):
        """Compose TransERR rotations with identity-initialized SO(4) maps."""
        head_operator, translation, tail_operator = torch.chunk(
            relation, 3, dim=2
        )
        direct_head = self._calc(head, self.q_norm(head_operator))
        direct_tail = self._calc(tail, self.q_norm(tail_operator))

        unique_relation_id, inverse = torch.unique(
            relation_id, sorted=False, return_inverse=True
        )
        unique_residual = self.residual_so4_embedding.index_select(
            0, unique_relation_id
        ).unsqueeze(1)
        unique_residual = self._bounded_residual_so4(unique_residual)
        head_generator, tail_generator, extra = torch.chunk(
            unique_residual, 3, dim=2
        )
        head_extra, tail_extra = torch.chunk(extra, 2, dim=2)
        head_matrix = self._cayley_matrix(
            head_generator, head_extra
        ).index_select(0, inverse)
        tail_matrix = self._cayley_matrix(
            tail_generator, tail_extra
        ).index_select(0, inverse)
        residual = (
            self._apply_cayley_matrix(direct_head, head_matrix)
            + translation
            - self._apply_cayley_matrix(direct_tail, tail_matrix)
        )
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def _bounded_residual_so4(self, generator):
        bound = self.residual_so4_bound
        if bound == 0.0:
            return generator
        scale = self.embedding_range.clamp_min(1e-9)
        return scale * bound * torch.tanh(generator / scale)

    def CoupledResidualSO4TransERR(
            self, head, relation, tail, relation_id, mode):
        """Apply inverse SO(4) half steps around the TransERR residual."""
        head_operator, translation, tail_operator = torch.chunk(
            relation, 3, dim=2
        )
        direct_head = self._calc(head, self.q_norm(head_operator))
        direct_tail = self._calc(tail, self.q_norm(tail_operator))

        unique_relation_id, inverse = torch.unique(
            relation_id, sorted=False, return_inverse=True
        )
        unique_generator = self.coupled_residual_so4_embedding.index_select(
            0, unique_relation_id
        ).unsqueeze(1)
        unique_generator = self._bounded_residual_so4(unique_generator)
        base_generator, extra_generator = torch.split(
            unique_generator,
            [self.entity_dim, self.entity_dim // 2],
            dim=2,
        )
        half_base = 0.5 * base_generator
        half_extra = 0.5 * extra_generator
        head_matrix = self._cayley_matrix(
            half_base, half_extra
        ).index_select(0, inverse)
        tail_matrix = self._cayley_matrix(
            -half_base, -half_extra
        ).index_select(0, inverse)
        residual = (
            self._apply_cayley_matrix(direct_head, head_matrix)
            + translation
            - self._apply_cayley_matrix(direct_tail, tail_matrix)
        )
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def RelativeResidualSO4TransERR(
            self, head, relation, tail, relation_id, mode):
        """Map the transformed head into the tail/translation frame."""
        head_operator, translation, tail_operator = torch.chunk(
            relation, 3, dim=2
        )
        direct_head = self._calc(head, self.q_norm(head_operator))
        direct_tail = self._calc(tail, self.q_norm(tail_operator))

        unique_relation_id, inverse = torch.unique(
            relation_id, sorted=False, return_inverse=True
        )
        unique_generator = self.relative_residual_so4_embedding.index_select(
            0, unique_relation_id
        ).unsqueeze(1)
        unique_generator = self._bounded_residual_so4(unique_generator)
        base_generator, extra_generator = torch.split(
            unique_generator,
            [self.entity_dim, self.entity_dim // 2],
            dim=2,
        )
        head_matrix = self._cayley_matrix(
            base_generator, extra_generator
        ).index_select(0, inverse)
        residual = (
            self._apply_cayley_matrix(direct_head, head_matrix)
            + translation
            - direct_tail
        )
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def GatedResidualSO4TransERR(
            self, head, relation, tail, relation_id, mode):
        """Select the original or SO(4) residual per relation and block."""
        head_operator, translation, tail_operator = torch.chunk(
            relation, 3, dim=2
        )
        direct_head = self._calc(head, self.q_norm(head_operator))
        direct_tail = self._calc(tail, self.q_norm(tail_operator))
        return self._gated_so4_score(
            direct_head, translation, direct_tail, relation_id
        )

    def RelativeGatedSO4TransERR(
            self, head, relation, tail, relation_id, mode):
        """Apply gated SO(4) maps on a RelativeQuaternion base frame."""
        base, translation, relative = torch.chunk(relation, 3, dim=2)
        head_operator = self.q_norm(base)
        relative_operator = self.q_norm(relative)
        tail_operator = self.q_norm(self._calc(
            head_operator, relative_operator
        ))
        direct_head = self._calc(head, head_operator)
        direct_tail = self._calc(tail, tail_operator)
        return self._gated_so4_score(
            direct_head, translation, direct_tail, relation_id
        )

    def _gated_so4_score(
            self, direct_head, translation, direct_tail, relation_id):
        direct_residual = direct_head + translation - direct_tail

        unique_relation_id, inverse = torch.unique(
            relation_id, sorted=False, return_inverse=True
        )
        unique_residual = self.residual_so4_embedding.index_select(
            0, unique_relation_id
        ).unsqueeze(1)
        unique_residual = self._bounded_residual_so4(unique_residual)
        head_generator, tail_generator, extra = torch.chunk(
            unique_residual, 3, dim=2
        )
        head_extra, tail_extra = torch.chunk(extra, 2, dim=2)
        head_matrix = self._cayley_matrix(
            head_generator, head_extra
        ).index_select(0, inverse)
        tail_matrix = self._cayley_matrix(
            tail_generator, tail_extra
        ).index_select(0, inverse)
        geometric_residual = (
            self._apply_cayley_matrix(direct_head, head_matrix)
            + translation
            - self._apply_cayley_matrix(direct_tail, tail_matrix)
        )

        gate = torch.sigmoid(
            self.residual_so4_gate_logits.index_select(0, relation_id)
        ).unsqueeze(1)
        residual = torch.cat([
            direct_component
            + gate * (geometric_component - direct_component)
            for direct_component, geometric_component in zip(
                torch.chunk(direct_residual, 4, dim=2),
                torch.chunk(geometric_residual, 4, dim=2),
            )
        ], dim=2)
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def DomainRangeGatedSO4TransERR(
            self, head, relation, tail, relation_id, sample, mode):
        """Combine adaptive SO(4) geometry with domain/range priors."""
        score = self.GatedResidualSO4TransERR(
            head, relation, tail, relation_id, mode
        )
        return score + self._relation_entity_bias(
            relation_id, sample, mode
        )

    def ProjectedGatedSO4TransERR(
            self, head, relation, tail, relation_id, mode):
        """Combine adaptive SO(4) geometry with shared type projections."""
        score = self.GatedResidualSO4TransERR(
            head, relation, tail, relation_id, mode
        )
        return score + self._domain_range_projection(
            head, tail, relation_id
        )

    def _apply_cayley_matrix(self, value, matrix):
        # Explicit row-vector multiplication avoids dispatching millions of
        # tiny 1x4 by 4x4 matmuls during negative sampling and evaluation.
        v0, v1, v2, v3 = torch.chunk(value, 4, dim=2)
        transformed = []
        for column in range(4):
            transformed.append(
                v0 * matrix[..., 0, column]
                + v1 * matrix[..., 1, column]
                + v2 * matrix[..., 2, column]
                + v3 * matrix[..., 3, column]
            )
        return torch.cat(transformed, dim=2)

    def _cayley_matrix(self, base_generator, extra_generator):
        scale = self.embedding_range.clamp_min(1e-9)
        a01, a02, a03, a12 = torch.chunk(
            base_generator / scale, 4, dim=2
        )
        a13, a23 = torch.chunk(
            extra_generator / scale, 2, dim=2
        )
        zero = torch.zeros_like(a01)
        skew = torch.stack([
            torch.stack([zero, a01, a02, a03], dim=-1),
            torch.stack([-a01, zero, a12, a13], dim=-1),
            torch.stack([-a02, -a12, zero, a23], dim=-1),
            torch.stack([-a03, -a13, -a23, zero], dim=-1),
        ], dim=-2)
        identity = torch.eye(
            4, dtype=skew.dtype, device=skew.device
        )
        return torch.linalg.solve(identity + skew, identity - skew)

    def QuaternionMobiusTransERR(
            self, head, relation, tail, relation_id, mode):
        """Apply compact nonlinear right-quaternion fractional maps."""
        head_a, head_b, tail_a = torch.chunk(relation, 3, dim=2)
        auxiliary = self.mobius_aux_embedding.index_select(
            0, relation_id
        ).unsqueeze(1)
        head_c, head_d, tail_b, tail_c, tail_d = torch.chunk(
            auxiliary, 5, dim=2
        )
        transformed_head = self._quaternion_mobius_map(
            head, self.q_norm(head_a), head_b, head_c, head_d
        )
        transformed_tail = self._quaternion_mobius_map(
            tail, self.q_norm(tail_a), tail_b, tail_c, tail_d
        )
        residual = transformed_head - transformed_tail
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def _quaternion_mobius_map(self, value, a, b, raw_c, d):
        c = self.mobius_c_bound * torch.tanh(raw_c)
        numerator = self._calc(value, a) + b
        denominator = self._calc(value, c) + d
        return self._calc(
            numerator, self._quaternion_inverse(denominator)
        )

    def _quaternion_inverse(self, value):
        parts = torch.chunk(value, 4, dim=2)
        norm_squared = sum(part.square() for part in parts).clamp_min(
            self.mobius_denominator_epsilon
        )
        conjugate_parts = torch.chunk(
            self.q_conjugate(value), 4, dim=2
        )
        return torch.cat([
            part / norm_squared for part in conjugate_parts
        ], dim=2)

    def ResidualSubspaceTransERR(
            self, head, relation, tail, relation_id, mode):
        """Learn a relation-specific metric over groups of final residuals."""
        wh, translation, wt = torch.chunk(relation, 3, dim=2)
        residual = (
            self._calc(head, self.q_norm(wh)) + translation
            - self._calc(tail, self.q_norm(wt))
        )
        group_weights = self.subspace_weights(relation_id)
        dimension_weights = group_weights.repeat_interleave(
            self.entity_dim // self.subspace_groups, dim=1
        ).unsqueeze(1)
        distance = torch.norm(
            residual * dimension_weights, p=1, dim=2
        )
        return self.gamma.item() - distance

    def subspace_weights(self, relation_id):
        logits = self.subspace_logits.index_select(0, relation_id)
        centered = logits - logits.mean(dim=1, keepdim=True)
        unnormalized = torch.exp(centered.clamp(min=-10.0, max=10.0))
        return unnormalized / unnormalized.mean(dim=1, keepdim=True)

    def DualQuaternionTransERR(
            self, head, relation, tail, relation_id, sample, mode):
        """Lift TransERR into dual-quaternion algebra with a bounded dual penalty."""
        dual_head, dual_tail = self._select_expert_entities(
            self.dual_entity_embedding, sample, mode
        )
        dual_relation = self.dual_relation_embedding.index_select(
            0, relation_id
        ).unsqueeze(1)

        wh, translation, wt = torch.chunk(relation, 3, dim=2)
        raw_dual_wh, dual_translation, raw_dual_wt = torch.chunk(
            dual_relation, 3, dim=2
        )
        wh = self.q_norm(wh)
        wt = self.q_norm(wt)
        dual_wh = self.q_project_dual(wh, raw_dual_wh)
        dual_wt = self.q_project_dual(wt, raw_dual_wt)

        real_residual = (
            self._calc(head, wh) + translation - self._calc(tail, wt)
        )
        dual_transformed_head = (
            self._calc(head, dual_wh) + self._calc(dual_head, wh)
        )
        dual_transformed_tail = (
            self._calc(tail, dual_wt) + self._calc(dual_tail, wt)
        )
        dual_residual = (
            dual_transformed_head + dual_translation
            - dual_transformed_tail
        )

        real_distance = torch.norm(real_residual, p=1, dim=2)
        dual_distance = torch.norm(dual_residual, p=1, dim=2)
        dual_weight = self.dual_weight_bound * torch.sigmoid(
            self.dual_gate.index_select(0, relation_id)
        )
        return self.gamma.item() - real_distance - dual_weight * dual_distance

    def q_project_dual(self, primary, dual):
        primary_parts = torch.chunk(primary, 4, dim=2)
        dual_parts = torch.chunk(dual, 4, dim=2)
        inner_product = sum(
            p * d for p, d in zip(primary_parts, dual_parts)
        )
        projected = [
            d - inner_product * p
            for p, d in zip(primary_parts, dual_parts)
        ]
        return torch.cat(projected, dim=2)

    @staticmethod
    def q_conjugate(value):
        return quaternion_conjugate(value)

    def OctonionTransERR(self, head, relation, tail, mode):
        """TransERR using normalized octonion relation operators at fixed width."""
        wh, translation, wt = torch.chunk(relation, 3, dim=2)
        wh = self.octonion_norm(wh)
        wt = self.octonion_norm(wt)
        residual = (
            self._octonion_calc(head, wh) + translation
            - self._octonion_calc(tail, wt)
        )
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    @staticmethod
    def _octonion_calc(left, right):
        a = torch.chunk(left, 8, dim=2)
        b = torch.chunk(right, 8, dim=2)
        a0, a1, a2, a3, a4, a5, a6, a7 = a
        b0, b1, b2, b3, b4, b5, b6, b7 = b
        result = [
            a0*b0-a1*b1-a2*b2-a3*b3-a4*b4-a5*b5-a6*b6-a7*b7,
            a0*b1+a1*b0+a2*b3-a3*b2+a4*b5-a5*b4-a6*b7+a7*b6,
            a0*b2-a1*b3+a2*b0+a3*b1+a4*b6+a5*b7-a6*b4-a7*b5,
            a0*b3+a1*b2-a2*b1+a3*b0+a4*b7-a5*b6+a6*b5-a7*b4,
            a0*b4-a1*b5-a2*b6-a3*b7+a4*b0+a5*b1+a6*b2+a7*b3,
            a0*b5+a1*b4-a2*b7+a3*b6-a4*b1+a5*b0-a6*b3+a7*b2,
            a0*b6+a1*b7+a2*b4-a3*b5-a4*b2+a5*b3+a6*b0-a7*b1,
            a0*b7-a1*b6+a2*b5+a3*b4-a4*b3-a5*b2+a6*b1+a7*b0,
        ]
        return torch.cat(result, dim=2)

    @staticmethod
    def octonion_norm(value):
        parts = torch.chunk(value, 8, dim=2)
        denominator = torch.sqrt(sum(part ** 2 for part in parts)).clamp_min(1e-9)
        return torch.cat([part / denominator for part in parts], dim=2)

    def ContextTransERR(self, head, relation, tail, relation_id, mode):
        """TransERR with a relation-specific low-rank dynamic translation."""
        wh, r, wt = torch.chunk(relation, 3, dim=2)
        transformed_head = self._calc(head, self.q_norm(wh))
        transformed_tail = self._calc(tail, self.q_norm(wt))

        down = self.context_down.index_select(0, relation_id)
        up = self.context_up.index_select(0, relation_id)
        context = torch.tanh(torch.einsum(
            'bnd,brd->bnr', transformed_head, down
        ))
        raw_delta = torch.einsum('bnr,bdr->bnd', context, up)
        raw_delta = raw_delta / math.sqrt(float(self.context_rank))
        delta = self.context_delta_bound * torch.tanh(raw_delta)
        gate = torch.sigmoid(
            self.context_gate.index_select(0, relation_id)
        ).unsqueeze(1)

        residual = transformed_head + r + gate * delta - transformed_tail
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def ScaleTransERR(self, head, relation, tail, relation_id, mode):
        """TransERR with bounded relation-only head and tail scaling."""
        wh, r, wt = torch.chunk(relation, 3, dim=2)
        transformed_head = self._calc(head, self.q_norm(wh))
        transformed_tail = self._calc(tail, self.q_norm(wt))

        head_scale = self._relation_scale(self.head_scale, relation_id)
        tail_scale = self._relation_scale(self.tail_scale, relation_id)
        residual = (
            transformed_head * head_scale + r
            - transformed_tail * tail_scale
        )
        return self.gamma.item() - torch.norm(residual, p=1, dim=2)

    def _relation_scale(self, scale_logits, relation_id):
        scale = scale_logits.index_select(0, relation_id)
        if self.model_name == 'ScaleGroupTransERR':
            component_dim = self.hidden_dim // 4
            scale = scale.repeat_interleave(component_dim, dim=1)
        return (1.0 + self.scale_bound * torch.tanh(scale)).unsqueeze(1)

    def MoGeoTransERR(self, head, relation, tail, relation_id, sample, mode):
        """Relation-routed mixture of quaternion, complex and hyperbolic scores."""
        transerr_score = self.TransERR(head, relation, tail, mode)

        complex_head, complex_tail = self._select_expert_entities(
            self.complex_entity_embedding, sample, mode
        )
        complex_relation = self.complex_relation_embedding.index_select(
            0, relation_id
        ).unsqueeze(1)
        complex_score = self._complex_score(
            complex_head, complex_relation, complex_tail
        ) / math.sqrt(float(self.complex_dim // 2))

        hyperbolic_head, hyperbolic_tail = self._select_expert_entities(
            self.hyperbolic_entity_embedding, sample, mode
        )
        hyperbolic_relation = self.hyperbolic_relation_embedding.index_select(
            0, relation_id
        ).unsqueeze(1)
        curvature = (
            F.softplus(self.curvature_raw.index_select(0, relation_id))
            + 1e-3
        ).unsqueeze(1)
        mapped_head = self._expmap0(hyperbolic_head, curvature)
        mapped_relation = self._expmap0(hyperbolic_relation, curvature)
        mapped_tail = self._expmap0(hyperbolic_tail, curvature)
        translated_head = self._mobius_add(
            mapped_head, mapped_relation, curvature
        )
        hyperbolic_score = -self._poincare_distance(
            translated_head, mapped_tail, curvature
        )

        expert_scores = torch.stack([
            transerr_score, complex_score, hyperbolic_score
        ], dim=-1)
        scales = F.softplus(self.expert_scale_raw).view(1, 1, 3)
        biases = self.expert_bias.view(1, 1, 3)
        calibrated_scores = expert_scores * scales + biases
        router = self.router_weights(relation_id).unsqueeze(1)
        return torch.sum(router * calibrated_scores, dim=-1)

    def router_weights(self, relation_id=None):
        logits = self.router_logits
        if relation_id is not None:
            logits = logits.index_select(0, relation_id)
        return F.softmax(logits / self.router_temperature, dim=-1)

    @staticmethod
    def _select_expert_entities(embedding, sample, mode):
        if mode == 'single':
            head = embedding.index_select(0, sample[:, 0]).unsqueeze(1)
            tail = embedding.index_select(0, sample[:, 2]).unsqueeze(1)
        elif mode == 'head-batch':
            positive, negative = sample
            head = embedding.index_select(
                0, negative.reshape(-1)
            ).view(negative.size(0), negative.size(1), -1)
            tail = embedding.index_select(0, positive[:, 2]).unsqueeze(1)
        elif mode == 'tail-batch':
            positive, negative = sample
            head = embedding.index_select(0, positive[:, 0]).unsqueeze(1)
            tail = embedding.index_select(
                0, negative.reshape(-1)
            ).view(negative.size(0), negative.size(1), -1)
        else:
            raise ValueError('mode %s not supported' % mode)
        return head, tail

    @staticmethod
    def _complex_score(head, relation, tail):
        re_head, im_head = torch.chunk(head, 2, dim=2)
        re_relation, im_relation = torch.chunk(relation, 2, dim=2)
        re_tail, im_tail = torch.chunk(tail, 2, dim=2)
        return (
            re_head * re_relation * re_tail
            + re_head * im_relation * im_tail
            + im_head * re_relation * im_tail
            - im_head * im_relation * re_tail
        ).sum(dim=2)

    @staticmethod
    def _project_ball(x, curvature):
        sqrt_c = torch.sqrt(curvature)
        max_norm = (1.0 - 1e-5) / sqrt_c
        norm = torch.norm(x, p=2, dim=2, keepdim=True).clamp_min(1e-9)
        return x * torch.clamp(max_norm / norm, max=1.0)

    def _expmap0(self, tangent, curvature):
        sqrt_c = torch.sqrt(curvature)
        norm = torch.norm(tangent, p=2, dim=2, keepdim=True).clamp_min(1e-9)
        mapped = (
            torch.tanh(sqrt_c * norm)
            * tangent / (sqrt_c * norm)
        )
        return self._project_ball(mapped, curvature)

    def _mobius_add(self, x, y, curvature):
        x2 = torch.sum(x * x, dim=2, keepdim=True)
        y2 = torch.sum(y * y, dim=2, keepdim=True)
        xy = torch.sum(x * y, dim=2, keepdim=True)
        numerator = (
            (1.0 + 2.0 * curvature * xy + curvature * y2) * x
            + (1.0 - curvature * x2) * y
        )
        denominator = (
            1.0 + 2.0 * curvature * xy
            + curvature * curvature * x2 * y2
        ).clamp_min(1e-9)
        return self._project_ball(numerator / denominator, curvature)

    def _poincare_distance(self, x, y, curvature):
        delta = self._mobius_add(-x, y, curvature)
        sqrt_c = torch.sqrt(curvature)
        delta_norm = torch.norm(delta, p=2, dim=2).clamp_min(1e-9)
        scaled_norm = (sqrt_c.squeeze(-1) * delta_norm).clamp_max(1.0 - 1e-5)
        return 2.0 * torch.atanh(scaled_norm) / sqrt_c.squeeze(-1)
  
    def _calc(self, h, r):
        return hamilton_product(h, r)


    def q_norm(self, r):
        return normalize_quaternion(r)

    @staticmethod
    def curriculum_hard_negative_progress(step, start_step, ramp_steps):
        return curriculum_progress(step, start_step, ramp_steps)

    @staticmethod
    def select_curriculum_negatives(
            uniform_negative, hard_negative, hard_count_cap, progress):
        return select_scheduled_negatives(
            uniform_negative, hard_negative, hard_count_cap, progress
        )

    @staticmethod
    def _masked_negative_score(
            raw_negative_score, mask, adversarial, temperature):
        return masked_negative_log_likelihood(
            raw_negative_score, mask, adversarial, temperature
        )
    
    @staticmethod
    def train_step(model, optimizer, train_iterator, args, step=None):
        '''
        A single train step. Apply back-propation and return the loss
        '''

        model.train()
        model.current_training_step = 0 if step is None else int(step)
        model.update_rank_defect_progress(model.current_training_step)

        optimizer.zero_grad()

        train_batch = next(train_iterator)
        curriculum_batch = len(train_batch) == 6
        curriculum_progress = 0.0
        hard_mask = None
        hard_count = None
        if curriculum_batch:
            (positive_sample, uniform_negative, hard_negative,
             hard_count_cap, subsampling_weight, mode) = train_batch
            curriculum_progress = model.curriculum_hard_negative_progress(
                0 if step is None else step,
                args.curriculum_hard_negative_start_step,
                args.curriculum_hard_negative_ramp_steps
            )
            negative_sample, hard_mask, hard_count = (
                model.select_curriculum_negatives(
                    uniform_negative, hard_negative, hard_count_cap,
                    curriculum_progress
                )
            )
        else:
            (positive_sample, negative_sample,
             subsampling_weight, mode) = train_batch

        if args.cuda:
            positive_sample = positive_sample.cuda()
            negative_sample = negative_sample.cuda()
            subsampling_weight = subsampling_weight.cuda()
            if hard_mask is not None:
                hard_mask = hard_mask.cuda()
                hard_count = hard_count.cuda()

        cache_log = {}
        cache = getattr(model, 'negative_cache', None)
        if cache is not None:
            if curriculum_batch or getattr(args, 'relation_pool_negative_ratio', 0) > 0:
                raise ValueError('Persistent cache cannot be combined with relation-pool sampling')
            negative_sample, cache_log = cache.sample(model, positive_sample, negative_sample, mode)

        raw_negative_score = model(
            (positive_sample, negative_sample), mode=mode
        )

        curriculum_active = (
            curriculum_batch and curriculum_progress > 0.0
        )
        if curriculum_active:
            uniform_negative_score, _ = model._masked_negative_score(
                raw_negative_score, ~hard_mask,
                args.negative_adversarial_sampling,
                args.adversarial_temperature
            )
            hard_negative_score, _ = model._masked_negative_score(
                raw_negative_score, hard_mask,
                args.negative_adversarial_sampling,
                args.adversarial_temperature
            )
            hard_fraction = (
                hard_count.to(raw_negative_score.dtype)
                / raw_negative_score.size(1)
            )
            negative_score = (
                (1.0 - hard_fraction) * uniform_negative_score
                + hard_fraction * hard_negative_score
            )
        elif args.negative_adversarial_sampling:
            #In self-adversarial sampling, we do not apply back-propagation on the sampling weight
            negative_score = (
                F.softmax(
                    raw_negative_score * args.adversarial_temperature,
                    dim=1
                ).detach()
                * F.logsigmoid(-raw_negative_score)
            ).sum(dim=1)
        else:
            negative_score = F.logsigmoid(
                -raw_negative_score
            ).mean(dim=1)

        curriculum_log = {}
        if curriculum_batch:
            curriculum_log = {
                'curriculum_progress': curriculum_progress,
                'hard_negative_fraction': (
                    hard_count.float().mean().item()
                    / negative_sample.size(1)
                )
            }

        positive_mode = 'single'
        if model.model_name in (
                'ReciprocalTransERR',
                'ReciprocalRelativeQuaternionTransERR',
                'CoupledReciprocalTransERR',
                'CoupledReciprocalRelativeQuaternionTransERR',
                'TailResidualReciprocalTransERR',
                'TailResidualReciprocalRelativeQuaternionTransERR',
                'BidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'BilinearResidualBidirectionalRelativeQuaternionTransERR',
                'RelationMetricBidirectionalRelativeQuaternionTransERR',
                'HamiltonCompatibilityBidirectionalRelativeQuaternionTransERR',
                'ResidualEnergyBidirectionalRelativeQuaternionTransERR',
                'TwoSidedBidirectionalRelativeQuaternionTransERR',
                'FullCayleyBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'Rank2CayleyBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'BidirectionalTranslationResidualReciprocalRelativeQuaternionTransERR',
                'SoftExtremalBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'MaxMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'MeanVarianceBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'PMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'RoleSeparatedReciprocalTransERR',
                'BoundedRoleReciprocalTransERR') \
                or model.model_name in _COUPLED_TRANSLATION_RESIDUAL_MODELS \
                or model.model_name in _ADAPTIVE_MOMENT_RECIPROCAL_MODELS \
                or model.model_name in _BLOCK_TRANSPORT_RECIPROCAL_MODELS \
                or model.model_name in _INTERLEAVED_BLOCK_TRANSPORT_RECIPROCAL_MODELS:
            positive_mode = (
                'head-single' if mode == 'head-batch' else 'tail-single'
            )
        raw_positive_score = model(positive_sample, mode=positive_mode)

        positive_score = F.logsigmoid(
            raw_positive_score
        ).squeeze(dim=1)

        if args.uni_weight:
            positive_sample_loss = - positive_score.mean()
            negative_sample_loss = - negative_score.mean()
        else:
            positive_sample_loss = - (subsampling_weight * positive_score).sum()/subsampling_weight.sum()
            negative_sample_loss = - (subsampling_weight * negative_score).sum()/subsampling_weight.sum()

        loss = (positive_sample_loss + negative_sample_loss)/2

        rank_loss_weight = getattr(args, 'rank_loss_weight', 0.0)
        rank_loss_log = {}
        if rank_loss_weight != 0.0:
            rank_loss_mode = getattr(args, 'rank_loss_mode', 'pairwise')
            rank_loss_topk = getattr(args, 'rank_loss_topk', 10)
            rank_loss_cutoffs = tuple(
                getattr(args, 'rank_loss_cutoffs', (1, 3, 10))
            )
            if rank_loss_topk <= 0:
                raise ValueError('rank_loss_topk must be positive')
            if (not rank_loss_cutoffs
                    or min(rank_loss_cutoffs) <= 0):
                raise ValueError(
                    'rank_loss_cutoffs must contain positive ranks'
                )

            pairwise_hard_negative_score = None
            cutoff_hard_negative_score = None
            rank_negative_score = raw_negative_score
            if curriculum_active:
                rank_negative_score = raw_negative_score.masked_fill(
                    hard_mask, float('-inf')
                )
            if rank_loss_mode in ('pairwise', 'hybrid'):
                pairwise_hard_negative_score = torch.topk(
                    rank_negative_score,
                    k=min(rank_loss_topk, rank_negative_score.size(1)),
                    dim=1
                ).values
            if rank_loss_mode in ('cutoff', 'hybrid'):
                max_cutoff = max(rank_loss_cutoffs)
                if max_cutoff > rank_negative_score.size(1):
                    raise ValueError(
                        'rank_loss_cutoffs cannot exceed negative sample size'
                    )
                sorted_hard_negative_score = torch.topk(
                    rank_negative_score, k=max_cutoff, dim=1
                ).values
                cutoff_indices = torch.tensor(
                    [cutoff - 1 for cutoff in rank_loss_cutoffs],
                    device=raw_negative_score.device,
                )
                cutoff_hard_negative_score = (
                    sorted_hard_negative_score.index_select(
                    dim=1, index=cutoff_indices
                    )
                )
            if rank_loss_mode not in ('pairwise', 'cutoff', 'hybrid'):
                raise ValueError(
                    'rank_loss_mode must be pairwise, cutoff, or hybrid'
                )

            positive_rank_score = raw_positive_score.squeeze(
                dim=1
            ).unsqueeze(dim=1)
            rank_loss_margin = getattr(args, 'rank_loss_margin', 0.0)
            pairwise_rank_loss = None
            cutoff_rank_loss = None
            if pairwise_hard_negative_score is not None:
                pairwise_rank_loss = F.softplus(
                    pairwise_hard_negative_score
                    - positive_rank_score
                    + rank_loss_margin
                ).mean(dim=1)
            if cutoff_hard_negative_score is not None:
                cutoff_rank_loss = F.softplus(
                    cutoff_hard_negative_score
                    - positive_rank_score
                    + rank_loss_margin
                ).mean(dim=1)
            if rank_loss_mode == 'pairwise':
                rank_loss_per_sample = pairwise_rank_loss
            elif rank_loss_mode == 'cutoff':
                rank_loss_per_sample = cutoff_rank_loss
            else:
                rank_loss_per_sample = (
                    pairwise_rank_loss + cutoff_rank_loss
                ) / 2
            curriculum_rank_log = {}
            if curriculum_active:
                hard_rank_topk = min(
                    args.curriculum_hard_rank_topk,
                    raw_negative_score.size(1)
                )
                hard_rank_score = torch.topk(
                    raw_negative_score.masked_fill(
                        ~hard_mask, float('-inf')
                    ),
                    k=hard_rank_topk,
                    dim=1
                ).values
                hard_rank_valid = (
                    torch.arange(
                        hard_rank_topk,
                        device=raw_negative_score.device
                    ).unsqueeze(0)
                    < hard_count.clamp(max=hard_rank_topk).unsqueeze(1)
                )
                hard_rank_element = F.softplus(
                    hard_rank_score
                    - positive_rank_score
                    + rank_loss_margin
                )
                hard_rank_loss = (
                    hard_rank_element
                    * hard_rank_valid.to(hard_rank_element.dtype)
                ).sum(dim=1) / hard_rank_valid.sum(dim=1).clamp_min(1)
                rank_blend = (
                    curriculum_progress
                    * (hard_count > 0).to(rank_loss_per_sample.dtype)
                )
                uniform_rank_loss = rank_loss_per_sample
                rank_loss_per_sample = (
                    (1.0 - rank_blend) * uniform_rank_loss
                    + rank_blend * hard_rank_loss
                )
                curriculum_rank_log = {
                    'uniform_rank_loss': uniform_rank_loss.mean().item(),
                    'hard_rank_loss': hard_rank_loss.mean().item(),
                }
            if args.uni_weight:
                rank_loss = rank_loss_per_sample.mean()
            else:
                rank_loss = (
                    subsampling_weight * rank_loss_per_sample
                ).sum() / subsampling_weight.sum()
            loss += rank_loss_weight * rank_loss
            rank_loss_log = {
                'rank_loss': rank_loss.item(),
                **curriculum_rank_log,
            }
        
        if args.regularization != 0.0:
            ent_reg = torch.sum(model.entity_embedding ** 2, dim=-1)
            if model.model_name == 'RoleSeparatedReciprocalTransERR':
                target_ent_reg = torch.sum(
                    model.target_entity_embedding ** 2, dim=-1
                )
                ent_reg = torch.cat([ent_reg, target_ent_reg])
            if (model.model_name == 'ContextTransERR'
                    or args.norm_aware_regularization):
                # The relation operators are normalized in the score, so
                # shrinking their raw norms is unidentifiable and unstable.
                if model.model_name in SPIN_MODELS:
                    _, translation, _ = split_spin_relation(model.relation_embedding, model.entity_dim)
                    rel_reg = translation.square().sum(-1)
                elif model.model_name == MIXED_SPIN_MODEL:
                    _, translation, _ = split_mixed_relation(model.relation_embedding, model.entity_dim)
                    rel_reg = translation.square().sum(-1)
                elif model.model_name == 'BuresTransERR':
                    _, head_offset, _ = model.relation_embedding.chunk(3, dim=-1)
                    rel_reg = head_offset.square().sum(-1) + model.bures_tail_offset.square().sum(-1)
                elif model.model_name == 'MidpointCartanComplexTransERR':
                    _, translation = torch.chunk(
                        model.relation_embedding, 2, dim=1
                    )
                    rel_reg = torch.sum(translation ** 2, dim=-1)
                elif (model.model_name in (
                        'TransERR', 'SpectralTransERR', 'KerrTransERR', 'FoldTransERR', 'LocalOTTransERR',
                        'ImplicitQuadraticTransERR',
                        'DoubleCenterTransERR', 'RegionTransERR', 'ReciprocalTransERR',
                        'ReciprocalRelativeQuaternionTransERR',
                        'CoupledReciprocalTransERR',
                        'CoupledReciprocalRelativeQuaternionTransERR',
                        'TailResidualReciprocalTransERR',
                        'TailResidualReciprocalRelativeQuaternionTransERR',
                        'BidirectionalResidualReciprocalRelativeQuaternionTransERR',
                        'BilinearResidualBidirectionalRelativeQuaternionTransERR',
                        'RelationMetricBidirectionalRelativeQuaternionTransERR',
                        'HamiltonCompatibilityBidirectionalRelativeQuaternionTransERR',
                        'ResidualEnergyBidirectionalRelativeQuaternionTransERR',
                        'TwoSidedBidirectionalRelativeQuaternionTransERR',
                        'RoleResidualBidirectionalRelativeQuaternionTransERR',
                        'ConjugateGatedBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                        'InverseConjugateGatedBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                        'FullCayleyBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                        'Rank2CayleyBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                        'BidirectionalTranslationResidualReciprocalRelativeQuaternionTransERR',
                        'CoupledTranslationResidualReciprocalRelativeQuaternionTransERR',
                        'GatedCoupledTranslationResidualReciprocalRelativeQuaternionTransERR',
                        'PolarBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                        'FlowBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                        'SoftExtremalBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                        'MaxMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                        'MeanVarianceBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                        'PMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                        'BlockQuaternionTransportBidirectionalRelativeQuaternionTransERR',
                        'InterleavedBlockQuaternionTransportBidirectionalRelativeQuaternionTransERR',
                        'RoleSeparatedReciprocalTransERR',
                        'BoundedRoleReciprocalTransERR',
                        'ContextTransERR',
                        'RelationEntityBiasTransERR',
                        'DomainRangeProjectionTransERR',
                        'ScaleGroupTransERR', 'ScaleDimTransERR',
                        'MoGeoTransERR', 'DualQuaternionTransERR',
                        'OctonionTransERR', 'BiquaternionTransERR',
                        'AdaptiveBiquaternionFusionTransERR',
                        'ConvexBiquaternionFusionTransERR',
                        'AdaptiveMetricCliffordTransERR',
                        'RealMatrix2TransERR',
                        'ComplexMatrix2TransERR',
                        'ResidualKroneckerComplexMatrix2TransERR',
                        'HouseholderShearTransERR',
                        'PortHamiltonianTransERR',
                        'StochasticPortHamiltonianTransERR',
                        'CayleyPortHamiltonianTransERR',
                        'RelativeQuaternionTransERR',
                        'AdaptiveFrameTransERR',
                        'BlockAdaptiveFrameTransERR',
                        'ResidualSubspaceTransERR',
                        'SymmetricRelativeTransERR',
                        'PreTranslationRelativeTransERR',
                        'BiRotorTransERR',
                        'CliffordRotorTransERR',
                        'LieGeodesicTransERR',
                        'ScrewFrameTransERR',
                        'CayleyOrthogonalTransERR',
                        'CayleyFrameFusionTransERR',
                        'BlockCayleyFrameFusionTransERR',
                        'ResidualSO4TransERR',
                        'CoupledResidualSO4TransERR',
                        'RelativeResidualSO4TransERR',
                        'GatedResidualSO4TransERR',
                        'DomainRangeGatedSO4TransERR',
                        'ProjectedGatedSO4TransERR',
                        'RelativeGatedSO4TransERR',
                        'RelativeCayleyFusionTransERR',
                        'DecoupledRelativeCayleyFusionTransERR',
                        'QuaternionMobiusTransERR')
                        or model.model_name
                        in _RANK_QUATERNION_OPERATOR_MODELS
                        or model.model_name
                        in _RANK_DEFECT_LOCAL_GLOBAL_MODELS):
                    _, translation, _ = torch.chunk(
                        model.relation_embedding, 3, dim=1
                    )
                    if model.model_name in (
                            'ReciprocalTransERR',
                            'ReciprocalRelativeQuaternionTransERR',
                            'RoleSeparatedReciprocalTransERR',
                            'BoundedRoleReciprocalTransERR'):
                        _, inverse_translation, _ = torch.chunk(
                            model.inverse_relation_embedding, 3, dim=1
                        )
                        translation = torch.cat([
                            translation, inverse_translation
                        ], dim=0)
                    rel_reg = torch.sum(translation ** 2, dim=-1)
                else:
                    rel_reg = torch.sum(model.relation_embedding ** 2, dim=-1)
            else:
                rel_reg = torch.sum(model.relation_embedding ** 2, dim=-1)
            reg = torch.cat([ent_reg, rel_reg]).mean()
            loss += reg * args.regularization
            regularization_log = {'regularization': reg.item()}
            if model.model_name in (
                    'BoundedRoleReciprocalTransERR',
                    'RoleResidualBidirectionalRelativeQuaternionTransERR'):
                role_delta_reg = torch.sum(
                    model.role_delta_embedding ** 2, dim=-1
                ).mean()
                loss += (
                    role_delta_reg * args.role_delta_regularization
                )
                regularization_log['role_delta_regularization'] = (
                    role_delta_reg.item()
                )
 
        else:
            regularization_log = {}

        if model.model_name == 'ImplicitQuadraticTransERR':
            weight = getattr(args, 'quadratic_regularization', 1e-4)
            effective = model.quadratic_bound * model.quadratic_output_raw.tanh()
            penalty = effective.square().mean()
            loss += weight * penalty
            regularization_log['quadratic_regularization'] = penalty.item()
        if model.model_name == 'BuresTransERR':
            weight = getattr(args, 'bures_regularization', 1e-4)
            penalty = (model.bures_stretch_bound * model.bures_stretch_raw.tanh()).square().mean()
            loss += weight * penalty
            regularization_log['bures_stretch_regularization'] = penalty.item()

        translation_weight = getattr(
            args, 'translation_regularization', 0.0
        )
        if translation_weight != 0.0:
            _, translation, _ = torch.chunk(
                model.relation_embedding, 3, dim=1
            )
            translation_reg = torch.sum(
                translation ** 2, dim=-1
            ).mean()
            loss += translation_weight * translation_reg
            regularization_log['translation_regularization'] = (
                translation_reg.item()
            )

        if (model.model_name in (
                'CoupledReciprocalTransERR',
                'CoupledReciprocalRelativeQuaternionTransERR')
                and args.reciprocal_residual_regularization != 0.0):
            reciprocal_residual_reg = torch.sum(
                model.inverse_relation_residual ** 2, dim=-1
            ).mean()
            loss += (
                reciprocal_residual_reg
                * args.reciprocal_residual_regularization
            )
            regularization_log['reciprocal_residual_regularization'] = (
                reciprocal_residual_reg.item()
            )

        if (model.model_name in (
                'TailResidualReciprocalTransERR',
                'TailResidualReciprocalRelativeQuaternionTransERR')
                and args.reciprocal_residual_regularization != 0.0):
            reciprocal_residual_reg = torch.sum(
                model.tail_relation_residual ** 2, dim=-1
            ).mean()
            loss += (
                reciprocal_residual_reg
                * args.reciprocal_residual_regularization
            )
            regularization_log['reciprocal_residual_regularization'] = (
                reciprocal_residual_reg.item()
            )

        if (model.model_name in _COUPLED_TRANSLATION_RESIDUAL_MODELS
                and args.reciprocal_residual_regularization != 0.0):
            reciprocal_residual_reg = torch.sum(
                model.tail_relation_residual ** 2, dim=-1
            ).mean()
            loss += (
                reciprocal_residual_reg
                * args.reciprocal_residual_regularization
            )
            regularization_log['reciprocal_residual_regularization'] = (
                reciprocal_residual_reg.item()
            )

        if ((model.model_name in (
                'BidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'BilinearResidualBidirectionalRelativeQuaternionTransERR',
                'RelationMetricBidirectionalRelativeQuaternionTransERR',
                'HamiltonCompatibilityBidirectionalRelativeQuaternionTransERR',
                'ResidualEnergyBidirectionalRelativeQuaternionTransERR',
                'RoleResidualBidirectionalRelativeQuaternionTransERR',
                'ConjugateGatedBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'InverseConjugateGatedBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'FullCayleyBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'Rank2CayleyBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'BidirectionalTranslationResidualReciprocalRelativeQuaternionTransERR',
                'SoftExtremalBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'MaxMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'MeanVarianceBidirectionalResidualReciprocalRelativeQuaternionTransERR',
                'PMeanBidirectionalResidualReciprocalRelativeQuaternionTransERR')
                or model.model_name in _TWO_SIDED_RECIPROCAL_MODELS
                or model.model_name in _ADAPTIVE_MOMENT_RECIPROCAL_MODELS
                or model.model_name in _BLOCK_TRANSPORT_RECIPROCAL_MODELS
                or model.model_name in _INTERLEAVED_BLOCK_TRANSPORT_RECIPROCAL_MODELS
                or model.model_name in _RANK_QUATERNION_OPERATOR_MODELS
                or model.model_name in _ADVANCED_DEFORMATION_RECIPROCAL_MODELS
                or model.model_name in _RANK_DEFECT_LOCAL_GLOBAL_MODELS)
                and args.reciprocal_residual_regularization != 0.0):
            inverse_residual_reg = torch.sum(
                model.inverse_relation_residual ** 2, dim=-1
            ).mean()
            tail_residual_reg = torch.sum(
                model.tail_relation_residual ** 2, dim=-1
            ).mean()
            reciprocal_residual_reg = (
                inverse_residual_reg + tail_residual_reg
            ) / 2
            loss += (
                reciprocal_residual_reg
                * args.reciprocal_residual_regularization
            )
            regularization_log['reciprocal_residual_regularization'] = (
                reciprocal_residual_reg.item()
            )

        if model.model_name == 'RegionTransERR':
            region_reg = (model.region_width_logits.sigmoid().square().sum(-1).mean()
                          if model.region_width_bound else model.region_width_logits.sum() * 0)
            loss += getattr(args, 'region_regularization', 1e-4) * region_reg
            regularization_log['region_regularization'] = region_reg.item()

        if model.model_name == 'DoubleCenterTransERR':
            center_reg = model.center_offset.square().sum(dim=-1).mean()
            loss += getattr(args, 'double_center_regularization', 1e-4) * center_reg
            regularization_log['double_center_regularization'] = center_reg.item()

        cycle_weight = getattr(
            args, 'reciprocal_cycle_regularization', 0.0
        )
        if cycle_weight != 0.0:
            cycle_loss, cycle_frame_loss, cycle_translation_loss = (
                reciprocal_cycle_consistency(
                    model.relation_embedding,
                    model.tail_relation_residual,
                    model.inverse_relation_residual,
                    model.reciprocal_residual_bound,
                    getattr(
                        args,
                        'reciprocal_cycle_translation_weight',
                        1.0,
                    ),
                )
            )
            loss += cycle_weight * cycle_loss
            regularization_log.update({
                'reciprocal_cycle_loss': cycle_loss.item(),
                'reciprocal_cycle_frame_loss': cycle_frame_loss.item(),
                'reciprocal_cycle_translation_loss': (
                    cycle_translation_loss.item()
                ),
            })

        if model.model_name == 'ContextTransERR' and args.context_regularization != 0.0:
            context_reg = (
                model.context_down.pow(2).mean()
                + model.context_up.pow(2).mean()
            )
            loss += context_reg * args.context_regularization
            regularization_log['context_regularization'] = context_reg.item()

        if (model.model_name in (
                'RelationEntityBiasTransERR',
                'DomainRangeGatedSO4TransERR')
                and args.relation_bias_regularization != 0.0):
            bias_reg = (
                model.head_entity_bias.pow(2).mean()
                + model.tail_entity_bias.pow(2).mean()
            )
            loss += bias_reg * args.relation_bias_regularization
            regularization_log['relation_bias_regularization'] = (
                bias_reg.item()
            )

        if (model.model_name in (
                'DomainRangeProjectionTransERR',
                'ProjectedGatedSO4TransERR')
                and args.relation_bias_regularization != 0.0):
            projection_reg = (
                model.domain_projection.pow(2).mean()
                + model.range_projection.pow(2).mean()
            )
            loss += projection_reg * args.relation_bias_regularization
            regularization_log['relation_bias_regularization'] = (
                projection_reg.item()
            )

        if (model.model_name in ('ScaleGroupTransERR', 'ScaleDimTransERR')
                and args.scale_regularization != 0.0):
            scale_reg = (
                model.head_scale.pow(2).mean()
                + model.tail_scale.pow(2).mean()
            )
            loss += scale_reg * args.scale_regularization
            regularization_log['scale_regularization'] = scale_reg.item()

        if model.model_name == 'MoGeoTransERR':
            if args.moe_regularization != 0.0:
                moe_reg = (
                    model.complex_entity_embedding.pow(2).mean()
                    + model.complex_relation_embedding.pow(2).mean()
                    + model.hyperbolic_entity_embedding.pow(2).mean()
                    + model.hyperbolic_relation_embedding.pow(2).mean()
                )
                loss += moe_reg * args.moe_regularization
                regularization_log['moe_regularization'] = moe_reg.item()
            if args.router_balance_regularization != 0.0:
                mean_router = model.router_weights().mean(dim=0)
                router_balance = torch.sum((mean_router - 1.0 / 3.0) ** 2)
                loss += router_balance * args.router_balance_regularization
                regularization_log['router_balance'] = router_balance.item()

        if (model.model_name == 'DualQuaternionTransERR'
                and args.dual_regularization != 0.0):
            dual_reg = (
                model.dual_entity_embedding.pow(2).mean()
                + model.dual_relation_embedding.pow(2).mean()
            )
            loss += dual_reg * args.dual_regularization
            regularization_log['dual_regularization'] = dual_reg.item()

        if (model.model_name == 'ResidualSubspaceTransERR'
                and args.subspace_regularization != 0.0):
            subspace_reg = model.subspace_logits.pow(2).mean()
            loss += subspace_reg * args.subspace_regularization
            regularization_log['subspace_regularization'] = subspace_reg.item()

        if (model.model_name in _PORT_HAMILTONIAN_MODELS
                and args.port_regularization != 0.0):
            port_reg = model.port_parameter_regularization()
            loss += port_reg * args.port_regularization
            regularization_log['port_regularization'] = port_reg.item()

        geometry_weight = getattr(args, 'geometry_regularization', 0.0)
        geometry_reg = None
        if model.model_name == 'ScrewFrameTransERR':
            geometry_reg = model.screw_distance_embedding.pow(2).mean()
        elif model.model_name in (
                'CayleyOrthogonalTransERR', 'CayleyFrameFusionTransERR',
                'BlockCayleyFrameFusionTransERR',
                'RelativeCayleyFusionTransERR',
                'DecoupledRelativeCayleyFusionTransERR'):
            geometry_reg = model.cayley_extra_embedding.pow(2).mean()
        elif model.model_name in (
                'ResidualSO4TransERR', 'GatedResidualSO4TransERR',
                'DomainRangeGatedSO4TransERR',
                'ProjectedGatedSO4TransERR',
                'RelativeGatedSO4TransERR'):
            geometry_reg = model.residual_so4_embedding.pow(2).mean()
        elif model.model_name == 'CoupledResidualSO4TransERR':
            geometry_reg = (
                model.coupled_residual_so4_embedding.pow(2).mean()
            )
        elif model.model_name == 'RelativeResidualSO4TransERR':
            geometry_reg = (
                model.relative_residual_so4_embedding.pow(2).mean()
            )
        elif model.model_name in _CAYLEY_RESIDUAL_RECIPROCAL_MODELS:
            geometry_reg = (
                model._cayley_residual_effective_gate().pow(2).mean()
            )
        elif model.model_name in _RANK_QUATERNION_OPERATOR_MODELS:
            geometry_reg = (
                model.quaternion_operator_bound
                * torch.tanh(model.quaternion_operator_coefficient)
            ).pow(2).mean()
        elif model.model_name in _RANK_DEFECT_LOCAL_GLOBAL_MODELS:
            geometry_reg = model.rank_defect_geometry_regularization()
        elif model.model_name == (
                'PolarBidirectionalResidualReciprocalRelativeQuaternionTransERR'):
            geometry_reg = (
                model.polar_bound
                * torch.tanh(model.polar_coefficient)
                / model.polar_rank
            ).pow(2).mean()
        elif model.model_name == (
                'FlowBidirectionalResidualReciprocalRelativeQuaternionTransERR'):
            geometry_reg = (
                model.flow_scale_up.pow(2).mean()
                + model.flow_shift_up.pow(2).mean()
            )
        elif model.model_name == 'AdaptiveMetricCliffordTransERR':
            geometry_reg = model.clifford_signature_delta.pow(2).mean()
        elif model.model_name == 'QuaternionMobiusTransERR':
            head_c, head_d, tail_b, tail_c, tail_d = torch.chunk(
                model.mobius_aux_embedding, 5, dim=1
            )
            quaternion_width = model.entity_dim // 4
            identity = torch.cat([
                torch.ones_like(head_d[:, :quaternion_width]),
                torch.zeros_like(head_d[:, quaternion_width:])
            ], dim=1)
            geometry_reg = (
                head_c.pow(2).mean()
                + (head_d - identity).pow(2).mean()
                + tail_b.pow(2).mean()
                + tail_c.pow(2).mean()
                + (tail_d - identity).pow(2).mean()
            )
        if geometry_reg is not None and geometry_weight != 0.0:
            loss += geometry_reg * geometry_weight
            regularization_log['geometry_regularization'] = (
                geometry_reg.item()
            )
            
        loss.backward()

        optimizer.step()

        log = {
            **regularization_log,
            **rank_loss_log,
            **curriculum_log,
            **cache_log,
            'positive_sample_loss': positive_sample_loss.item(),
            'negative_sample_loss': negative_sample_loss.item(),
            'loss': loss.item()
        }
        if model.model_name in _CAYLEY_RESIDUAL_RECIPROCAL_MODELS:
            log['cayley_residual_gate'] = (
                model._cayley_residual_effective_gate()
                .detach().abs().mean().item()
            )
        if model.model_name in _RANK_DEFECT_LOCAL_GLOBAL_MODELS:
            log['rank_defect_progress'] = (
                model.rank_defect_progress.detach().item()
            )
        if model.model_name == 'AdaptiveMetricCliffordTransERR':
            signature = model.effective_clifford_signature().detach()
            log.update({
                'clifford_signature_mean': signature.mean().item(),
                'clifford_signature_min': signature.min().item(),
                'clifford_signature_max': signature.max().item(),
            })

        if model.model_name == 'RegionTransERR':
            width = model.effective_region_width().detach()
            log.update(region_width_mean=width.mean().item(), region_width_max=width.max().item())

        return log
    
    @staticmethod
    def test_step(model, test_triples, all_true_triples, args):
        '''
        Evaluate the model on test or valid datasets
        '''
        
        model.eval()
        
        if args.countries:
            from sklearn.metrics import average_precision_score

            #Countries S* datasets are evaluated on AUC-PR
            #Process test data for AUC-PR evaluation
            sample = list()
            y_true  = list()
            for head, relation, tail in test_triples:
                for candidate_region in args.regions:
                    y_true.append(1 if candidate_region == tail else 0)
                    sample.append((head, relation, candidate_region))

            sample = torch.LongTensor(sample)
            if args.cuda:
                sample = sample.cuda()

            with torch.no_grad():
                y_score = model(sample).squeeze(1).cpu().numpy()

            y_true = np.array(y_true)

            #average_precision_score is the same as auc_pr
            auc_pr = average_precision_score(y_true, y_score)

            metrics = {'auc_pr': auc_pr}
            
        else:
            #Otherwise use standard (filtered) MRR, MR, HITS@1, HITS@3, and HITS@10 metrics
            #Prepare dataloader for evaluation
            test_dataloader_head = DataLoader(
                TestDataset(
                    test_triples, 
                    all_true_triples, 
                    args.nentity, 
                    args.nrelation, 
                    'head-batch'
                ), 
                batch_size=args.test_batch_size,
                num_workers=max(1, args.cpu_num//2), 
                collate_fn=TestDataset.collate_fn
            )

            test_dataloader_tail = DataLoader(
                TestDataset(
                    test_triples, 
                    all_true_triples, 
                    args.nentity, 
                    args.nrelation, 
                    'tail-batch'
                ), 
                batch_size=args.test_batch_size,
                num_workers=max(1, args.cpu_num//2), 
                collate_fn=TestDataset.collate_fn
            )
            
            test_dataset_list = [test_dataloader_head, test_dataloader_tail]
            
            logs = []

            step = 0
            total_steps = sum([len(dataset) for dataset in test_dataset_list])

            with torch.no_grad():
                for test_dataset in test_dataset_list:
                    for positive_sample, negative_sample, filter_bias, mode in test_dataset:
                        if args.cuda:
                            positive_sample = positive_sample.cuda()
                            negative_sample = negative_sample.cuda()
                            filter_bias = filter_bias.cuda()

                        batch_size = positive_sample.size(0)

                        score = model((positive_sample, negative_sample), mode)
                        score += filter_bias

                        #Explicitly sort all the entities to ensure that there is no test exposure bias
                        argsort = torch.argsort(score, dim = 1, descending=True)

                        if mode == 'head-batch':
                            positive_arg = positive_sample[:, 0]
                        elif mode == 'tail-batch':
                            positive_arg = positive_sample[:, 2]
                        else:
                            raise ValueError('mode %s not supported' % mode)

                        for i in range(batch_size):
                            #Notice that argsort is not ranking
                            ranking = (argsort[i, :] == positive_arg[i]).nonzero()
                            assert ranking.size(0) == 1

                            #ranking + 1 is the true ranking used in evaluation metrics
                            ranking = 1 + ranking.item()
                            logs.append({
                                'MRR': 1.0/ranking,
                                'MR': float(ranking),
                                'HITS@1': 1.0 if ranking <= 1 else 0.0,
                                'HITS@3': 1.0 if ranking <= 3 else 0.0,
                                'HITS@10': 1.0 if ranking <= 10 else 0.0,
                            })

                        if step % args.test_log_steps == 0:
                            logging.info('Evaluating the model... (%d/%d)' % (step, total_steps))

                        step += 1

            metrics = {}
            for metric in logs[0].keys():
                metrics[metric] = sum([log[metric] for log in logs])/len(logs)

        return metrics
