"""One-factor deviations from the running FB gamma10 / scale LR4 run."""

PROFILES = {
    'reference': {},
    'gamma5': {'gamma': 5.},
    'negative256': {'negative_sample_size': 256},
    'temperature025': {'adversarial_temperature': .25},
    'scale_lr2': {'scale_variant': 'lr2'},
    'reg02': {'regularization': .2},
    'reg06': {'regularization': .6},
    'first_decay10k': {'warm_up_ratio': [.1, .5, .8]},
    'residual_reg1e5': {'reciprocal_residual_regularization': 1e-5},
    'residual_reg1e3': {'reciprocal_residual_regularization': 1e-3},
    'reg08': {'regularization': .8},
    'temperature10': {'adversarial_temperature': 1.},
    'residual_lr025': {'reciprocal_residual_lr_scale': .25},
    'residual_lr1': {'reciprocal_residual_lr_scale': 1.},
    'decay5': {'lr_decay_factor': 5., 'reciprocal_residual_lr_decay_factor': 5.},
    'margin025': {'rank_loss_margin': .25},
    'margin1': {'rank_loss_margin': 1.},
    'lr_half': {'learning_rate': .0005},
    'lr_double': {'learning_rate': .002},
}

HARD_PROFILES = {
    'hard_max0075': {'curriculum_hard_negative_max_ratio': .075},
    'hard_max010': {'curriculum_hard_negative_max_ratio': .1},
    'hard005_negative256': {'negative_sample_size': 256},
    # Compensate the multipliers so only the base group's absolute LR changes.
    'hard005_base_lr_half': {
        'learning_rate': .0005, 'reciprocal_residual_lr_scale': 1.,
        'scale_variant': 'lr8',
    },
    'hard005_base_lr_double': {
        'learning_rate': .002, 'reciprocal_residual_lr_scale': .25,
        'scale_variant': 'lr2',
    },
    'hard005_residual_lr_half': {'reciprocal_residual_lr_scale': .25},
    'hard005_residual_lr_double': {'reciprocal_residual_lr_scale': 1.},
    'hard005_scale_lr_half': {'scale_variant': 'lr2'},
    'hard005_scale_lr_double': {'scale_variant': 'lr8'},
}
FOLLOWUP_PROFILES = {
    'hard005_start8k': {'curriculum_hard_negative_start_step': 8000},
    'hard005_start12k': {'curriculum_hard_negative_start_step': 12000},
    'hard005_ramp4k': {'curriculum_hard_negative_ramp_steps': 4000},
    'hard005_ramp16k': {'curriculum_hard_negative_ramp_steps': 16000},
    'hard005_rank0125': {'rank_loss_weight': .0125},
    'hard005_temp035': {'adversarial_temperature': .35},
    'hard005_temp07': {'adversarial_temperature': .7},
    'hard005_decay40k': {'warm_up_ratio': [.2, .4, .8]},
    'hard005_decay60k': {'warm_up_ratio': [.2, .6, .8]},
    'hard005_topk4': {'curriculum_hard_rank_topk': 4},
    'hard005_bound005': {'reciprocal_residual_bound': .05},
    'hard005_bound02': {'reciprocal_residual_bound': .2},
    'hard005_scale_lr3': {'scale_variant': 'lr3'},
    'hard005_scale_lr6': {'scale_variant': 'lr6'},
    'hard005_uniweight': {'uni_weight': True},
    'hard005_rank0005': {'rank_loss_weight': .005},
    'hard005_rank0': {'rank_loss_weight': 0.},
}
HARD_PROFILES.update(FOLLOWUP_PROFILES)
PROFILES.update({name: {'curriculum_hard_negative_max_ratio': .05, **overrides}
                 for name, overrides in HARD_PROFILES.items()})

SCALE_RATES = {'lr1': 1., 'lr2': 2., 'lr3': 3., 'lr4': 4., 'lr6': 6., 'lr8': 8.}

DECAY60_PROFILES = {
    'd60_hard0025': {'curriculum_hard_negative_min_ratio': .025,
                     'curriculum_hard_negative_max_ratio': .025},
    'd60_hard0': {'curriculum_hard_negative_min_ratio': 0.,
                  'curriculum_hard_negative_max_ratio': 0.},
    'd60_bound025': {},
    'd60_bound035': {},
    'd60_reg03': {'regularization': .3},
    'd60_first30k': {'warm_up_ratio': [.3, .6, .8]},
}
ENDPOINT_BOUNDS = {'d60_bound025': .25, 'd60_bound035': .35}
PROFILES.update({name: {'curriculum_hard_negative_max_ratio': .05,
                       'warm_up_ratio': [.2, .6, .8], **overrides}
                 for name, overrides in DECAY60_PROFILES.items()})
