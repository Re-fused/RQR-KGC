"""Isolated v73 control and endpoint-scale interventions; fresh training only."""

import argparse
import json
import logging
from pathlib import Path
import sys
from functools import partial

HERE = Path(__file__).resolve().parent
BASE_CODE = HERE / 'base_code'
if not BASE_CODE.is_dir():
    BASE_CODE = HERE.parents[1] / 'code'
sys.path.insert(0, str(BASE_CODE))
import run as base_run
from scale_model import MODEL, ScaledV73, scaled_optimizer
from bound_model import BoundedV73
from profiles import PROFILES, SCALE_RATES, ENDPOINT_BOUNDS

ORIGINAL_OPTIMIZER = base_run.build_optimizer


def parse_args(argv=None):
    extra = argparse.ArgumentParser(add_help=False)
    extra.add_argument('--scale_variant', choices=('control', *SCALE_RATES), default='control')
    extra.add_argument('--tuning_profile', choices=tuple(PROFILES), default='reference')
    options, remaining = extra.parse_known_args(argv)
    args = base_run.parse_args(remaining)
    args.scale_variant = options.scale_variant
    args.tuning_profile = options.tuning_profile
    args.experiment_model = 'V73FBGamma10ParameterStudy'
    if args.model != MODEL or not args.triple_relation_embedding:
        raise ValueError('Requires v73 with --triple_relation_embedding')
    if args.double_entity_embedding or args.double_relation_embedding or args.hidden_dim % 4:
        raise ValueError('Keep the original real quaternion width')
    if args.do_train and args.init_checkpoint is not None:
        raise ValueError('Training must start from scratch')
    if args.init_checkpoint:
        saved = json.loads((Path(args.init_checkpoint) / 'config.json').read_text())
        if saved.get('experiment_model') != args.experiment_model:
            raise ValueError('Checkpoint belongs to another experiment')
        args.scale_variant = saved['scale_variant']
        args.tuning_profile = saved['tuning_profile']
    return args


def optimizer_factory(model, lr, *rates, multiplier):
    optimizer = scaled_optimizer(ORIGINAL_OPTIMIZER, model, lr, multiplier, *rates)
    logging.info('V73Scale optimizer learning rates: %s',
                 [g['lr'] for g in optimizer.param_groups])
    return optimizer


def main(argv=None):
    args = parse_args(argv)
    if args.do_train:
        if not args.save_path:
            raise ValueError('Explicit fresh save path required')
        destination = Path(args.save_path)
        if any((destination / n).exists() for n in ('checkpoint', 'config.json', 'train.log')):
            raise FileExistsError('Refusing to overwrite an existing training run')
    if args.scale_variant != 'control':
        base_run.KGEModel = ScaledV73
        if args.tuning_profile in ENDPOINT_BOUNDS:
            base_run.KGEModel = partial(BoundedV73,
                endpoint_bound=ENDPOINT_BOUNDS[args.tuning_profile])
        multiplier = SCALE_RATES[args.scale_variant]
        base_run.build_optimizer = lambda model, lr, *rates: optimizer_factory(
            model, lr, *rates, multiplier=multiplier)
    base_run.main(args)


if __name__ == '__main__':
    main()
