"""Scale range intervention with unchanged identity and initial derivative."""

import torch
from scale_model import ScaledV73


class BoundedV73(ScaledV73):
    def __init__(self, *args, endpoint_bound=.5, **kwargs):
        super().__init__(*args, **kwargs)
        if endpoint_bound <= 0:
            raise ValueError('Endpoint scale bound must be positive')
        self.endpoint_bound = endpoint_bound

    def endpoint_scales(self, ids, inverse=False):
        bound = self.endpoint_bound
        scales = torch.exp(bound * torch.tanh((.5 / bound) * self.quaternion_scale_raw[ids]))
        if inverse:
            scales = scales.flip(1)
        return scales.repeat(1, 1, 4)
